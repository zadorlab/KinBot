from kinbot.species_routing import routing_name
import time
import copy
import logging
import numpy as np
import matplotlib.pyplot as plt
from kinbot import constants
from kinbot import geometry
from kinbot import zmatrix
from kinbot.frequencies import skip_rotor
from kinbot.stationary_pt import StationaryPoint
from kinbot.calculation import geometry_reference
from kinbot.stereo_identity import configured_geometry_allowed, UnsupportedStereochemistry

logger = logging.getLogger('KinBot')


def use_harmonic_model(species, par, reason):
    """Omit HIR consistently while retaining its calculated observations."""
    from kinbot.frequencies import thermochemical_frequencies
    logger.warning('%s: %s; retaining full harmonic frequencies and omitting '
                   'hindered rotors.', species.name, reason)
    hir = getattr(species, 'hir', None)
    if hir is not None:
        hir.projection_failure = reason
        hir._harmonic_fallback_reference = (
            geometry_reference(species), copy.deepcopy(species.dihed))
    modes = thermochemical_frequencies(species.freq, species.wellorts,
                                      par.get('imagfreq_threshold', 50.))
    species.kinbot_freqs = list(modes)
    species.reduced_freqs = list(modes)
    reference = copy.deepcopy((getattr(species, 'rotor_projection', None) or {}).get('reference'))
    species.rotor_projection = dict(method='harmonic_fallback', internal_rank=0,
        reference=reference,
        reason=reason, rotors=[dict(rotor_index=i, projected=False, reason=reason)
                             for i in range(len(species.dihed))])


def recover_hir_model(species, qc, par, *, allow_qc=False, wait=0):
    """Validate scans and reproject their modes; only optimization may submit QC.

    Return None while replacement scans are running, True after a repair or
    harmonic fallback, and False when the existing thermal model is unchanged.
    """
    from kinbot import frequencies
    from kinbot.calculation import array_fingerprint
    from kinbot.qc import QuantumChemistry

    hir = getattr(species, 'hir', None)
    if hir is None or par.get('multi_conf_tst') or not par.get('rotor_scan'):
        return False
    reference = geometry_reference(species)
    fallback_reference = (reference, species.dihed)
    if (getattr(hir, '_harmonic_fallback_reference', None) == fallback_reference
            and not (allow_qc and getattr(hir, 'scan_input_errors', None))):
        return True
    reference.update(backend=getattr(qc, 'qc', None),
                     dihedrals=[list(map(int, rotor)) for rotor in species.dihed])
    previous = getattr(hir, 'scan_reference', None) or {}
    keys = ('geometry_sha256', 'atoms', 'dihedrals', 'source_job', 'source_row_id')
    scan_changed = any(previous.get(key) != reference.get(key) for key in keys)
    incompatible = []
    if scan_changed:
        previous_rotors = previous.get('dihedrals', [])
        for rotor, definition in enumerate(species.dihed):
            trusted = (all(previous.get(key) == reference.get(key)
                           for key in ('geometry_sha256', 'atoms'))
                       and rotor < len(previous_rotors)
                       and previous_rotors[rotor] == list(definition))
            if not trusted:
                try:
                    QuantumChemistry._check_hir_definition(hir.point_job(rotor, 0),
                        [int(atom) + 1 for atom in definition], True,
                        geometry=species.geom, atoms=species.atom)
                    trusted = True
                except (ValueError, OSError):
                    pass
            if not trusted:
                incompatible.append(rotor)
        if incompatible:
            history = getattr(hir, 'recovery_observations', [])
            history.append({key: copy.deepcopy(getattr(hir, key, None)) for key in
                ('scan_reference', 'scan_jobs', 'hir_status', 'hir_raw_energies',
                 'hir_energies', 'hir_geoms', 'point_observations')})
            hir.recovery_observations = history
        else:
            logger.info('%s: recovered HIR reference from matching saved input.', species.name)
        hir.scan_reference = reference
    if not hasattr(hir, 'scan_input_errors'):
        hir.scan_input_errors = {}
    if allow_qc:
        incompatible = sorted(set(incompatible) | set(hir.scan_input_errors))
    scan_changed |= bool(incompatible)
    hir.species = species
    if allow_qc:
        hir.qc = qc
    if incompatible:
        if allow_qc:
            logger.warning('%s: replacing incompatible HIR scans %s; other scans are retained.',
                           species.name, incompatible)
            hir.generate_hir_geoms(np.asarray(species.geom).copy(),
                                   par.get('rigid_hir', False), rotors=incompatible)
        else:
            for rotor in incompatible:
                hir.scan_input_errors[rotor] = 'scan input differs from the selected geometry or rotor definition'
            logger.warning('%s: incompatible HIR scans %s remain harmonic; no QC is submitted during export.',
                           species.name, incompatible)
    if allow_qc and any(value < 0 for status in hir.hir_status for value in status):
        if not hir.check_hir(wait=wait):
            return None

    projection = getattr(species, 'rotor_projection', None) or {}
    projected_reference = projection.get('reference') or {}
    projection_changed = any(projected_reference.get(key) != reference.get(key) for key in keys)
    entries = projection.get('rotors', [])
    flags = [entry.get('projected') for entry in entries]
    indices = [entry.get('rotor_index') for entry in entries]
    valid_indices = (all(isinstance(i, (int, np.integer)) and not isinstance(i, (bool, np.bool_))
                         for i in indices)
                     and sorted(indices) == list(range(len(species.dihed))))
    try:
        hessian = np.asarray(getattr(species, 'hess', []), dtype=float)
    except (TypeError, ValueError) as error:
        use_harmonic_model(species, par, f'The selected Hessian is not a numerical matrix: {error}')
        return True
    projection_changed |= (not valid_indices
        or any(not isinstance(flag, (bool, np.bool_)) for flag in flags)
        or projection.get('internal_rank') != sum(bool(flag) for flag in flags)
        or len(species.freq) - len(species.reduced_freqs) != projection.get('internal_rank')
        or (valid_indices and any(entry.get('projected') and not hir.is_valid_rotor(entry['rotor_index'])
                                  for entry in entries))
        or bool(hessian.size and projected_reference.get('hessian_sha256') != array_fingerprint(hessian))
        or not reference['source_job'] or reference['source_row_id'] is None)
    if not scan_changed and not projection_changed:
        return False

    hir.projection_status = []
    if species.dihed and not any(hir.is_valid_rotor(i) for i in range(len(species.dihed))):
        use_harmonic_model(species, par, 'No usable HIR scans remain')
        return True

    # The original Hessian must belong to this geometry, atom order and selected
    # database row. Export does not read QC output or request a new Hessian.
    references = [getattr(species, 'optical_hessian_reference', None), projected_reference]
    hessian_reference = next((ref for ref in references if ref
        and all(ref.get(key) == reference.get(key) for key in
                ('geometry_sha256', 'atoms', 'source_job', 'source_row_id'))
        and reference['source_job'] and reference['source_row_id'] is not None
        and ref.get('hessian_sha256') == array_fingerprint(hessian)
        and isinstance(ref.get('hessian_massweighted'), (bool, np.bool_))
        and ref.get('hessian_unit') == ('hartree / (bohr^2 * amu)'
            if ref['hessian_massweighted'] else 'hartree / bohr^2')), None)
    if (hessian.shape != (3 * species.natom, 3 * species.natom)
            or not np.all(np.isfinite(hessian)) or hessian_reference is None):
        use_harmonic_model(species, par, 'HIR has no full Hessian associated with the selected calculation')
        return True
    hir.projection_status = []
    hir.__dict__.pop('projection_failure', None)
    try:
        species.kinbot_freqs, species.reduced_freqs = frequencies.get_frequencies(
            species, hessian, np.asarray(species.geom),
            massweighted=hessian_reference['hessian_massweighted'])
    except np.linalg.LinAlgError as error:
        use_harmonic_model(species, par, f'HIR frequency projection failed: {error}')
        return True
    for attr in ('kinbot_freqs', 'reduced_freqs'):
        setattr(species, attr, frequencies.thermochemical_frequencies(
            getattr(species, attr), species.wellorts, par.get('imagfreq_threshold', 50.)))
    summary = hir.demoted_rotor_summary()
    if summary:
        logger.warning('%s', summary)
    return True


class HIR:
    """
    Class that does all the steps for the HIR calculations of one species
    """
    def __init__(self, species, qc, par):
        """
        species: instance of StationaryPoint
        qc: instance of QuantumChemistry
        par: instance of Parameters
        """
        self.species = species
        self.qc = qc

        # number of points along one scan
        self.nrotation = par['nrotation']
        # boolean tells if profiles should be plotted
        self.plot_hir_profiles = par['plot_hir_profiles']
        # if 1 (default), remove bad rotors
        self.rotor_0_test = par['rotor_0_test']

        # -1 (not finished), 0 (successful), 1 (failed), or 2 (skipped)
        # for each HIR scan point
        self.hir_status = []
        # energies of all the HIR scan points
        self.hir_energies = []
        # Results before failed points are filled from a Fourier fit.
        self.hir_raw_energies = []
        # Fourier fit of each scan
        self.hir_fourier = []
        self.hir_fit_diagnostics = []
        self.projection_status = []
        self.scan_jobs = []
        self.rigid_scan = None
        # number of terms for Fourier
        self.n_terms = 6
        # all the geometries of the HIR scan points
        self.hir_geoms = []
        self.scan_reference = None
        self.point_observations = []
        # Definitions and continuation counts are part of the scan state so a
        # restart can retain completed points and resume only an optimization
        # that exhausted its Sella step budget.
        self.scan_definitions = []
        self.point_recovery_attempts = []
        attempts = par.get('hir_recovery_attempts', 1)
        multiplier = par.get('hir_recovery_step_multiplier', 2)
        if (not isinstance(attempts, int) or isinstance(attempts, bool)
                or attempts < 0):
            raise ValueError('hir_recovery_attempts must be a nonnegative integer.')
        if (not isinstance(multiplier, int) or isinstance(multiplier, bool)
                or multiplier < 1):
            raise ValueError('hir_recovery_step_multiplier must be a positive integer.')
        self.hir_recovery_attempts = attempts
        self.hir_recovery_step_multiplier = multiplier
        self.sella_steps = int(par.get('sella_steps', 250))
        self.demotion_reason = None
        self.statuses_before_demotion = None
        self.scan_input_errors = {}

    def generate_hir_geoms(self, cart, rigid, rotors=None):
        """
        Generate the initial geometries of the points along the scans
        """
        # A changed rotor does not discard compatible scans of other rotors.
        selected = set(range(len(self.species.dihed)) if rotors is None else rotors)
        fields = {
            'hir_status': lambda: [-1] * self.nrotation,
            'hir_energies': lambda: [-1] * self.nrotation,
            'hir_raw_energies': lambda: None,
            'hir_fourier': lambda: None,
            'hir_fit_diagnostics': lambda: None,
            'scan_jobs': lambda: [None] * self.nrotation,
            'hir_geoms': lambda: [[] for _ in range(self.nrotation)],
            'point_observations': lambda: [None] * self.nrotation,
            'scan_definitions': lambda: [None] * self.nrotation,
            'point_recovery_attempts': lambda: [0] * self.nrotation,
        }
        for field, empty in fields.items():
            old = getattr(self, field, [])
            setattr(self, field, [empty() if i in selected or i >= len(old) else old[i]
                                 for i in range(len(self.species.dihed))])
        for rotor in selected:
            self.scan_input_errors.pop(rotor, None)
        self.__dict__.pop('projection_failure', None)
        self.__dict__.pop('_harmonic_fallback_reference', None)
        self.projection_status = []
        self.rigid_scan = bool(rigid)
        self.scan_reference = geometry_reference(self.species, cart)
        self.scan_reference['backend'] = getattr(self.qc, 'qc', None)
        self.scan_reference['dihedrals'] = [list(map(int, rotor)) for rotor in self.species.dihed]
        self.demotion_reason = None
        self.statuses_before_demotion = None

        for rotor in range(len(self.species.dihed)):
            if rotor not in selected:
                continue
            if skip_rotor(self.species.name, self.species.dihed[rotor]) == 1:
                self.hir_status[rotor] = [2 for i in range(self.nrotation)]
                logger.info('\tFor {} rotor {} was skipped in HIR.'.format(self.species.name, rotor))
                continue

            cart = np.asarray(cart)
            zmat_atom, zmat_ref, zmat, zmatorder = zmatrix.make_zmat_from_cart(self.species, rotor, cart, 0)

            # first element has same geometry
            cart_new = zmatrix.make_cart_from_zmat(zmat,
                                                   zmat_atom,
                                                   zmat_ref,
                                                   self.species.natom,
                                                   self.species.atom,
                                                   zmatorder)
            fi = [(zi + 1) for zi in zmatorder[:4]]
            self._submit_point(cart_new, rotor, 0, fi, rigid)
            for ai in range(1, self.nrotation):
                ang = 360. / float(self.nrotation)
                zmat[3][2] += ang
                for i in range(4, self.species.natom):
                    if zmat_ref[i][2] == 4:
                        zmat[i][2] += ang
                    if zmat_ref[i][2] == 1:
                        zmat[i][2] += ang
                cart_new = zmatrix.make_cart_from_zmat(zmat,
                                                       zmat_atom,
                                                       zmat_ref,
                                                       self.species.natom,
                                                       self.species.atom,
                                                       zmatorder)
                self._submit_point(cart_new, rotor, ai, fi, rigid)
        return 0

    def _submit_point(self, geom, rotor, point, dihedral, rigid):
        self.scan_definitions[rotor][point] = list(map(int, dihedral))
        try:
            self.scan_jobs[rotor][point] = self.qc.qc_hir(
                self.species, geom, rotor, point, [dihedral], rigid)
        except (ValueError, OSError, RuntimeError) as error:
            logger.warning('%s rotor %s point %s could not be submitted: %s',
                           self.species.name, rotor, point, error)
            self.hir_status[rotor][point] = 1
            self.point_observations[rotor][point] = {
                'accepted': False, 'rejection_reason': str(error),
                'qc_geometry_status': 'not_requested', 'qc_energy_status': 'not_requested',
                'geometry_angstrom': None, 'electronic_energy_hartree': None,
            }

    @staticmethod
    def _last_finite_geometry(job, natom):
        """Return the last finite constrained-optimization geometry."""
        from ase.io import read
        for suffix in ('.traj', '.xyz'):
            try:
                frames = read(job + suffix, index=':')
            except (FileNotFoundError, OSError, ValueError, EOFError):
                continue
            if not isinstance(frames, list):
                frames = [frames]
            for frame in reversed(frames):
                positions = np.asarray(frame.positions, dtype=float)
                if positions.shape == (natom, 3) and np.all(np.isfinite(positions)):
                    return positions
        return None

    @staticmethod
    def _saved_dihedral(job):
        """Read the literal constrained dihedral without executing a worker."""
        import ast
        from pathlib import Path
        try:
            nodes = ast.parse(Path(job + '.py').read_text()).body
        except (FileNotFoundError, OSError, SyntaxError):
            return None
        for node in nodes:
            if not isinstance(node, ast.Assign):
                continue
            names = [target.id for target in node.targets
                     if isinstance(target, ast.Name)]
            if 'base_0_fix' not in names or not isinstance(node.value, ast.ListComp):
                continue
            try:
                return list(map(int, ast.literal_eval(
                    node.value.generators[0].iter)))
            except (ValueError, TypeError, AttributeError):
                return None
        return None

    def _continue_failed_point(self, rotor, point, job):
        """Continue one incomplete Sella scan, preserving the original result.

        The Sella worker deliberately catches calculator/optimizer exceptions
        so it can publish an error record and its finite trajectory.  Such a
        record is just as useful a continuation point as ordinary step
        exhaustion.  Retry either case under a distinct job name; malformed
        output and scheduler jobs that never completed remain terminal here
        and are handled by the scheduler recovery layer.
        """
        from pathlib import Path
        if not hasattr(self, 'point_recovery_attempts'):
            self.point_recovery_attempts = []
        while len(self.point_recovery_attempts) <= rotor:
            self.point_recovery_attempts.append([0] * self.nrotation)
        while len(self.point_recovery_attempts[rotor]) < self.nrotation:
            self.point_recovery_attempts[rotor].append(0)
        attempts = self.point_recovery_attempts[rotor][point]
        limit = getattr(self, 'hir_recovery_attempts', 1)
        if attempts >= limit:
            return False

        # A clean worker exit, terminal Sella handoff, and finite trajectory
        # identify a completed worker whose constrained optimization can be
        # continued.  This includes both step exhaustion and a caught
        # calculator/optimizer exception after one or more finite steps.
        try:
            log_text = Path(job + '_sella.log').read_text()
        except OSError:
            return False
        try:
            exit_text = Path(job + '.exitcode').read_text().strip()
        except OSError:
            # Local execution does not necessarily use the scheduler wrapper.
            exit_text = ''
        # Scheduler wrappers now prefix the exit code with the scheduler job
        # id. Keep historical one-field status files restartable.
        exit_fields = exit_text.split()
        clean_exit = (not exit_fields
                      or (len(exit_fields) in (1, 2)
                          and exit_fields[-1] == '0'))
        terminal = log_text.rstrip().endswith('done')
        geom = self._last_finite_geometry(job, self.species.natom)
        if not clean_exit or not terminal or geom is None:
            return False

        if not hasattr(self, 'scan_definitions'):
            self.scan_definitions = []
        while len(self.scan_definitions) <= rotor:
            self.scan_definitions.append([None] * self.nrotation)
        while len(self.scan_definitions[rotor]) < self.nrotation:
            self.scan_definitions[rotor].append(None)
        dihedral = self.scan_definitions[rotor][point]
        if dihedral is None:
            dihedral = self._saved_dihedral(job)
        if dihedral is None:
            return False

        attempt = attempts + 1
        multiplier = getattr(self, 'hir_recovery_step_multiplier', 2)
        base_steps = getattr(self, 'sella_steps', 250)
        steps = int(base_steps * multiplier ** attempt)
        try:
            replacement = self.qc.qc_hir(
                self.species, geom, rotor, point, [dihedral],
                bool(getattr(self, 'rigid_scan', False)),
                recovery_attempt=attempt, steps=steps)
        except (ValueError, OSError, RuntimeError) as error:
            logger.warning('%s could not be continued from its last geometry: %s',
                           job, error)
            self.point_recovery_attempts[rotor][point] = attempt
            return False
        self.point_recovery_attempts[rotor][point] = attempt
        self.scan_definitions[rotor][point] = list(map(int, dihedral))
        if not hasattr(self, 'scan_jobs'):
            self.scan_jobs = []
        while len(self.scan_jobs) <= rotor:
            self.scan_jobs.append([None] * self.nrotation)
        while len(self.scan_jobs[rotor]) < self.nrotation:
            self.scan_jobs[rotor].append(None)
        self.scan_jobs[rotor][point] = replacement
        failure_lines = [line.strip() for line in log_text.splitlines()
                         if line.startswith('Constrained optimization failed:')]
        cause = (failure_lines[-1] if failure_lines
                 else 'constrained optimization did not converge')
        logger.warning('%s did not complete (%s); continuing as %s from the '
                       'last finite geometry for up to %s steps.',
                       job, cause, replacement, steps)
        return True

    def _resume_saved_failure(self, rotor, point):
        """Reconsider a saved recoverable point after a controller restart."""
        if self.hir_status[rotor][point] != 1:
            return False
        observations = getattr(self, 'point_observations', [])
        observation = (observations[rotor][point]
                       if rotor < len(observations)
                       and point < len(observations[rotor]) else None)
        recoverable = ('QC geometry failed',
                       'QC energy unavailable or nonfinite')
        if (not observation
                or observation.get('rejection_reason') not in recoverable):
            return False
        job = observation.get('source_job') or self.point_job(rotor, point)
        if not self._continue_failed_point(rotor, point, job):
            return False
        self.hir_status[rotor][point] = -1
        self.hir_energies[rotor][point] = -1
        self.hir_geoms[rotor][point] = []
        self.point_observations[rotor][point] = None
        return True

    def point_job(self, rotor, point):
        """Use the calculation actually submitted, including replacement scans."""
        jobs = getattr(self, 'scan_jobs', [])
        if rotor < len(jobs) and point < len(jobs[rotor]) and isinstance(jobs[rotor][point], str):
            return jobs[rotor][point]
        name = self.species.name if self.species.wellorts else routing_name(self.species)
        return f'hir/{name}_hir_{rotor}_{point:02d}'

    def test_hir(self):
        for rotor in range(len(self.species.dihed)):
            for ai in range(self.nrotation):
                if self._resume_saved_failure(rotor, ai):
                    continue
                if ai and self.hir_status[rotor][0] == -1:
                    # A completed point cannot be screened against an unknown
                    # reference energy. Revisit it after point zero finishes.
                    continue
                success = None
                if self.hir_status[rotor][ai] == -1:
                    energy, energy_status, reason = None, None, None
                    job = self.point_job(rotor, ai)
                    err, geom = self.qc.get_qc_geom(job, self.species.natom)
                    geometry_status = err
                    if err == 1:  # still running
                        continue
                    elif err == -1:  # failed
                        if self._continue_failed_point(rotor, ai, job):
                            continue
                        success = -1
                        reason = 'QC geometry failed'
                    else:
                        # check if all the bond lenghts are within
                        # 15% of the original bond lengths
                        temp = StationaryPoint('temp',
                                               self.species.charge,
                                               self.species.mult,
                                               atom=self.species.atom,
                                               geom=geom)
                        temp.characterize()
                        stereo_error = self._configuration_error(geom)
                        if stereo_error:
                            success = -1
                            reason = stereo_error
                        elif geometry.equal_geom(self.species,
                                               temp,
                                               0.15):
                            err, energy = self.qc.get_qc_energy(job)
                            energy_status = err
                            if err or not np.isfinite(energy):
                                success = -1
                                reason = 'QC energy unavailable or nonfinite'
                            elif ai == 0:
                                success = 1
                            # cut off barriers above 20 kcal/mol to prevent the Fourier fit to oscillate
                            elif (energy - self.hir_energies[rotor][0]) < 20. / constants.AUtoKCAL:
                                success = 1
                            else:
                                success = -1
                                reason = 'scan point exceeds the 20 kcal/mol acceptance limit'
                        else:
                            success = -1
                            reason = 'geometry failed the existing bond-length check'
                    # Acceptance arrays use failure sentinels. Keep the actual
                    # available observation before those arrays are overwritten.
                    while len(self.point_observations) <= rotor:
                        self.point_observations.append([None] * self.nrotation)
                    coordinates = np.asarray(geom)
                    self.point_observations[rotor][ai] = {
                        'source_job': job,
                        'qc_geometry_status': 'failed' if geometry_status == -1 else 'returned',
                        'qc_energy_status': {None: 'not_requested', -1: 'failed', 1: 'running',
                                             0: 'returned'}.get(energy_status, 'unknown'),
                        'electronic_energy_hartree': (float(energy) if energy_status == 0 and energy is not None
                                                     and np.isfinite(energy) else None),
                        'geometry_angstrom': (coordinates.tolist()
                                              if geometry_status == 0 and coordinates.shape == (self.species.natom, 3)
                                              and np.all(np.isfinite(coordinates)) else None),
                        'accepted': success == 1, 'rejection_reason': reason,
                    }
                if success == 1:
                    self.hir_status[rotor][ai] = 0
                    self.hir_energies[rotor][ai] = energy
                    self.hir_geoms[rotor][ai] = geom
                elif success == -1:
                    logger.warning('Hindered rotor optimization not successful '
                                   'for %s: %s', job, reason)
                    self.hir_status[rotor][ai] = 1
                    self.hir_energies[rotor][ai] = -1
                    self.hir_geoms[rotor][ai] = geom

        return 0

    def _configuration_error(self, geom):
        try:
            allowed = configured_geometry_allowed(self.species, geom)
        except UnsupportedStereochemistry:
            return 'scan stereochemistry cannot be assigned'
        if not allowed:
            return ('scan crosses into a different stereochemical pathway' if self.species.wellorts
                    else 'scan enters an excluded stereoisomer')
        return None

    def invalid_rotor_reason(self, rotor):
        """Why a rotor is excluded from the hindered-rotor treatment.

        Returns None for a usable scan. Failed non-reference points retain
        master's Fourier-fill policy; stereochemical pathway guards still apply.
        """
        if getattr(self, 'projection_failure', None):
            return self.projection_failure
        if rotor in self.scan_input_errors:
            return self.scan_input_errors[rotor]
        observations = getattr(self, 'point_observations', [])
        if rotor < len(observations):
            for point in observations[rotor]:
                reason = point.get('rejection_reason') if point else None
                if reason in ('scan crosses into a different stereochemical pathway',
                              'scan enters an excluded stereoisomer',
                              'scan stereochemistry cannot be assigned'):
                    # Do not interpolate across an excluded stereoisomer or
                    # another separately counted reaction pathway.
                    return reason
        if rotor >= len(self.hir_status) or len(self.hir_status[rotor]) != self.nrotation:
            return 'no scan recorded'
        status = self.hir_status[rotor]
        if status[0] == 2:
            return 'scan skipped'
        if status[0] == 1:
            return 'reference point failed or scans disabled by the rotor-0 energy test'
        if any(value < 0 for value in status):
            return 'scan incomplete'
        if any(value == 2 for value in status):
            return 'scan contains skipped points'
        if rotor >= len(self.hir_energies) or len(self.hir_energies[rotor]) != self.nrotation:
            return 'no scan energies recorded'
        if any(self.hir_energies[rotor][i] is None or not np.isfinite(self.hir_energies[rotor][i])
               for i, value in enumerate(status) if value == 0):
            return 'nonfinite successful scan energy'
        # Use the same measured energies and geometry source as hir_evidence.
        # Fourier-filled values must not conceal a missing successful result.
        raw = self.hir_raw_energies[rotor] if rotor < len(self.hir_raw_energies) else None
        raw = self.hir_energies[rotor] if raw is None else raw
        if any(i >= len(raw) or raw[i] is None or not np.isfinite(raw[i])
               for i, value in enumerate(status) if value == 0):
            return 'nonfinite successful measured scan energy'
        if 1 in status and (rotor >= len(self.hir_fourier)
                            or self.hir_fourier[rotor] is None):
            return 'partial scan has no usable Fourier interpolation'
        geoms = self.hir_geoms[rotor] if rotor < len(self.hir_geoms) else []
        points = observations[rotor] if rotor < len(observations) else []
        for i, state in enumerate(status):
            point = points[i] if i < len(points) else None
            geom = (point.get('geometry_angstrom') if point is not None
                    else geoms[i] if i < len(geoms) else None)
            if (state == 0 and np.shape(geom) == (self.species.natom, 3)
                    and np.all(np.isfinite(geom))):
                reason = self._configuration_error(geom)
                if reason:
                    return reason
        if rotor < len(self.projection_status):
            if not self.projection_status[rotor]['projected']:
                return self.projection_status[rotor]['reason']
        return None

    def is_valid_rotor(self, rotor):
        """Whether a completed scan has a usable reference point.

        Completion alone does not enable a failed or skipped rotor; such
        rotors stay harmonic oscillators in the frequency set and in MESS.
        """
        return self.invalid_rotor_reason(rotor) is None

    def demoted_rotor_summary(self):
        """One-line account of the rotors MESS will treat as harmonic, or ''."""
        demoted = []
        for rotor, rot in enumerate(self.species.dihed):
            why = self.invalid_rotor_reason(rotor)
            if why is not None:
                demoted.append(f'rotor {rotor} (atoms {rot[1] + 1}-{rot[2] + 1}): {why}')
        if not demoted:
            return ''
        return (f'{len(demoted)} of {len(self.species.dihed)} rotors of '
                f'{self.species.name} will be treated as harmonic oscillators '
                f'in MESS: ' + '; '.join(demoted))

    def check_hir(self, wait=0):
        """
        Return completion, including failed/skipped scans. Use is_valid_rotor
        to decide which completed scans can replace harmonic modes.
        """
        while 1:
            # check if all the calculations are finished
            self.test_hir()
            if len(self.species.dihed) == 0:
                logger.debug(f'No hindered rotors for {self.species.name}.')
            for rotor in range(len(self.species.dihed)):
                status = self.hir_status[rotor]
                if any([st < 0 for st in status]):  # at least one is running
                    continue
                if self.hir_status[rotor][0] in (1, 2):  # failed or skipped
                    continue
                energies = self.hir_energies[rotor]
                if abs(energies[0] - self.species.energy) * constants.AUtoKCAL > 0.1 and self.rotor_0_test:
                    logger.warning(f'\t0 angle rotor for rotor {rotor} has a different energy than '
                                   'the optimized structure for '
                                   f'{self.species.name} ({energies[0]} vs {self.species.energy}).')
                    logger.warning('This might be '
                                   'caused by an SCF convergence issue. '
                                   'Hindered rotors are disabled for this '
                                   'stationary point.')
                    logger.warning(rotor)
                    logger.warning(energies)
                    self.demotion_reason = 'rotor-zero energy differs from the optimized reference'
                    self.statuses_before_demotion = [list(row) for row in self.hir_status]
                    self.hir_status = [[1 for ai in ri] for ri in self.hir_status]

            # if job finishes status set to 0 or 1, if all done then do the following calculation
            if all([all([test >= 0 for test in status]) for status in self.hir_status]):
                for rotor in range(len(self.species.dihed)):
                    if self.hir_status[rotor][0] == 2 or self.hir_status[rotor][0] == 1:  # skipped or corrupted rotor
                        continue
                    if self.species.wellorts:
                        job = self.species.name + '_hir_' + str(rotor)
                    else:
                        job = routing_name(self.species) + '_hir_' + str(rotor)
                    replacements = [point for point in self.scan_jobs[rotor]
                                    if isinstance(point, str) and '_recovery_' in point] \
                                   if rotor < len(self.scan_jobs) else []
                    if replacements:
                        job += '_recovery_' + replacements[0].split('_recovery_')[-1]
                    if self.hir_status[rotor].count(0) < self.nrotation - 2:
                        logger.warning("More than 2 HIR calculations failed for " + job)

                    angles = [i * 2 * np.pi / float(self.nrotation) for i in range(self.nrotation)]
                    # write profile to file
                    self.write_profile(rotor, job)
                    if self.hir_status[rotor].count(0) < self.nrotation - 2:
                        # Keep legacy fitted evidence readable, while refusing
                        # to create a new torsional model from a scan whose
                        # measured profile is this incomplete.
                        while len(self.hir_fourier) <= rotor:
                            self.hir_fourier.append(None)
                        while len(self.hir_fit_diagnostics) <= rotor:
                            self.hir_fit_diagnostics.append(None)
                        while len(self.hir_raw_energies) <= rotor:
                            self.hir_raw_energies.append(None)
                        self.hir_fourier[rotor] = None
                        self.hir_raw_energies[rotor] = list(
                            self.hir_energies[rotor])
                        self.hir_fit_diagnostics[rotor] = {
                            'accepted': False,
                            'reason': 'more than two scan points are unavailable',
                            'measured_points': self.hir_status[rotor].count(0),
                            'required_points': self.nrotation - 2,
                        }
                        logger.warning('HIR fit unavailable for %s: %s', job,
                                       self.invalid_rotor_reason(rotor))
                        continue
                    # Check to see if HIR failed, job will continue if failed, but warning will be generated
                    a = self.fourier_fit(job, angles, rotor)
                    if a == 0:
                        logger.warning('HIR fit unavailable for %s: %s', job,
                                       self.invalid_rotor_reason(rotor))
                summary = self.demoted_rotor_summary()
                if summary:
                    logger.warning('\t' + summary)
                return 1
            else:
                if wait:
                    time.sleep(1)
                else:
                    return 0

    def write_profile(self, rotor, job):
        """
        Write a molden-readable file with the
        HIR scan (geometries and energies)
        """
        with open('hir/' + job + '.xyz', 'w') as ff:
            for i in range(self.nrotation):
                geom = np.asarray(self.hir_geoms[rotor][i])
                if geom.shape != (self.species.natom, 3):
                    # Failed calculations may have no geometry to display.
                    continue
                s = str(self.species.natom) + '\n'
                s += 'energy = ' + str(self.hir_energies[rotor][i]) + '\n'
                for j, at in enumerate(self.species.atom):
                    x, y, z = geom[j]
                    s += '{} {:.8f} {:.8f} {:.8f}\n'.format(at, x, y, z)
                ff.write(s)
        return

    def fourier_fit(self, job, angles, rotor):
        """
        Create a alternative fourier formulation of a hindered rotor
        profile, the angles are in radians and the energies in
        kcal per mol (Vanspeybroeck et al.)
        """
        energies = self.hir_energies[rotor]
        status = self.hir_status[rotor]
        while len(self.hir_fourier) <= rotor:
            self.hir_fourier.append(None)
        # Retain the optional export slot, without claiming the legacy fit
        # has passed the removed rank/order/coverage diagnostics.
        while len(self.hir_fit_diagnostics) <= rotor:
            self.hir_fit_diagnostics.append(None)
        self.hir_fit_diagnostics[rotor] = None
        while len(self.hir_raw_energies) <= rotor:
            self.hir_raw_energies.append(None)
        if self.hir_raw_energies[rotor] is None:
            self.hir_raw_energies[rotor] = list(energies)

        ang = [angles[i] for i in range(len(status)) if status[i] == 0]
        ens = [(energies[i] - energies[0])*constants.AUtoKCAL for i in range(len(status)) if status[i] == 0]

        X = np.zeros((len(ang), 2 * self.n_terms))
        for i, ai in enumerate(ang):
            for j in range(self.n_terms):
                X[i][j] = (1 - np.cos((j+1) * ai))
                X[i][j+self.n_terms] = np.sin((j+1) * ai)

        if(len(ens) > 0):
            a = 1
            self.A = np.linalg.lstsq(X, np.array(ens), rcond=None)[0]
            self.hir_fourier[rotor] = self.A.copy().tolist()

            for i, si in enumerate(status):
                if si == 1:
                    energies[i] = energies[0] + self.get_fit_value(angles[i])/constants.AUtoKCAL
            if self.plot_hir_profiles:
                # fit the plot to a png file
                plt.plot(ang, ens, 'ro')
                fit_angles = [i * 2. * np.pi / 360 for i in range(360)]
                fit_energies = [self.get_fit_value(ai) for ai in fit_angles]
                plt.plot(fit_angles, fit_energies)
                plt.xlabel('Dihedral angle [radians]')
                plt.ylabel('Energy [kcal/mol]')
                plt.savefig('hir_profiles/{}.png'.format(job))
                plt.clf()
        else:
            self.A = 0
            self.hir_fourier[rotor] = None
            a = 0

        return a

    def get_fit_value(self, ai, rotor=None):
        """
        Get the fitted energy
        """
        coefficients = self.A if rotor is None else self.hir_fourier[rotor]
        if coefficients is None:
            raise ValueError(f'No Fourier fit is available for rotor {rotor}.')
        e = 0.
        for j in range(self.n_terms):
            e += coefficients[j] * (1 - np.cos((j+1) * ai))
            e += coefficients[j+self.n_terms] * np.sin((j+1) * ai)
        return e
