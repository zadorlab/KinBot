import os
import shutil

import numpy as np
from ase import Atoms
from ase.db import connect
from ase.io import read, write
from ase.vibrations import Vibrations
from sella import Sella

from kinbot.constants import EVtoHARTREE
from kinbot.ase_modules.calculators.{code} import {Code}
from kinbot.stationary_pt import StationaryPoint
from kinbot.frequencies import calc_vibrations, get_frequencies

db = connect('{working_dir}/kinbot.db')
mol = Atoms(symbols={atom},
            positions={geom})

kwargs = {kwargs}
if '{Code}' == 'ORCA':
    from kinbot.ase_modules.calculators.orca import OrcaProfile
    kwargs['profile'] = OrcaProfile(command=kwargs['profile'])

mol.calc = {Code}(**kwargs)
if '{Code}' == 'Gaussian':
    mol.get_potential_energy()
    kwargs['guess'] = 'Read'
    mol.calc = {Code}(**kwargs)

basename = os.path.basename('{label}')
frequency_mode = '{frequency_mode}'

if os.path.isfile('{label}_sella.log'):
    os.remove('{label}_sella.log')

sella_kwargs = {sella_kwargs}
sella_kwargs.setdefault('internal', True)
if sella_kwargs['internal'] == True and len(mol.symbols) < 5:
    sella_kwargs['internal'] = False
opt = Sella(mol, order=1, 
            trajectory='{label}.traj',
            logfile='{label}_sella.log',
            **sella_kwargs)
freqs = []

fmax = {fmax}
steps = {steps}
mol.calc.label = '{label}'

converged = False
try:
    converged = opt.run(fmax=fmax, steps=steps)
    traj = read('{label}.traj', index=':')
    write('{label}.xyz', traj, format='xyz')
except:
    pass
if converged:
    try:
        if frequency_mode == 'native_hessian' and '{Code}' == 'Gaussian':
            # Sella owns the TS optimization. Evaluate the native Gaussian
            # Hessian once at the fixed, optimized saddle geometry.
            from kinbot import reader_gauss
            from kinbot.ase_modules.calculators.gaussian import \
                fixed_frequency_parameters
            from kinbot.utils import iowait

            frequency_kwargs = fixed_frequency_parameters(kwargs)
            frequency_kwargs['label'] = '{label}'
            frequency_kwargs['chk'] = os.path.basename('{label}')
            mol.calc = Gaussian(**frequency_kwargs)
            e = mol.get_potential_energy()
            iowait('{label}.log', 'gauss')
            freqs = reader_gauss.read_freq('{label}.log', {atom})
            zpe = reader_gauss.read_zpe('{label}.log')
            hessian = None
        else:
            freqs, zpe, hessian = calc_vibrations(mol, f'{{basename}}')
        if freqs is None:
            converged = False
        elif (np.count_nonzero(np.array(freqs) < 0) > 2  # More than two imag frequencies
            or np.count_nonzero(np.array(freqs) < -50) >= 2  # More than one frequency smaller than 50i
            or np.count_nonzero(np.array(freqs) < 0) == 0):  # No imaginary frequencies
            converged = False
        else:
            e = mol.get_potential_energy()
            data = {{'energy': e, 'frequencies': freqs, 'zpe': zpe,
                    'status': 'normal'}}
            if hessian is not None:
                data['hess'] = hessian
            db.write(mol, name='{label}', data=data)
    except Exception as error:
        with open('{label}_sella.log', 'a') as f:
            f.write(f'Frequency evaluation failed: '
                    f'{{type(error).__name__}}: {{error}}\n')
        converged = False

if 'vib' in os.getcwd():
    os.chdir("..")

if not converged:
    data = {{'status': 'error'}}
    data['frequencies'] = freqs
    db.write(mol, name='{label}', data=data)

if os.path.isdir(f'{{basename}}'):
    shutil.rmtree(f'{{basename}}')

if os.path.isdir(f'{{basename}}_vib'):
    if os.path.exists(os.path.join(f'{{basename}}_vib', 'vib.xyz')):
        shutil.copy2(os.path.join(f'{{basename}}_vib', 'vib.xyz'), 
                     os.path.join(os.getcwd(), f'{{basename}}_vib.xyz'))
    shutil.rmtree(f'{{basename}}_vib')

with open('{label}_sella.log', 'a') as f:
    f.write('done\n')
