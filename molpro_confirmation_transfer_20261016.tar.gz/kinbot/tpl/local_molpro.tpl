{command} {name}.inp

