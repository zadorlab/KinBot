        2TSMethod   statistical
{outerts}
