  Fragment       {chemid} ! {smi}
    RRHO
      Geometry[angstrom]            {natom}
{geom}
      Core   RigidRotor
        SymmetryFactor              {symm}
{rotconst}
      End
      Frequencies[1/cm]             {nfreq}
{freq}
{hinderedrotor}
      ElectronicLevels[1/cm]        {nelec}
{electronic_levels}
      ZeroEnergy[kcal/mol]        0.0
    End ! RRHO
