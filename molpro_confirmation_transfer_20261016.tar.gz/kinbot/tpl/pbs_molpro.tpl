{command} molpro/{name}.inp

