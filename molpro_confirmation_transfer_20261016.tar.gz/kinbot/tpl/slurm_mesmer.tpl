mesmer mesmer.inp

