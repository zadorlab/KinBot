cd "${{SLURM_SUBMIT_DIR:-$PWD}}/me" || exit 1
if {command} mess_{n}.inp; then
    mess_exit_code=0
else
    mess_exit_code=$?
fi
printf '%s\n' "$mess_exit_code" > mess_{n}.exitcode
exit "$mess_exit_code"
