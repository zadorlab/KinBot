"""Adapt audited ORCA observations to KinBot's backend-independent VRC report."""
import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
from kinbot.orbital_validation import assess
from run_panel import sha, write


def collect(specification):
    base=specification.resolve().parent
    spec=json.loads(specification.read_text())
    config_path=base/spec['output_settings']
    config=json.loads(config_path.read_text())
    policy_path=base/'selection_policy.json'
    policy=json.loads(policy_path.read_text())
    payload={'schema':1,'points':{},'models':{},'comparisons':[],
             'specification':str(specification),'specification_sha256':sha(specification),
             'configuration_sha256':sha(config_path), 'selection_policy_sha256':sha(policy_path)}
    for ch in spec['channels']:
        point_labels={p['label'] for p in ch['points']}
        jobs=[j for j in config['pilots'] if j['channel']==ch['id']
              and j['point'] in point_labels
              and [j['active_electrons'],j['active_orbitals']] in ch['candidate_spaces']]
        for job in jobs:
            point=ch['id']+'_'+job['point']
            definition=next(p for p in ch['points'] if p['label']==job['point'])
            geometry={'geometry_angstrom':job['geometry_angstrom'],
                      'distance_angstrom':definition['distance_angstrom']}
            if point in payload['points'] and payload['points'][point] != geometry:
                raise ValueError('Candidate geometries differ at a matched point')
            payload['points'][point]=geometry
            model=f"{ch['id']}_cas{job['active_electrons']}_{job['active_orbitals']}"
            observations=payload['models'].setdefault(model,{})
            directory=base/job['directory'];path=directory/'result.json'
            if not path.exists():
                continue
            result=json.loads(path.read_text())
            if not result['numerically_accepted']:
                continue
            states={}
            for mult in job['multiplicities']:
                energies=sorted(s['energy_hartree'] for s in result['caspt2_states'] if s['multiplicity']==mult)
                for rank,energy in enumerate(energies,1):
                    states[f'spectrum_m{mult}_rank{rank}']=energy
            observations[point]={'geometry_angstrom':job['geometry_angstrom'],'energies_hartree':states,
                'native_review_flags':result.get('native_review_flags',[]),
                'elapsed_seconds':result['elapsed_seconds'],
                'evidence':[{'path':str(p.resolve()),'sha256':sha(p)} for p in
                            [config_path,specification,path,directory/'panel.out',directory/'panel.inp']]}
        candidate,reference=ch['candidate_spaces']
        # The ordering here is declared by the example recipe, not inferred from size or completion.
        payload['comparisons'].append({'id':ch['id'],'question':ch['question'],
            'candidate':f'{ch["id"]}_cas{candidate[0]}_{candidate[1]}',
            'reference':f'{ch["id"]}_cas{reference[0]}_{reference[1]}',
            'points':[ch['id']+'_'+p['label'] for p in ch['points']],
            'asymptote':ch['id']+'_far',
            'angular_reference':{ch['id']+'_tilted':ch['id']+'_center'},
            'tolerance_kcal_mol':policy['screening_targets']['angular_difference_error'],
            'state_assignment':'Provisional sorted spectra within each spin; this does NOT establish physical state tracking.'})
    stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    folder=base/config['panel_directory']/'assessments';folder.mkdir(exist_ok=True)
    source=folder/(stamp+'.observations.json');write(source,payload)
    output=folder/(stamp+'.assessment.json');assess(source,output)
    write(folder/'latest.json',{'observations':str(source.resolve()),'assessment':str(output.resolve())})
    return output


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('specification',type=Path);a=p.parse_args()
    output=collect(a.specification);print(output)
    for comparison in json.loads(output.read_text())['comparisons']:
        print(comparison['id'],comparison['status'],'missing observations',len(comparison['missing']))
        for row in comparison['raw_comparisons']:
            print(' RAW',row['point'],row['maximum_absolute_difference_kcal_mol'])
        for row in comparison['angular_residuals']:
            print(' ANGULAR',row['point'],row['maximum_absolute_residual_kcal_mol'])
