"""Hash-bound radial, return-path and spin-gap diagnostics from closed ORCA jobs.

This analysis uses spectra sorted within each spin. It cannot identify physical
states across a crossing and never automatically approves an active space.
All paths, returning pairs and spin pairings are supplied in JSON.
"""
import argparse
from datetime import datetime, timezone
import json
import math
from pathlib import Path
from kinbot.orbital_validation import assess_path
from kinbot.constants import AUtoKCAL
from audit_orca import active_subspace_overlap
from run_panel import sha, write


def collect(specification):
    specification = specification.resolve()
    base = specification.parent
    spec = json.loads(specification.read_text())
    config_path = base / spec['settings']
    config = json.loads(config_path.read_text())
    jobs = {j['directory']: j for j in config['pilots']}
    report = {'schema': 1, 'created_utc': datetime.now(timezone.utc).isoformat(),
              'specification_sha256': sha(specification),
              'configuration_sha256': sha(config_path), 'cases': [],
              'state_assignment': 'Sorted spectra within spin; physical state identity is not established.',
              'production_approved': False}
    for case in spec['cases']:
        observations = {}; missing = []
        names = list(dict.fromkeys([case['asymptote'], *case['path'],
                *(n for pair in case.get('return_pairs', []) for n in pair)]))
        for name in names:
            job = jobs[name]; directory = base / name
            result_path = directory / 'result.json'
            if not result_path.exists():
                missing.append(name); continue
            result = json.loads(result_path.read_text())
            if not result['numerically_accepted']:
                missing.append(name); continue
            if sha(directory / 'panel.inp') != result['input_sha256']:
                raise ValueError(f'Native input changed: {name}')
            states = {}
            for mult in job['multiplicities']:
                values = sorted(x['energy_hartree'] for x in result['caspt2_states']
                                if x['multiplicity'] == mult)
                expected = job['roots'][job['multiplicities'].index(mult)]
                if len(values) != expected or not all(map(math.isfinite, values)):
                    raise ValueError(f'Incomplete native spectrum: {name}')
                states.update({f'm{mult}_rank{i}': e for i, e in enumerate(values, 1)})
            bond = case['bond_0based']; xyz = job['geometry_angstrom']
            distance = math.sqrt(sum((xyz[bond[0]][i] - xyz[bond[1]][i])**2 for i in (1, 2, 3)))
            observations[name] = {'distance_angstrom': distance, 'energies_hartree': states,
                'geometry_angstrom': xyz, 'elapsed_seconds': result['elapsed_seconds'],
                'active_subspace_overlap': result.get('active_subspace_overlap'),
                'active_core_projection': result.get('active_core_projection'),
                'native_review_flags': result.get('native_review_flags', []),
                'evidence': [{'path': str(p.resolve()), 'sha256': sha(p)} for p in
                             (result_path, directory/'panel.inp', directory/'panel.out')]}
        points = {}
        for name in names:
            xyz = jobs[name]['geometry_angstrom']
            a, b = case['bond_0based']
            points[name] = {'geometry_angstrom': xyz,
                'distance_angstrom': math.sqrt(sum((xyz[a][i]-xyz[b][i])**2 for i in (1,2,3)))}
        measured = assess_path(points, observations, path=case['path'],
            asymptote=case['asymptote'], return_pairs=case.get('return_pairs', []),
            return_tolerance_kcal_mol=spec['return_tolerance_kcal_mol'],
            spin_pairs=case.get('spin_gap_pairs', []))
        for name, row in observations.items():
            if name in measured['relative_energies_kcal_mol']:
                row['relative_energies_kcal_mol'] = measured['relative_energies_kcal_mol'][name]
                row['spin_gaps'] = measured['spin_gaps'][name]
        return_orbitals = []
        for forward, reverse in case.get('return_pairs', []):
            if forward not in observations or reverse not in observations:
                continue
            a, b = jobs[forward], jobs[reverse]
            if (a['active_electrons'], a['active_orbitals'], a['inactive_orbitals']) != (
                    b['active_electrons'], b['active_orbitals'], b['inactive_orbitals']):
                raise ValueError('Return pair uses different orbital partitions')
            paths = [base / name / 'panel.json' for name in (forward, reverse)]
            overlap = active_subspace_overlap(paths[1], paths[0],
                a['inactive_orbitals'], a['active_orbitals'])
            spectra = []
            for name in (forward, reverse):
                result = json.loads((base / name / 'result.json').read_text())
                spectra.append({(s['multiplicity'], s['root_0based']): s['energy_hartree']
                                for s in result['caspt2_states']})
            if spectra[0].keys() != spectra[1].keys():
                raise ValueError('Return pair uses different state labels')
            differences = [{'multiplicity': m, 'root_0based': r,
                'reverse_minus_forward_kcal_mol': (spectra[1][m,r]-spectra[0][m,r])*AUtoKCAL}
                for m,r in sorted(spectra[0])]
            return_orbitals.append({'forward': forward, 'reverse': reverse,
                'same_geometry_active_subspace_overlap': overlap,
                'native_label_energy_differences': differences,
                'maximum_native_label_difference_kcal_mol': max(
                    abs(s['reverse_minus_forward_kcal_mol']) for s in differences),
                'evidence': [{'path': str(p.resolve()), 'sha256': sha(p)} for p in paths],
                'interpretation': 'Direct same-geometry active-span and native-root-label comparison; '
                    'neither proves wavefunction identity along intervening points.'})
        report['cases'].append({'id': case['id'], 'observations': observations,
            'return_orbital_comparisons': return_orbitals, **measured})
    folder = base / spec['output_directory']; folder.mkdir(parents=True, exist_ok=True)
    path = folder / (datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')+'.json')
    write(path, report)
    return path


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('specification', type=Path)
    print(collect(p.parse_args().specification))
