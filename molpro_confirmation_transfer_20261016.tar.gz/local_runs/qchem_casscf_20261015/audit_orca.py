"""Extract native pilot results without interpreting normal exit as convergence."""
import argparse
import json
import re
from pathlib import Path


def audit(path):
    text = path.read_text(errors='replace')
    result = {'output': str(path.resolve()),
              'normal_termination': 'ORCA TERMINATED NORMALLY' in text,
              'casscf_native_converged': bool(re.search(r'THE CAS-SCF .*HAS CONVERGED', text)),
              'casscf_states': [], 'caspt2_states': [],
              'caspt2_converged_root_count': len(re.findall(r'CASPT2 calculation converged in', text)),
              'caspt2_nonconvergence_messages': re.findall(r'^.*CASPT2.*(?:NOT CONVERGE|not converge|failed to converge).*$', text, re.M)}
    gradients = re.findall(r'\|\|g\|\|\s*=\s*([-+\d.eE]+)', text)
    energies = re.findall(r'E\(CAS\)=\s*([-+\d.eE]+)', text)
    occupations = re.findall(r'N\(occ\)=([^\n]+)', text)
    if gradients:
        result['final_printed_orbital_gradient'] = float(gradients[-1])
    if energies:
        result['state_average_energy_hartree'] = float(energies[-1])
    if occupations:
        result['final_printed_occupations'] = [float(x) for x in occupations[-1].split()]
        result['occupation_note'] = 'Final printed/exported occupations may use the final property density; do not assume they are state-averaged.'
    result['native_active_electron_counts']=sorted({int(x) for x in re.findall(
        r'Number of active electrons\s*\.\.\.\s*(\d+)',text)})
    result['native_active_orbital_counts']=sorted({int(x) for x in re.findall(
        r'Number of active orbitals\s*\.\.\.\s*(\d+)',text)})
    result['native_frozen_core_orbital_counts']=sorted({int(x)+1 for x in re.findall(
        r'Last\s+frozen\s+orbital\s*\.\.\.\s*(-?\d+)',text)})
    result['native_alerts'] = []
    current_root = None
    for number, line in enumerate(text.splitlines(), 1):
        root = re.search(r'MULT\s+(\d+),\s+ROOT\s+(\d+)', line)
        if root:
            current_root = {'multiplicity': int(root[1]), 'root_0based': int(root[2])}
        if re.search(r'\bERROR\b|\bWARNING\b|NOT CONVERG|not converge|Diagonalization failed|error termination', line):
            result['native_alerts'].append({'line': number, 'text': line.strip(), 'state': current_root})
    result['native_review_flags'] = [a for a in result['native_alerts']
        if not re.search(r'CASSCF multiplicity blocks not in descending order', a['text'])]
    result['caspt2_denominators'] = []
    pt_iterations = text.split('CASPT2 Results')[0]
    for block in re.finditer(r'MULT\s+(\d+),\s+ROOT\s+(\d+)(.*?)(?=MULT\s+\d+,\s+ROOT|$)', pt_iterations, re.S):
        denominators = {name: float(value) for name, value in re.findall(
            r'smallest energy denominator\s+(\w+)\s*=\s*([-+\d.eE]+)', block[3])}
        if denominators:
            result['caspt2_denominators'].append({'multiplicity': int(block[1]),
                'root_0based': int(block[2]), 'classes_hartree': denominators})
    for block in re.finditer(r'CAS-SCF STATES FOR BLOCK\s+(\d+)\s+MULT=\s*(\d+)\s+NROOTS=\s*(\d+)(.*?)(?=CAS-SCF STATES FOR BLOCK|LOWEST ROOT|$)', text, re.S):
        for root, energy in re.findall(r'ROOT\s+(\d+):\s+E=\s*([-+\d.]+)', block.group(4)):
            result['casscf_states'].append({'multiplicity': int(block.group(2)), 'root_0based': int(root), 'energy_hartree': float(energy)})
    if 'CASPT2 Results' in text:
        part = text.split('CASPT2 Results')[-1]
        for block in re.finditer(r'MULT\s+(\d+),\s+ROOT\s+(\d+)(.*?)(?=MULT\s+\d+,\s+ROOT|$)', part, re.S):
            energy = re.search(r'Total Energy \(E0\+dE\)\s*:\s*E\s*=\s*([-+\d.]+)', block.group(3))
            weight = re.search(r'Reference Weight\s*:\s*W0\s*=\s*([-+\d.]+)', block.group(3))
            if energy:
                result['caspt2_states'].append({'multiplicity':int(block.group(1)), 'root_0based':int(block.group(2)), 'energy_hartree':float(energy.group(1)), 'reference_weight':float(weight.group(1)) if weight else None})
    result['last_lines'] = text.splitlines()[-10:]
    return result


def audit_orbitals(path, first, count):
    import numpy as np
    mol = json.loads(path.read_text())['Molecule']
    s = np.asarray(mol['S-Matrix'])
    mos = mol['MolecularOrbitals']['MOs']
    c = np.asarray([mo['MOCoefficients'] for mo in mos]).T
    eig, u = np.linalg.eigh(s)
    if np.min(eig) <= 0:
        raise ValueError('Nonpositive overlap eigenvalue')
    coeff = (u*np.sqrt(eig)) @ u.T @ c
    groups, offset = [], 0
    for index, atom in enumerate(mol['Atoms'], 1):
        for shell in atom['Basis']:
            size = 2*'spdfghi'.index(shell['Shell'].lower())+1
            groups.append((f"{index}:{atom['ElementLabel']}:{shell['Shell']}", offset, offset+size))
            offset += size
    if offset != c.shape[0]:
        raise ValueError('Basis-shell and coefficient dimensions differ')
    result = {'source':str(path.resolve()), 'overlap_min_eigenvalue':float(eig.min()),
              'orthonormality_max_error':float(np.max(abs(c.T@s@c-np.eye(c.shape[1])))),
              'population_convention':'Symmetric Loewdin populations in ORCA AO order',
              'occupation_note':'GBW occupations are exported values; not automatically the state-average occupations.',
              'active_orbitals':[]}
    for orbital in range(first, first+count):
        populations = {}
        for label, start, stop in groups:
            populations[label] = populations.get(label, 0)+float((coeff[start:stop,orbital]**2).sum())
        result['active_orbitals'].append({'orca_index_0based':orbital, 'occupation':mos[orbital]['Occupancy'],
            'populations':dict(sorted(populations.items(), key=lambda item:-item[1]))})
    return result


def core_projection(target, seed, core_indices, first, count):
    """Test active contamination by the seed's atom-centered core span.

    Seed AO coefficients are transported by atom/shell index to target geometry.
    This is a core-character diagnostic, NOT a cross-geometry MO overlap.
    """
    import numpy as np
    a = json.loads(target.read_text())['Molecule']
    b = json.loads(seed.read_text())['Molecule']
    if len(a['Atoms']) != len(b['Atoms']):
        raise ValueError('Core projection atom counts differ')
    for at, bt in zip(a['Atoms'], b['Atoms'], strict=True):
        if at['ElementLabel'] != bt['ElementLabel'] or len(at['Basis']) != len(bt['Basis']):
            raise ValueError('Core projection needs identical atom/basis order')
        for ab, bb in zip(at['Basis'], bt['Basis'], strict=True):
            if (ab['Shell'] != bb['Shell'] or not np.allclose(ab['Exponents'], bb['Exponents'], rtol=1e-12, atol=0)
                    or not np.allclose(ab['Coefficients'], bb['Coefficients'], rtol=1e-9, atol=1e-12)):
                raise ValueError('Core projection basis coefficients differ')
    s = np.array(a['S-Matrix'])
    ca = np.array([o['MOCoefficients'] for o in a['MolecularOrbitals']['MOs']]).T[:,first:first+count]
    cb = np.array([o['MOCoefficients'] for o in b['MolecularOrbitals']['MOs']]).T[:,core_indices]
    gram = cb.T @ s @ cb
    cross = cb.T @ s @ ca
    projection = cross.T @ np.linalg.solve(gram, cross)
    return {'definition':'Seed core AO coefficients transported to target geometry by identical atom/shell order',
            'per_active_orbital':np.diag(projection).tolist(),
            'maximum_subspace_projection':float(np.linalg.eigvalsh(projection).max())}


def active_subspace_overlap(target, seed, first, count):
    """Exact same-geometry span overlap, invariant to rotations within the CAS."""
    import numpy as np
    a = json.loads(target.read_text())['Molecule']
    b = json.loads(seed.read_text())['Molecule']
    if a['CoordinateUnits'] != b['CoordinateUnits'] or len(a['Atoms']) != len(b['Atoms']):
        raise ValueError('Active overlap requires identical geometry and AO definitions')
    for at, bt in zip(a['Atoms'], b['Atoms'], strict=True):
        if (at['ElementLabel'] != bt['ElementLabel'] or
                not np.allclose(at['Coords'], bt['Coords'], rtol=0, atol=1e-9) or
                len(at['Basis']) != len(bt['Basis'])):
            raise ValueError('Active overlap requires identical geometry and AO definitions')
        for ab, bb in zip(at['Basis'], bt['Basis'], strict=True):
            if (ab['Shell'] != bb['Shell'] or
                    not np.allclose(ab['Exponents'], bb['Exponents'], rtol=1e-12, atol=0) or
                    not np.allclose(ab['Coefficients'], bb['Coefficients'], rtol=1e-9, atol=1e-12)):
                raise ValueError('Active overlap basis differs')
    s = np.asarray(a['S-Matrix'])
    ca = np.array([o['MOCoefficients'] for o in a['MolecularOrbitals']['MOs']]).T[:,first:first+count]
    cb = np.array([o['MOCoefficients'] for o in b['MolecularOrbitals']['MOs']]).T[:,first:first+count]
    sv = np.linalg.svd(cb.T @ s @ ca, compute_uv=False)
    return {'definition':'Same-geometry seed/final active-space principal overlaps',
            'singular_values':sv.tolist(), 'minimum':float(sv.min()),
            'interpretation':'Small values require chemical review; orbital relaxation can change the span.'}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('output', type=Path)
    parser.add_argument('--orbitals', type=Path)
    parser.add_argument('--first-active', type=int)
    parser.add_argument('--active-count', type=int)
    args = parser.parse_args()
    result = audit(args.output)
    if args.orbitals:
        if args.first_active is None or args.active_count is None:
            parser.error('Orbital audit needs --first-active and --active-count')
        result['orbital_audit'] = audit_orbitals(args.orbitals, args.first_active, args.active_count)
    args.output.with_suffix('.audit.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ('orbital_audit','last_lines')}, indent=2))
