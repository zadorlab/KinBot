"""Prepare correlated fragment geometry checks from localized asymptotic seeds.

Fragment identity, active spaces, spin roots and displacements are JSON data.
Bond displacements are sensitivity calculations, not a claim of optimization.
"""
import argparse
from copy import deepcopy
import json
from pathlib import Path
import time
import numpy as np
from build_fragment_panel import read_xyz
from extract_fragment_seed import extract
from transport_seed import transport
from run_panel import run, sha, write


def build(path, wait=False):
    base=path.resolve().parent; spec=json.loads(path.read_text())
    required=[base/case['geometry_job']/'result.json' for case in spec['cases']]
    while any(not p.exists() for p in required):
        for result_path in required:
            if result_path.exists() and not json.loads(result_path.read_text()).get('preoptimization_completed'):
                raise RuntimeError(f'Fragment optimization requires review: {result_path}')
        if not wait:
            raise RuntimeError('Required fragment optimizations have not finished')
        time.sleep(10)
    config=deepcopy(json.loads((base/spec['baseline_settings']).read_text()))
    config.update(panel_directory=spec['panel_directory'],execution_lock=spec['execution_lock'],
                  processes=spec['processes'],maxcore_mb_per_process=spec['maxcore_mb_per_process'],
                  purpose=spec['purpose'],pilots=[])
    executable=str(Path(config['executable']).with_name('orca_2json'))
    for case in spec['cases']:
        geometry_job=base/case['geometry_job']
        if not json.loads((geometry_job/'result.json').read_text())['preoptimization_completed']:
            raise RuntimeError(f'Fragment geometry needs review: {geometry_job}')
        source=base/case['source_job']
        if not json.loads((source/'result.json').read_text())['numerically_accepted']:
            raise RuntimeError(f'Asymptotic source needs review: {source}')
        symbols,coordinates=read_xyz(geometry_job/'geometry.xyz')
        seed_directory=base/spec['panel_directory']/(case['label']+'_source_seed')
        extraction=dict(case['extraction'],source_json=str(source/'panel.json'),directory=str(seed_directory))
        if not (seed_directory/'seed_copy.gbw').exists():
            extract(extraction,executable)
        for variation in case['variations']:
            xyz=coordinates.copy()
            if variation.get('bond_0based'):
                a,b=variation['bond_0based']
                if len(xyz)!=2 or sorted([a,b])!=[0,1]:
                    raise ValueError('Bond displacements currently require a diatomic fragment')
                direction=xyz[b]-xyz[a];direction/=np.linalg.norm(direction)
                xyz[a]-=0.5*variation['offset_angstrom']*direction
                xyz[b]+=0.5*variation['offset_angstrom']*direction
            geometry=[[s,*v.tolist()] for s,v in zip(symbols,xyz)]
            directory=base/spec['panel_directory']/(case['label']+'_'+variation['label'])
            seed=directory/'seed'
            if not (seed/'seed_copy.gbw').exists():
                transport(seed_directory/'seed_copy.json',geometry,[[i] for i in range(len(xyz))],
                          extraction['core'],extraction['inactive'],extraction['active'],seed,executable)
            config['pilots'].append(dict(
                directory=str(directory.relative_to(base)),channel=case['label'],point=variation['label'],
                charge=extraction['charge'],active_electrons=extraction['active_electrons'],
                active_orbitals=extraction['active'],inactive_orbitals=extraction['inactive'],
                multiplicities=case['multiplicities'],roots=case['roots'],block_weights=case['block_weights'],
                stage='CASSCF+CASPT2',export_orbitals=True,geometry_angstrom=geometry,
                initial_orbitals=str((seed/'seed_copy.gbw').relative_to(base)),
                initial_orbitals_validation=str((seed/'seed.validation.json').relative_to(base)),
                seed_core_orbitals=list(range(extraction['core'])),fragments_0based=[list(range(len(xyz)))],
                geometry_provenance={'job':case['geometry_job'],'xyz_sha256':sha(geometry_job/'geometry.xyz'),
                                     'variation':variation,'specification_sha256':sha(path)},
                initialization_note='Localized asymptotic fragment span, transported to the new internal geometry as an orbital guess.'))
    output=base/spec['output_settings']
    if output.exists() and json.loads(output.read_text())!=config:
        raise RuntimeError(f'Refusing to change existing configuration: {output}')
    write(output,config)
    return output


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('specification',type=Path)
    p.add_argument('--wait',action='store_true');p.add_argument('--run',action='store_true')
    args=p.parse_args();configuration=build(args.specification,args.wait)
    print('Prepared',configuration,flush=True)
    if args.run:
        run(configuration,wait=True)
