"""Build matched CAS comparisons from independently optimized fragments.

Atom mappings, channels, geometries, spaces and seed sources come from JSON.
The fragment optimizations provide geometry seeds, not chemical acceptance.
"""
import argparse
from copy import deepcopy
import json
from pathlib import Path
import time
import numpy as np
from run_panel import run, sha, write
from transport_seed import transport


def read_xyz(path):
    lines=path.read_text().splitlines()
    count=int(lines[0]);rows=[s.split() for s in lines[2:2+count]]
    if len(rows)!=count or any(len(r)!=4 for r in rows):
        raise ValueError(f'Invalid XYZ: {path}')
    return [r[0] for r in rows],np.array([[float(v) for v in r[1:]] for r in rows])


def fit_rotation(x,y):
    if len(x)==1:
        return np.eye(3)
    u,_,v=np.linalg.svd(x.T@y)
    fix=np.eye(3);fix[-1,-1]=np.linalg.det(u@v)
    return u@fix@v


def assemble(reference, template, fragments, bond, base):
    symbols=[r[0] for r in reference]
    old=np.array([r[1:] for r in reference]);target=np.array([r[1:] for r in template])
    if symbols != [r[0] for r in template]:
        raise ValueError('Template atom order differs from reference')
    if sorted(i for f in fragments for i in f['atoms_0based']) != list(range(len(old))):
        raise ValueError('Fragments must partition all atoms')
    new=target.copy();provenance=[]
    for fragment in fragments:
        ids=fragment['atoms_0based'];endpoints=[i for i in bond if i in ids]
        if len(endpoints)!=1:
            raise ValueError('Each fragment must contain exactly one bond endpoint')
        pivot=ids.index(endpoints[0])
        if len(ids)==1:
            if fragment.get('optimized_job'):
                raise ValueError('Atomic fragments do not need geometry optimization')
            continue
        source=base/fragment['optimized_job']
        result=json.loads((source/'result.json').read_text())
        if not result['preoptimization_completed']:
            raise ValueError(f'Fragment optimization needs review: {source}')
        atomlist,xyz=read_xyz(source/'geometry.xyz')
        if atomlist != [symbols[i] for i in ids]:
            raise ValueError('Optimized fragment atom ordering differs')
        # Align around the specified reacting atom, keeping its location fixed.
        x=xyz-xyz[pivot];y=old[ids]-old[endpoints[0]]
        fitted=x@fit_rotation(x,y)
        destination=target[ids]-target[endpoints[0]]
        rotation=fit_rotation(y,destination)
        if np.max(np.linalg.norm(y@rotation-destination,axis=1))>2e-7:
            raise ValueError('Existing panel templates do not use rigid fragments')
        new[ids]=fitted@rotation+target[endpoints[0]]
        provenance.append({'job':fragment['optimized_job'],'xyz_sha256':sha(source/'geometry.xyz'),
                           'result_sha256':sha(source/'result.json'),'atoms_0based':ids,
                           'maximum_change_from_parent_angstrom':float(np.linalg.norm(fitted-y,axis=1).max())})
        part=new[ids]
        if not np.allclose(np.linalg.norm(part[:,None]-part[None,:],axis=2),
                           np.linalg.norm(xyz[:,None]-xyz[None,:],axis=2),atol=1e-8,rtol=0):
            raise ValueError('Assembly changed internal fragment distances')
    if abs(np.linalg.norm(new[bond[1]]-new[bond[0]])-np.linalg.norm(target[bond[1]]-target[bond[0]]))>1e-8:
        raise ValueError('Assembly changed the requested separation')
    return [[s,*v.tolist()] for s,v in zip(symbols,new)],provenance


def build(specification, wait=False):
    base=specification.resolve().parent
    spec=json.loads(specification.read_text())
    if not spec['points'] or spec['points'][0] != 'far' or len(set(spec['points'])) != len(spec['points']):
        raise ValueError('Unique points must begin with far for orbital propagation')
    for index, point in enumerate(spec['points'][1:], 1):
        if spec['propagation_source'].get(point,'far') not in spec['points'][:index]:
            raise ValueError(f'Orbital dependency must precede {point}')
    required=sorted({f['optimized_job'] for ch in spec['channels'] for f in ch['fragments'] if f.get('optimized_job')})
    while True:
        for name in required:
            result_path=base/name/'result.json'
            if result_path.exists() and not json.loads(result_path.read_text()).get('preoptimization_completed'):
                raise RuntimeError(f'Fragment optimization requires review: {result_path}')
        missing=[j for j in required if not (base/j/'result.json').exists()]
        if not missing:
            break
        if not wait:
            raise RuntimeError('Waiting for fragment optimizations: '+', '.join(missing))
        write(base/(spec['panel_directory']+'_preparation_status.json'),{'status':'waiting_for_fragment_optimizations','jobs':missing})
        time.sleep(10)
    baseline=json.loads((base/spec['baseline_settings']).read_text())
    geometries=json.loads((base/spec['geometry_templates']).read_text())
    channels={ch['id']:ch for ch in spec['channels']}
    config=deepcopy(baseline)
    config.update(panel_directory=spec['panel_directory'],execution_lock=spec['execution_lock'],
                  purpose=spec['purpose'],pilots=[],geometry_level='PBE0 preoptimized isolated fragments; correlated geometry sensitivity pending')
    if 'resources' in spec:
        config.update(spec['resources'])
    if 'parallel_limits' in spec:
        config['parallel_limits']=spec['parallel_limits']
    prototypes=[j for j in baseline['pilots'] if j['point']=='far' and j['channel'] in channels]
    for point in spec['points']:
        for old in prototypes:
            channel=channels[old['channel']]
            job=deepcopy(old);label=f"{old['channel']}_cas{old['active_electrons']}_{old['active_orbitals']}_{point}"
            if 'resources' in spec:
                for key in ('processes','maxcore_mb_per_process'):
                    job.pop(key,None)
            directory=base/spec['panel_directory']/label
            geometry,proof=assemble(geometries[old['channel']]['center']['geometry_angstrom'],
                 geometries[old['channel']][point]['geometry_angstrom'],channel['fragments'],channel['bond_0based'],base)
            job.update(directory=str(directory.relative_to(base)),point=point,geometry_angstrom=geometry,
                       geometry_provenance=proof,geometry_specification_sha256=sha(specification),
                       initial_orbitals=str((directory/'seed/seed_copy.gbw').relative_to(base)),
                       initial_orbitals_validation=str((directory/'seed/seed.validation.json').relative_to(base)))
            for key in ('source_archive','source_member','source_input_sha256','original_seed','transported'):
                job.pop(key,None)
            if point=='far':
                source=base/old['directory'];result=source/'result.json'
                if result.exists() and json.loads(result.read_text()).get('numerically_accepted'):
                    seed=source/'panel.json'
                else:
                    seed=(base/old['initial_orbitals']).with_suffix('.json')
                directory.mkdir(parents=True,exist_ok=True)
                if not (directory/'seed/seed_copy.gbw').exists():
                    transport(seed,geometry,[[i] for i in range(len(geometry))],len(job['seed_core_orbitals']),
                              job['inactive_orbitals'],job['active_orbitals'],directory/'seed',
                              str(Path(config['executable']).with_name('orca_2json')))
                job['initialization_note']='Atom-centered AO coefficient transport and block orthonormalization for changed internal geometry; a guess, not a cross-geometry wavefunction overlap.'
            else:
                source_point=spec['propagation_source'].get(point,'far')
                source_label=label.removesuffix(point)+source_point
                job['transport_from_job']=str(Path(spec['panel_directory'])/source_label)
            config['pilots'].append(job)
    path=base/spec['output_settings']
    if path.exists() and json.loads(path.read_text())!=config:
        raise RuntimeError(f'Refusing to change existing panel specification: {path}')
    write(path,config)
    write(base/(spec['panel_directory']+'_preparation_status.json'),{'status':'prepared','configuration':str(path),'jobs':len(config['pilots'])})
    return path


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('specification',type=Path);parser.add_argument('--wait',action='store_true')
    parser.add_argument('--run',action='store_true')
    args=parser.parse_args();configuration=build(args.specification,args.wait)
    print('Prepared:',configuration,flush=True)
    if args.run:
        if 'parallel_limits' in json.loads(configuration.read_text()):
            from run_parallel_panel import run as parallel_run
            parallel_run(configuration,wait=True)
        else:
            run(configuration,wait=True)
