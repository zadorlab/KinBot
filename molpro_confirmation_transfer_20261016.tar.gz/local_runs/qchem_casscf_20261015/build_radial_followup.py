"""Prepare explicitly requested radial and reverse-propagation CASPT2 checks.

This helper never selects a space. Cases, distances and propagation order come
from a JSON specification. It retains the matched screen's far-point evidence.
"""
import argparse
from copy import deepcopy
import json
from pathlib import Path
import numpy as np
from run_panel import sha, write


def translate_fragment(geometry, fragments, bond, distance):
    if not np.isfinite(distance) or distance <= 0:
        raise ValueError('A positive finite separation is required')
    xyz=np.array([r[1:] for r in geometry],dtype=float)
    if sorted(i for f in fragments for i in f)!=list(range(len(xyz))):
        raise ValueError('Fragments must partition all atoms')
    if len(bond)!=2 or bond[0]==bond[1] or any(i<0 or i>=len(xyz) for i in bond):
        raise ValueError('Invalid reacting bond')
    moving=next(f for f in fragments if bond[1] in f)
    if bond[0] in moving:
        raise ValueError('Reacting atoms must belong to different fragments')
    vector=xyz[bond[1]]-xyz[bond[0]];length=np.linalg.norm(vector)
    if length<1e-10:
        raise ValueError('Undefined approach direction')
    if abs(distance-length) < 1e-10:
        return deepcopy(geometry)  # Exact same-geometry forward/reverse comparison.
    xyz[moving]+=vector/length*(distance-length)
    return [[row[0],*point.tolist()] for row,point in zip(geometry,xyz,strict=True)]


def build(specification):
    base=specification.resolve().parent;spec=json.loads(specification.read_text())
    folder=Path(spec['panel_directory'])
    if folder.is_absolute() or '..' in folder.parts:
        raise ValueError('Followup folder must remain inside the experiment directory')
    original_path=base/spec['screen_settings'];original=json.loads(original_path.read_text())
    catalog={j['directory']:j for j in original['pilots']}
    config=deepcopy(original);config.update(panel_directory=spec['panel_directory'],
        purpose=spec['purpose'],pilots=[],execution_lock=original['execution_lock'])
    config['followup_specification_sha256']=sha(specification)
    config['source_configuration_sha256']=sha(original_path)
    selected=set();additions=[];seen=set(catalog)
    for case in spec['cases']:
        if Path(case['id']).name!=case['id'] or case['id'] in ('.','..',''):
            raise ValueError('Each case needs a simple directory name')
        source=catalog[case['geometry_source']]
        signature=(source['channel'],source['active_electrons'],source['active_orbitals'])
        selected.add(signature)
        parent=case['orbital_source']
        if parent not in catalog:
            raise ValueError('Initial orbital source must be a declared screen job')
        for key in ('channel','active_electrons','active_orbitals','inactive_orbitals',
                    'multiplicities','roots','block_weights'):
            if source[key]!=catalog[parent][key]:
                raise ValueError(f'Incompatible propagation source: {key}')
        for point in case['points']:
            job=deepcopy(source)
            directory=str(Path(spec['panel_directory'])/case['id']/point['label'])
            if (directory in seen or Path(point['label']).name!=point['label']
                    or point['label'] in ('', '.', '..')):
                raise ValueError('Each followup point needs a unique simple label')
            seen.add(directory)
            job.update(directory=directory,point=point['label'],
                geometry_angstrom=translate_fragment(source['geometry_angstrom'],source['fragments_0based'],
                                                     case['bond_0based'],point['distance_angstrom']),
                initial_orbitals=str(Path(directory)/'seed/seed_copy.gbw'),
                initial_orbitals_validation=str(Path(directory)/'seed/seed.validation.json'),
                transport_from_job=parent,
                radial_followup={'geometry_source':case['geometry_source'],
                    'distance_angstrom':point['distance_angstrom'],'bond_0based':case['bond_0based'],
                    'specification_sha256':sha(specification)})
            job.pop('seed_requires_accepted',None)
            additions.append(job)
            parent=directory
    config['pilots']=[deepcopy(j) for j in original['pilots']
        if (j['channel'],j['active_electrons'],j['active_orbitals']) in selected]+additions
    path=base/spec['output_settings']
    if path.exists() and json.loads(path.read_text())!=config:
        raise RuntimeError(f'Refusing to replace an existing specification: {path}')
    from run_parallel_panel import chains
    chains(config)  # Validate dependency order before writing or launching.
    write(path,config)
    return path


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('specification',type=Path)
    p.add_argument('--run',action='store_true');a=p.parse_args();path=build(a.specification)
    print(path)
    if a.run:
        from run_parallel_panel import run
        run(path,wait=True)
