"""Capture stable inputs, seeds, helper code and finished native evidence.

Running native files and large transient integral files are excluded. Licensed
ORCA executables are identified by hash, never copied into the archive.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import io
import json
from pathlib import Path
import platform
import subprocess
import sys
import tarfile

from render_orca import render


def capture(configuration, output, additional=()):
    base = configuration.resolve().parent
    config = json.loads(configuration.read_text())
    configurations = [(configuration, config)]
    for path in additional:
        if path.resolve().parent != base:
            raise ValueError('All included configurations must share the experiment directory')
        configurations.append((path, json.loads(path.read_text())))
    files = {}

    def include(path):
        path = path.resolve()
        if not path.is_file():
            return
        relative = str(path.relative_to(base))
        before = path.stat()
        data = path.read_bytes()
        after = path.stat()
        if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
            raise RuntimeError(f'File changed during snapshot: {path}')
        files[relative] = data

    for path in base.glob('*.py'):
        include(path)
    for path, _ in configurations:
        include(path)
    for path in base.glob('*policy.json'):
        include(path)
    for name in ('selection_decision.json', 'minimum_evidence_recipe.json',
                 'curated_evidence_recipe.json', 'plot_evidence_recipe.json',
                 'shift_control_cancellation.json',
                 'minimum_vrc_evidence.json', 'reproducibility/regression_20261016.json',
                 'reproducibility/regression_20261016.log',
                 'reproducibility/regression_20261016_followup.stdout',
                 'reproducibility/regression_20261016_followup.stderr',
                 'reproducibility/handoff_examples_20261016.log',
                 'reproducibility/final_handoff_regression_20261016.log',
                 'reproducibility/final_handoff_regression_verified_20261016.log',
                 'reproducibility/blodgett_transition_observation_20261016.json'):
        include(base/name)
    include(base/'panel_geometries.json')
    for path in (base / 'decision_history').rglob('*.json'):
        include(path)
    for path in base.glob('*specification.json'):
        include(path)
    for path in base.glob('*_worker_*.json'):
        include(path)
    for pattern in ('*_analysis_settings.json', '*_watch_settings.json', '*_resource_record.json'):
        for path in base.glob(pattern):
            include(path)
    for folder in ('basis', 'molpro_seeds'):
        for path in (base/folder).iterdir():
            if path.is_file() and path.suffix in ('.json', '.xml', '.gbw', '.orca', '.log'):
                include(path)
    for _, current in configurations:
        if 'jobs' in current:
            from run_geometry_preoptimization import render as render_geometry
            for job in current['jobs']:
                directory=base/job['directory']
                files['generated_inputs/'+job['directory']+'/geometry.inp']=render_geometry(current,job,base).encode()
                if (directory/'result.json').exists():
                    for name in ('geometry.inp','geometry.out','geometry.launcher.stderr',
                                 'execution.json','result.json','geometry.xyz','geometry.hess',
                                 'geometry.gbw','geometry_trj.xyz','geometry.property.txt',
                                 'geometry_review.json','relaxation_diagnostic.json'):
                        include(directory/name)
            continue
        for job in current['pilots']:
            include(base/job['initial_orbitals'])
            include((base/job['initial_orbitals']).with_suffix('.json'))
            include(base/job['initial_orbitals_validation'])
            if (base/job['initial_orbitals']).exists():
                files['generated_inputs/'+job['directory']+'/panel.inp'] = render(current, job, base).encode()
            directory = base/job['directory']
            if (directory/'result.json').exists():
                # The controller writes result.json only after the child exits.
                for name in ('panel.inp', 'panel.out', 'panel.launcher.stderr', 'execution.json',
                             'result.json', 'independent_review.json', 'panel.json', 'panel.gbw',
                             'panel.json.conf', 'panel.property.txt'):
                    include(directory/name)
    for folder, name in [('caspt2_controls','numerical_sensitivity.json'),
                         ('caspt2_validation','independent_review_summary.json'),
                         ('caspt2_validation','asymptotic_screen.json'),
                         ('fragment_checks','separability.json'),
                         ('optimized_fragment_screen','hold.json')]:
        include(base/folder/name)
    for _, current in configurations:
        for folder in ('assessments', 'path_assessments'):
            for path in (base/current.get('panel_directory','')/folder).glob('*.json'):
                include(path)
    for path in (base / 'curated_evidence').rglob('*'):
        if path.is_file() and path.suffix in ('.json', '.md', '.pdf', '.png'):
            include(path)
    # The general comparison and geometry helpers are part of the reproducible
    # calculation record too. PYTHONPATH=source permits rerunning these adapters
    # from an extracted archive without relying on a later KinBot checkout.
    repository = base.parents[1]
    for name in ('__init__.py','rdkit_config.py','constants.py','execution.py',
                 'orbital_geometry.py','orbital_validation.py'):
        files['source/kinbot/'+name] = (repository/'kinbot'/name).read_bytes()
    files['source/LICENSE'] = (repository/'LICENSE').read_bytes()
    files['source/tests/test_orbital_validation.py'] = (repository/'tests/test_orbital_validation.py').read_bytes()
    for name in ('SULFUR_ORCA_VALIDATION_2026-10-15.md', 'SULFUR_REMAINING_CHECKS_2026-10-15.md',
                 'ORBITAL_REVIEW_WORKFLOW.md', 'ORBITAL_RECON_DELIVERABLES.md',
                 'GENERALITY_AUDIT_2026-10-15.md', 'REPOSITORY_CLEANUP_PLAN.md',
                 'SULFUR_MINIMUM_ACTIVE_SPACE_DECISIONS.md'):
        path = base.parents[1]/'docs'/name
        if path.exists():
            files['documentation/'+name] = path.read_bytes()
    for path in (repository / 'examples/anl/orbital_reviews/molpro_confirmation').iterdir():
        if path.is_file() and path.suffix in ('.py', '.json', '.md', '.sh'):
            files['handoff/molpro_confirmation/' + path.name] = path.read_bytes()
    for case in ('ch3s_anl1_f12', 'ch3ss_anl1_f12'):
        for path in (repository / 'examples/anl' / case).iterdir():
            if path.is_file() and path.suffix in ('.json', '.md'):
                files['handoff/' + case + '/' + path.name] = path.read_bytes()
    files['README.md'] = (
        '# Retained ORCA evidence and Molpro handoff\n\n'
        'This archive preserves inputs, native outputs, orbital seeds, settings, '
        'analysis code and the local decision. It does not certify native Molpro '
        'or production kinetics. See selection_decision.json and curated_evidence/.\n\n'
        'Reparse outputs with `PYTHONPATH=source python curate_minimum_evidence.py '
        'curated_evidence_recipe.json curated_evidence/replay`. Replay the three '
        'path specification files with assess_path_checks.py. These read retained '
        'data and create fresh reports without electronic-structure jobs.\n\n'
        'For fresh energy calculations use make_replay.py and a licensed ORCA '
        'installation; never overwrite retained outputs. See documentation/ for '
        'the methodology and handoff/ for Molpro/example inputs. Those documents '
        'retain repository-relative links and original provenance paths. The '
        'Molpro adapters require the updated full KinBot checkout on Blodgett.\n'
    ).encode()
    executable = Path(config['executable'])
    manifest = {'schema': 1, 'created_utc': datetime.now(timezone.utc).isoformat(),
        'configuration': configuration.name, 'additional_configurations': [p.name for p in additional],
        'python': sys.version, 'platform': platform.platform(),
        'numpy': importlib.metadata.version('numpy'),
        'ase': importlib.metadata.version('ase'),
        'rdkit': importlib.metadata.version('rdkit'),
        'matplotlib': importlib.metadata.version('matplotlib'),
        'scipy': importlib.metadata.version('scipy'),
        'orca_executable': str(executable),
        'orca_executable_sha256': hashlib.sha256(executable.read_bytes()).hexdigest(),
        'mpi_bin': config['mpi_bin'],
        'git_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=base, text=True).strip(),
        'git_dirty': subprocess.check_output(['git', 'status', '--porcelain'], cwd=base, text=True),
        'scope': 'Inputs, orbital seeds, current helper code and finished native evidence. Running outputs excluded.',
        'replay': 'Extract into a new directory. Set executable and mpi_bin to local installations, then run run_panel.py. Paths in source-provenance records describe origin; job seed paths are relative. Existing outputs are preserved; use new job directories for fresh energy runs.',
        'assessment_replay': 'With the recorded dependencies installed, set PYTHONPATH=source and run assess_decision_panel.py decision_panel_specification.json. This creates a fresh report with evidence paths bound to the extracted files; original reports retain their original provenance paths.',
        'files': {name: {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
                  for name,data in sorted(files.items())}}
    if output.exists():
        raise FileExistsError(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(output, 'w:gz') as archive:
        for name,data in sorted(files.items()):
            info = tarfile.TarInfo(name); info.size = len(data)
            archive.addfile(info, io.BytesIO(data))
        data = (json.dumps(manifest, indent=2)+'\n').encode()
        info = tarfile.TarInfo('reproducibility_manifest.json'); info.size = len(data)
        archive.addfile(info, io.BytesIO(data))
    output.with_suffix(output.suffix+'.sha256').write_text(hashlib.sha256(output.read_bytes()).hexdigest()+'  '+output.name+'\n')
    print(output, len(files), 'files', output.stat().st_size, 'bytes')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('configuration', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--also', action='append', type=Path, default=[])
    args = parser.parse_args()
    capture(args.configuration, args.output, args.also)
