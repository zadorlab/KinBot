"""Compare the orbital spans of two candidates at identical geometries.

This is not cross-geometry wavefunction tracking or an energy accuracy test.
Candidate pairs and orbital ranges are read from the example specification.
"""
import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import numpy as np
from run_panel import sha, write


def compare(specification):
    base = specification.resolve().parent
    spec = json.loads(specification.read_text())
    configuration = base/spec['output_settings']
    config = json.loads(configuration.read_text())
    rows = []
    for channel in spec['channels']:
        small, large = channel['candidate_spaces']
        for point in channel['points']:
            pair = []
            for space in (small, large):
                job = next(j for j in config['pilots'] if j['channel'] == channel['id']
                           and j['point'] == point['label']
                           and [j['active_electrons'], j['active_orbitals']] == space)
                directory = base/job['directory']
                result = directory/'result.json'
                if not result.exists() or not json.loads(result.read_text())['numerically_accepted']:
                    break
                path = directory/'panel.json'
                mol = json.loads(path.read_text())['Molecule']
                first, count = job['inactive_orbitals'], job['active_orbitals']
                coefficients = np.array([m['MOCoefficients'] for m in mol['MolecularOrbitals']['MOs']]).T
                pair.append((mol, coefficients[:, first:first+count], path))
            if len(pair) != 2:
                continue
            a, ca, pa = pair[0]
            b, cb, pb = pair[1]
            if a['Atoms'] != b['Atoms'] or a['CoordinateUnits'] != b['CoordinateUnits']:
                raise ValueError('Candidate orbital comparison requires identical geometry and basis')
            s = np.asarray(a['S-Matrix'])
            if not np.allclose(s, np.asarray(b['S-Matrix']), atol=1e-12, rtol=0):
                raise ValueError('Candidate AO overlap matrices differ')
            if ca.shape[1] > cb.shape[1]:
                raise ValueError('Containment needs the smaller span first')
            for c in (ca, cb):
                if np.max(np.abs(c.T@s@c-np.eye(c.shape[1]))) > 1e-6:
                    raise ValueError('Candidate orbitals are not orthonormal')
            values = np.linalg.svd(cb.T@s@ca, compute_uv=False)
            rows.append({'channel':channel['id'], 'point':point['label'],
                         'candidate_spaces':[small,large], 'singular_values':values.tolist(),
                         'minimum':float(values.min()),
                         'evidence':[{'path':str(p.resolve()), 'sha256':sha(p)} for p in (pa,pb)]})
    folder = base/config['panel_directory']/'assessments'
    folder.mkdir(exist_ok=True)
    output = folder/(datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')+'.orbital_spans.json')
    write(output, {'schema':1, 'definition':'Same-geometry smaller-CAS containment in expanded-CAS orbital span',
                  'configuration_sha256':sha(configuration), 'specification_sha256':sha(specification),
                  'cross_geometry_state_tracking_verified':False, 'comparisons':rows})
    return output


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('specification', type=Path)
    path = compare(parser.parse_args().specification)
    print(path)
    for row in json.loads(path.read_text())['comparisons']:
        print(row['channel'], row['point'], row['minimum'])
