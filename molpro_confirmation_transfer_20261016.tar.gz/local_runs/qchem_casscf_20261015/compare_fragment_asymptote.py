"""Compare spin-free dimer spectra to explicit products of fragment states.

This tests energy separability at a declared geometry. Sorted spectra provide
an energy diagnostic, not a wavefunction-overlap assignment.
"""
import argparse
from itertools import product
import json
from pathlib import Path
import numpy as np
from audit_orca import audit
from run_panel import sha, write

KCAL=627.5094740631


def compare(specification):
    base=specification.resolve().parent;spec=json.loads(specification.read_text())
    catalog={}
    for name in spec['configurations']:
        c=json.loads((base/name).read_text())
        for job in c['pilots']:catalog[job['directory']]=(c,job)
    records=[]
    for case in spec['cases']:
        paths=[base/case['dimer'],*(base/p for p in case['fragments'])]
        if len(paths)!=3:
            raise ValueError('Exactly two fragment calculations are required')
        declared=[catalog[str(p.relative_to(base))] for p in paths]
        dimer=declared[0][1]
        if len(dimer['fragments_0based'])!=2:raise ValueError('Expected two dimer atom groups')
        correlations=[dict(c['correlation'],**j.get('correlation',{})) for c,j in declared]
        if any(c!=correlations[0] for c in correlations[1:]):raise ValueError('Different correlated models')
        if len({sha(base/c['basis_file']) for c,j in declared})!=1:raise ValueError('Different orbital bases')
        for group,(_,fragment) in zip(dimer['fragments_0based'],declared[1:],strict=True):
            a=[dimer['geometry_angstrom'][i] for i in group];b=fragment['geometry_angstrom']
            if [r[0] for r in a]!=[r[0] for r in b]:raise ValueError('Fragment atom order differs')
            x=np.array([r[1:] for r in a]);y=np.array([r[1:] for r in b])
            if not np.allclose(np.linalg.norm(x[:,None]-x[None,:],axis=2),
                               np.linalg.norm(y[:,None]-y[None,:],axis=2),atol=1e-8,rtol=0):
                raise ValueError('Fragment internal geometry differs from the dimer')
        for key in ('charge','active_electrons','active_orbitals','inactive_orbitals'):
            if dimer[key]!=sum(j[key] for c,j in declared[1:]):raise ValueError(f'Nonadditive {key}')
        if not all((p/'result.json').exists() for p in paths):
            records.append({'id':case['id'],'status':'waiting'});continue
        results=[json.loads((p/'result.json').read_text()) for p in paths]
        if not all(r['numerically_accepted'] for r in results):
            records.append({'id':case['id'],'status':'native_result_requires_review'});continue
        natives=[audit(p/'panel.out') for p in paths]
        cores=[r['native_frozen_core_orbital_counts'] for r in natives]
        if any(len(c)!=1 for c in cores) or cores[0][0]!=cores[1][0]+cores[2][0]:
            raise ValueError('Incompatible native frozen-core definitions')
        row={'id':case['id'],'status':'compared','evidence':[
            {'directory':str(p.relative_to(base)),'output_sha256':sha(p/'panel.out'),
             'native_review_flags':r['native_review_flags']} for p,r in zip(paths,natives,strict=True)],'levels':{}}
        for level in ('casscf_states','caspt2_states'):
            if not all(r.get(level) for r in results):continue
            products=[]
            for a,b in product(results[1][level],results[2][level]):
                # 2*S=multiplicity-1; angular-momentum coupling in unit steps.
                for twice_spin in range(abs(a['multiplicity']-b['multiplicity']),
                                        a['multiplicity']+b['multiplicity']-1,2):
                    products.append({'multiplicity':twice_spin+1,
                        'energy_hartree':a['energy_hartree']+b['energy_hartree'],
                        'fragment_roots_0based':[a['root_0based'],b['root_0based']]})
            differences=[]
            for mult in sorted({s['multiplicity'] for s in results[0][level]}):
                actual=sorted(s['energy_hartree'] for s in results[0][level] if s['multiplicity']==mult)
                expected=sorted(s['energy_hartree'] for s in products if s['multiplicity']==mult)
                if len(actual)!=len(expected):raise ValueError('Dimer and coupled fragment root counts differ')
                differences.append({'multiplicity':mult,
                    'dimer_minus_fragment_sum_kcal_mol':[(a-b)*KCAL for a,b in zip(actual,expected,strict=True)],
                    'dimer_splittings_kcal_mol':[(a-min(actual))*KCAL for a in actual],
                    'fragment_product_splittings_kcal_mol':[(b-min(expected))*KCAL for b in expected]})
            row['levels'][level]=differences
        records.append(row)
    return {'specification_sha256':sha(specification),'cases':records,
        'interpretation':'Spin-free sorted-spectrum separability diagnostic. Requires matched basis, core, geometry and method in the declared calculations. Does not clear native warnings or establish production accuracy.'}


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('specification',type=Path)
    p.add_argument('--output',type=Path,required=True);a=p.parse_args();write(a.output,compare(a.specification))
