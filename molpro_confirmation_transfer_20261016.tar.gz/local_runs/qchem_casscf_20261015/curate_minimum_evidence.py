"""Index the declared minimum-space study from re-read native outputs.

This creates a new evidence directory. It neither moves original files nor
accepts a production model. The recipe selects the scientific comparisons;
historical failed and deferred expansions are not silently included.
"""
import argparse
from datetime import datetime, timezone
import json
from pathlib import Path

from audit_orca import audit
from run_panel import acceptance, sha, write


def curate(recipe_path, output):
    recipe_path = recipe_path.resolve()
    base = recipe_path.parent
    output = output.resolve()
    if output.exists():
        raise FileExistsError(output)
    recipe = json.loads(recipe_path.read_text())
    configurations = {}
    jobs = {}
    paths = []
    for item in recipe['panels']:
        p = base / item['settings']
        config = json.loads(p.read_text())
        configurations[str(p.relative_to(base))] = sha(p)
        for job in config['pilots']:
            if any(job['directory'].startswith(prefix) for prefix in item['directory_prefixes']):
                jobs[job['directory']] = (config, job)
    for name in recipe['path_specifications']:
        spec = json.loads((base / name).read_text())
        path = base / spec['settings']
        config = json.loads(path.read_text())
        configurations[str(path.relative_to(base))] = sha(path)
        by_name = {j['directory']: j for j in config['pilots']}
        for case in spec['cases']:
            paths.append(case)
            for job_name in [case['asymptote'], *case['path'],
                             *(j for pair in case['return_pairs'] for j in pair)]:
                jobs[job_name] = (config, by_name[job_name])
    rows = []
    missing = []
    for name, (config, job) in sorted(jobs.items()):
        directory = base / name
        if not (directory / 'result.json').is_file():
            missing.append(name)
            continue
        result = json.loads((directory / 'result.json').read_text())
        execution = json.loads((directory / 'execution.json').read_text())
        if not result.get('numerically_accepted'):
            raise ValueError('The declared decision set contains an unaccepted result: ' + name)
        native = audit(directory / 'panel.out')
        solver = dict(config['solver'], **job.get('solver', {}))
        errors = acceptance(native, job, solver)
        if errors:
            raise ValueError(f'{name}: {errors}')
        for field in ('casscf_states', 'caspt2_states', 'native_review_flags'):
            if native[field] != result[field]:
                raise ValueError('Saved result differs from native output: ' + name + ' ' + field)
        if (execution.get('status') != 'complete' or execution.get('returncode') != 0
                or sha(directory / 'panel.inp') != execution['input_sha256']
                or execution['input_sha256'] != result['input_sha256']
                or sha(base / config['basis_file']) != execution['basis_sha256']):
            raise ValueError('Native execution provenance failed: ' + name)
        if (execution['solver'] != solver or execution['correlation'] !=
                dict(config['correlation'], **job.get('correlation', {}))):
            raise ValueError('Executed model differs from requested settings: ' + name)
        seed = base / job['initial_orbitals']
        if sha(seed) != execution['seed_sha256']:
            raise ValueError('Orbital seed provenance failed: ' + name)
        artifacts = [directory / f for f in ('panel.inp', 'panel.out', 'panel.gbw',
            'panel.json', 'execution.json', 'result.json')]
        artifacts.extend((seed, base / job['initial_orbitals_validation']))
        xyz = job['geometry_angstrom']
        rows.append({'directory': name, 'channel': job['channel'], 'point': job['point'],
            'active_space': [job['active_electrons'], job['active_orbitals']],
            'geometry_angstrom': xyz, 'correlation': execution['correlation'],
            'states': native['caspt2_states'], 'state_average_roots': job['roots'],
            'multiplicities': job['multiplicities'], 'block_weights': job['block_weights'],
            'native_review_flags': native['native_review_flags'],
            'active_subspace_overlap': result.get('active_subspace_overlap'),
            'active_core_projection': result.get('active_core_projection'),
            'elapsed_seconds': execution['elapsed_seconds'],
            'evidence': [{'path': str(p.relative_to(base)), 'sha256': sha(p)} for p in artifacts]})
    report = {'schema': 1, 'created_utc': datetime.now(timezone.utc).isoformat(),
        'recipe': recipe_path.name, 'recipe_sha256': sha(recipe_path),
        'configuration_sha256': configurations, 'production_approved': False,
        'state_tracking_verified': False, 'native_outputs_reparsed': True,
        'interpretation': recipe['interpretation'], 'missing': missing,
        'observations': rows, 'path_definitions': paths}
    output.mkdir(parents=True)
    write(output / 'native_evidence.json', report)
    lines = ['# Curated native evidence', '', recipe['interpretation'], '',
             f'{len(rows)} completed points; {len(missing)} pending points.', '',
             '| Channel | CAS | Point | CASPT2 roots | Native review flags | Output |',
             '| --- | --- | --- | --- | --- | --- |']
    import os
    for row in rows:
        native_path = base / row['directory'] / 'panel.out'
        link = Path(os.path.relpath(native_path, output)).as_posix()
        lines.append(f'| {row["channel"]} | {tuple(row["active_space"])} | {row["point"]} | '
                     f'{len(row["states"])} | {len(row["native_review_flags"])} | [native output]({link}) |')
    if missing:
        lines += ['', 'Pending:'] + ['- ' + name for name in missing]
    (output / 'README.md').write_text('\n'.join(lines) + '\n')
    print(output / 'native_evidence.json')
    return report


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('recipe', type=Path)
    p.add_argument('output', type=Path)
    args = p.parse_args()
    curate(args.recipe, args.output)
