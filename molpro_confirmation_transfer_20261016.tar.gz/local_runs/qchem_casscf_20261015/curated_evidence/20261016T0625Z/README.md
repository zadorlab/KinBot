# Curated native evidence

Decision evidence for minimum-space VRC selection: completed native outputs are reparsed and compared with their saved results. Numerical acceptance is separate from chemical selection. Every native warning is retained. Expanded spaces are diagnostic comparators, not exact references. Sorted energies do not prove physical root tracking. Molpro confirmation and production kinetics remain pending.

47 completed points; 0 pending points.

| Channel | CAS | Point | CASPT2 roots | Native review flags | Output |
| --- | --- | --- | --- | --- | --- |
| ch3s_cs | (13, 8) | r1p9 | 6 | 0 | [native output](../../ch3s_radial_checks/ch3s_cs_cas13_8/r1p9/panel.out) |
| ch3s_cs | (13, 8) | r2p5 | 6 | 0 | [native output](../../ch3s_radial_checks/ch3s_cs_cas13_8/r2p5/panel.out) |
| ch3s_cs | (13, 8) | r3p1_reverse | 6 | 0 | [native output](../../ch3s_radial_checks/ch3s_cs_cas13_8/r3p1_reverse/panel.out) |
| ch3s_cs | (13, 8) | r4 | 6 | 0 | [native output](../../ch3s_radial_checks/ch3s_cs_cas13_8/r4/panel.out) |
| ch3s_cs | (5, 4) | r1p9 | 6 | 3 | [native output](../../ch3s_radial_checks/ch3s_cs_cas5_4/r1p9/panel.out) |
| ch3s_cs | (5, 4) | r2p5 | 6 | 3 | [native output](../../ch3s_radial_checks/ch3s_cs_cas5_4/r2p5/panel.out) |
| ch3s_cs | (5, 4) | r3p1_reverse | 6 | 3 | [native output](../../ch3s_radial_checks/ch3s_cs_cas5_4/r3p1_reverse/panel.out) |
| ch3s_cs | (5, 4) | r4 | 6 | 3 | [native output](../../ch3s_radial_checks/ch3s_cs_cas5_4/r4/panel.out) |
| ch3s_cs | (7, 5) | center | 6 | 3 | [native output](../../ch3s_s3s_recovery/ch3s_cs_cas7_5_center/panel.out) |
| ch3s_cs | (7, 5) | far | 6 | 3 | [native output](../../ch3s_s3s_recovery/ch3s_cs_cas7_5_far/panel.out) |
| ch3s_cs | (7, 5) | outer | 6 | 3 | [native output](../../ch3s_s3s_recovery/ch3s_cs_cas7_5_outer/panel.out) |
| ch3s_cs | (7, 5) | tilted | 6 | 3 | [native output](../../ch3s_s3s_recovery/ch3s_cs_cas7_5_tilted/panel.out) |
| ch3ss_cs | (7, 5) | r1p9 | 2 | 1 | [native output](../../ch3ss_radial_checks/ch3ss_cs_cas7_5/r1p9/panel.out) |
| ch3ss_cs | (7, 5) | r2p6 | 2 | 1 | [native output](../../ch3ss_radial_checks/ch3ss_cs_cas7_5/r2p6/panel.out) |
| ch3ss_cs | (7, 5) | r3p3_reverse | 2 | 1 | [native output](../../ch3ss_radial_checks/ch3ss_cs_cas7_5/r3p3_reverse/panel.out) |
| ch3ss_cs | (7, 5) | r4 | 2 | 1 | [native output](../../ch3ss_radial_checks/ch3ss_cs_cas7_5/r4/panel.out) |
| ch3ss_ss | (9, 7) | r2p1 | 12 | 11 | [native output](../../ch3ss_radial_checks/ch3ss_ss_cas9_7/r2p1/panel.out) |
| ch3ss_ss | (9, 7) | r2p8 | 12 | 0 | [native output](../../ch3ss_radial_checks/ch3ss_ss_cas9_7/r2p8/panel.out) |
| ch3ss_ss | (9, 7) | r3p7_reverse | 12 | 0 | [native output](../../ch3ss_radial_checks/ch3ss_ss_cas9_7/r3p7_reverse/panel.out) |
| ch3ss_ss | (9, 7) | r4p5 | 12 | 0 | [native output](../../ch3ss_radial_checks/ch3ss_ss_cas9_7/r4p5/panel.out) |
| ch3s_cs | (13, 8) | center | 6 | 0 | [native output](../../decision_panel/ch3s_cs_cas13_8_center/panel.out) |
| ch3s_cs | (13, 8) | far | 6 | 0 | [native output](../../decision_panel/ch3s_cs_cas13_8_far/panel.out) |
| ch3s_cs | (13, 8) | outer | 6 | 0 | [native output](../../decision_panel/ch3s_cs_cas13_8_outer/panel.out) |
| ch3s_cs | (13, 8) | tilted | 6 | 0 | [native output](../../decision_panel/ch3s_cs_cas13_8_tilted/panel.out) |
| ch3s_cs | (5, 4) | center | 6 | 3 | [native output](../../decision_panel/ch3s_cs_cas5_4_center/panel.out) |
| ch3s_cs | (5, 4) | far | 6 | 3 | [native output](../../decision_panel/ch3s_cs_cas5_4_far/panel.out) |
| ch3s_cs | (5, 4) | outer | 6 | 3 | [native output](../../decision_panel/ch3s_cs_cas5_4_outer/panel.out) |
| ch3s_cs | (5, 4) | tilted | 6 | 3 | [native output](../../decision_panel/ch3s_cs_cas5_4_tilted/panel.out) |
| ch3ss_cs | (7, 5) | center | 2 | 1 | [native output](../../decision_panel/ch3ss_cs_cas7_5_center/panel.out) |
| ch3ss_cs | (7, 5) | far | 2 | 1 | [native output](../../decision_panel/ch3ss_cs_cas7_5_far/panel.out) |
| ch3ss_cs | (7, 5) | outer | 2 | 1 | [native output](../../decision_panel/ch3ss_cs_cas7_5_outer/panel.out) |
| ch3ss_cs | (7, 5) | tilted | 2 | 1 | [native output](../../decision_panel/ch3ss_cs_cas7_5_tilted/panel.out) |
| ch3ss_cs | (9, 7) | center | 2 | 0 | [native output](../../decision_panel/ch3ss_cs_cas9_7_center/panel.out) |
| ch3ss_cs | (9, 7) | far | 2 | 0 | [native output](../../decision_panel/ch3ss_cs_cas9_7_far/panel.out) |
| ch3ss_cs | (9, 7) | outer | 2 | 0 | [native output](../../decision_panel/ch3ss_cs_cas9_7_outer/panel.out) |
| ch3ss_cs | (9, 7) | tilted | 2 | 0 | [native output](../../decision_panel/ch3ss_cs_cas9_7_tilted/panel.out) |
| ch3ss_ss | (7, 5) | center | 12 | 6 | [native output](../../decision_panel/ch3ss_ss_cas7_5_center/panel.out) |
| ch3ss_ss | (7, 5) | far | 12 | 6 | [native output](../../decision_panel/ch3ss_ss_cas7_5_far/panel.out) |
| ch3ss_ss | (7, 5) | outer | 12 | 6 | [native output](../../decision_panel/ch3ss_ss_cas7_5_outer/panel.out) |
| ch3ss_ss | (7, 5) | tilted | 12 | 6 | [native output](../../decision_panel/ch3ss_ss_cas7_5_tilted/panel.out) |
| ch3ss_ss | (9, 7) | center | 12 | 0 | [native output](../../decision_panel/ch3ss_ss_cas9_7_center/panel.out) |
| ch3ss_ss | (9, 7) | far | 12 | 0 | [native output](../../decision_panel/ch3ss_ss_cas9_7_far/panel.out) |
| ch3ss_ss | (9, 7) | outer | 12 | 0 | [native output](../../decision_panel/ch3ss_ss_cas9_7_outer/panel.out) |
| ch3ss_ss | (9, 7) | tilted | 12 | 5 | [native output](../../decision_panel/ch3ss_ss_cas9_7_tilted/panel.out) |
| ch3ss_ss | (7, 5) | r2p1 | 12 | 12 | [native output](../../minimum_ss_radial/ch3ss_ss_cas7_5/r2p1/panel.out) |
| ch3ss_ss | (7, 5) | r2p8 | 12 | 6 | [native output](../../minimum_ss_radial/ch3ss_ss_cas7_5/r2p8/panel.out) |
| ch3ss_ss | (7, 5) | r3p7_reverse | 12 | 6 | [native output](../../minimum_ss_radial/ch3ss_ss_cas7_5/r3p7_reverse/panel.out) |
