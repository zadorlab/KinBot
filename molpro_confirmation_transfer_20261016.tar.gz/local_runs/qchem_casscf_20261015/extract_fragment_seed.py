"""Extract a fragment's core/inactive/active spans from a separated supermolecule.

Geometry, atom partition and orbital dimensions are explicit input data. Singular
values must demonstrate localization before the result is used as a seed.
"""
import argparse
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import numpy as np
from transport_seed import invoke


def extract(spec, executable):
    source = Path(spec['source_json']).resolve()
    original = json.loads(source.read_text())
    molecule = original['Molecule']
    if molecule['CoordinateUnits'] != 'Angs':
        raise ValueError('Fragment extraction requires Angstrom coordinates')
    atoms = spec['atoms_0based']
    if len(set(atoms)) != len(atoms) or not all(0 <= i < len(molecule['Atoms']) for i in atoms):
        raise ValueError('Invalid fragment atom indices')
    offsets = [0]
    for atom in molecule['Atoms']:
        offsets.append(offsets[-1]+sum(2*'spdfghi'.index(s['Shell'])+1 for s in atom['Basis']))
    rows = np.array([r for i in atoms for r in range(offsets[i],offsets[i+1])])
    metric = np.asarray(molecule['S-Matrix'])[np.ix_(rows,rows)]
    values, vectors = np.linalg.eigh(metric)
    if values.min() <= 0:
        raise ValueError('Fragment AO metric is not positive definite')
    root = (vectors*np.sqrt(values))@vectors.T
    invroot = (vectors/np.sqrt(values))@vectors.T
    c = np.array([o['MOCoefficients'] for o in molecule['MolecularOrbitals']['MOs']]).T
    if len(c) != offsets[-1]:
        raise ValueError('Source coefficients do not match the basis dimensions')
    sc, si, sa = (spec[k] for k in ('source_core', 'source_inactive', 'source_active'))
    tc, ti, ta = (spec[k] for k in ('core', 'inactive', 'active'))
    source_bounds = [0,sc,si,si+sa,c.shape[1]]
    target_counts = [tc,ti-tc,ta,len(rows)-ti-ta]
    q = np.empty((len(rows),0)); diagnostics = []
    for label,a,b,n in zip(('core','inactive','active','external'),source_bounds[:-1],source_bounds[1:],target_counts,strict=True):
        if n < 0 or n > b-a:
            raise ValueError('Incompatible fragment block dimensions')
        if n == 0:
            continue
        block = c[rows,a:b].copy()
        for _ in range(2):
            block -= q@(q.T@metric@block)
        u,s,_ = np.linalg.svd(root@block,full_matrices=False)
        if len(s)<n or s[n-1] < spec.get('minimum_localization_singular_value',0.95):
            raise ValueError(f'{label} span is not localized on this fragment: {s[:n]}')
        q = np.column_stack((q,invroot@u[:,:n]))
        diagnostics.append({'block':label,'retained':n,'minimum_retained_singular_value':float(s[n-1]),
                            'maximum_discarded_singular_value':float(s[n]) if len(s)>n else None})
    error = float(np.max(abs(q.T@metric@q-np.eye(len(rows)))))
    if error > 1e-7:
        raise ValueError('Extracted fragment orbitals are not orthonormal')
    data = deepcopy(original);m=data['Molecule'];m['HFTyp']='RHF'
    m['Atoms']=[deepcopy(molecule['Atoms'][i]) for i in atoms]
    for i,atom in enumerate(m['Atoms']):atom['Idx']=i
    m.update(Charge=spec['charge'],Multiplicity=spec['multiplicity'],BaseName='seed')
    m['S-Matrix']=metric.tolist()
    electrons=sum(a['NuclearCharge'] for a in m['Atoms'])-spec['charge']
    if electrons != 2*ti+spec['active_electrons']:
        raise ValueError('Fragment electron count does not match orbital partition')
    alpha=(spec['active_electrons']+spec['multiplicity']-1)//2
    beta=(spec['active_electrons']-spec['multiplicity']+1)//2
    occupations=[2]*ti+[int(i<alpha)+int(i<beta) for i in range(ta)]+[0]*(len(rows)-ti-ta)
    energies=np.array([o['OrbitalEnergy'] for o in molecule['MolecularOrbitals']['MOs']])
    overlaps=c[rows].T@metric@q
    moenergies=(overlaps**2).T@energies
    template=deepcopy(molecule['MolecularOrbitals']['MOs'][0]);mos=[]
    for i in range(len(rows)):
        mo=deepcopy(template);mo.update(MOCoefficients=q[:,i].tolist(),Occupancy=occupations[i],OrbitalEnergy=float(moenergies[i]))
        mos.append(mo)
    m['MolecularOrbitals']['MOs']=mos
    labels=m['MolecularOrbitals'].get('OrbitalLabels')
    if isinstance(labels,list) and len(labels)==c.shape[1]:m['MolecularOrbitals']['OrbitalLabels']=labels[:len(rows)]
    directory=Path(spec['directory']).resolve()
    if directory.exists():raise FileExistsError(directory)
    directory.mkdir(parents=True)
    (directory/'seed.json').write_text(json.dumps(data)+'\n')
    (directory/'seed_copy.json.conf').write_text(json.dumps({'MOCoefficients':True,'Basisset':True,'1elIntegrals':['S'],'JSONFormats':['json']}))
    invoke(executable,directory,'seed',True);invoke(executable,directory,'seed_copy',False)
    check=json.loads((directory/'seed_copy.json').read_text())['Molecule']
    cc=np.array([o['MOCoefficients'] for o in check['MolecularOrbitals']['MOs']]).T
    err=float(abs(cc.T@np.array(check['S-Matrix'])@cc-np.eye(len(rows))).max())
    if err>1e-7:raise ValueError('Native fragment overlap validation failed')
    proof={'source_json':str(source),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
        'fragment_atoms_0based':atoms,'block_localization':diagnostics,'native_orthonormality_max_error':err,
        'orca_gbw_sha256':hashlib.sha256((directory/'seed_copy.gbw').read_bytes()).hexdigest(),
        'requires_native_overlap_validation':False,'core':tc,'inactive':ti,'active':ta}
    (directory/'seed.validation.json').write_text(json.dumps(proof,indent=2)+'\n')
    return proof


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('specification',type=Path);parser.add_argument('--orca-2json',required=True)
    args=parser.parse_args()
    for spec in json.loads(args.specification.read_text())['fragments']:
        print(json.dumps(extract(spec,args.orca_2json)),flush=True)
