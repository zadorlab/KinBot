"""Create a fresh run specification while retaining exact archived seeds."""
import argparse
from copy import deepcopy
import json
from pathlib import Path


def prepare(configuration, output, directory, executable=None, mpi_bin=None):
    base = configuration.resolve().parent
    if output.resolve().parent != base:
        raise ValueError('Replay JSON must be beside the original JSON so relative seeds remain valid')
    if Path(directory).is_absolute() or '..' in Path(directory).parts:
        raise ValueError('Replay directory must be inside the experiment directory')
    if (base/directory).exists() or output.exists():
        raise FileExistsError('A fresh replay directory and JSON filename are required')
    config = deepcopy(json.loads(configuration.read_text()))
    config['panel_directory'] = directory
    config['execution_lock'] = str(Path(directory)/'controller.lock')
    if executable:
        config['executable'] = str(executable.resolve())
    if mpi_bin:
        config['mpi_bin'] = str(mpi_bin.resolve())
    jobs=config.get('pilots',config.get('jobs'))
    if jobs is None:
        raise ValueError('Expected an energy panel or geometry job configuration')
    names = set();mapping={}
    for job in jobs:
        name = Path(job['directory'])
        if name.is_absolute() or '..' in name.parts or name == Path('.'):
            raise ValueError('Original job directories must be relative experiment paths')
        if name in names:
            raise ValueError('Duplicate original job directory')
        names.add(name)
        job['replay_of'] = job['directory']
        job['directory'] = str(Path(directory)/name)
        mapping[job['replay_of']]=job['directory']
    for job in jobs:
        for key in ('transport_from_job','seed_requires_accepted'):
            if job.get(key) in mapping:
                job[key]=mapping[job[key]]
        # Finished archived seeds are reused exactly. A not-yet-built seed must
        # instead be generated inside the fresh replay, never in the archive.
        if job.get('initial_orbitals') and not (base/job['initial_orbitals']).exists():
            job['initial_orbitals']=str(Path(job['directory'])/'seed/seed_copy.gbw')
            job['initial_orbitals_validation']=str(Path(job['directory'])/'seed/seed.validation.json')
    output.write_text(json.dumps(config, indent=2)+'\n')
    print(output)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('configuration', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--directory', required=True)
    parser.add_argument('--executable', type=Path)
    parser.add_argument('--mpi-bin', type=Path)
    args = parser.parse_args()
    prepare(args.configuration, args.output, args.directory, args.executable, args.mpi_bin)
