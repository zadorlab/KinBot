"""Map Cartesian Molpro XML orbitals to ORCA's normalized real spherical AOs.

Restricted to matching ordered atomic basis contractions, no ECP and l<=3.
Conventions: molpro/pymolpro grid.py and ORCA 6.1 manual section 9.3.3.
The transformation is checked by Cartesian reconstruction and C^T S C.
"""
import argparse
import copy
import json
import re
from pathlib import Path
import xml.etree.ElementTree as ET
import numpy as np


def cart_to_real(l):
    # Rows: Molpro Cartesian x,y,z; xx,yy,zz,xy,xz,yz;
    # xxx,yyy,zzz,xxy,xxz,xyy,yyz,xzz,yzz,xyz.
    # Columns: ORCA m=0,+1,-1,+2,-2,+3,-3, including ORCA f phases.
    if l == 0:
        return np.ones((1, 1))
    if l == 1:
        return np.eye(3)[:, [2, 0, 1]]
    if l == 2:
        a = np.zeros((6, 5))
        a[:3, 0] = [-.5, -.5, 1]
        a[4, 1] = a[5, 2] = a[3, 4] = 1
        a[:2, 3] = [np.sqrt(3)/2, -np.sqrt(3)/2]
        return a
    if l == 3:
        a = np.zeros((10, 7))
        a[2, 0] = 1
        a[[4, 6], 0] = -1.5/np.sqrt(5)
        a[0, 1] = a[1, 2] = -np.sqrt(3/8)
        a[5, 1] = a[3, 2] = -np.sqrt(3/40)
        a[7, 1] = a[8, 2] = np.sqrt(6/5)
        a[[4, 6], 3] = [np.sqrt(3)/2, -np.sqrt(3)/2]
        a[9, 4] = 1
        a[0, 5] = -np.sqrt(5/8)
        a[5, 5] = 3/np.sqrt(8)
        a[3, 6] = -3/np.sqrt(8)
        a[1, 6] = np.sqrt(5/8)
        return a
    raise ValueError('Angular momentum beyond verified s,p,d,f mapping')


def convert(xml, template, output, source_geometry=False):
    ns = {'m': 'http://www.molpro.net/schema/molpro-output'}
    root = ET.parse(xml).getroot()
    orbital_sets = [e for e in root.iter() if e.tag.endswith('}orbitals')]
    if len(orbital_sets) != 1 or orbital_sets[0].get('angular') != 'cartesian':
        raise ValueError('Need exactly one Cartesian orbital set')
    orbitals = orbital_sets[0].findall('m:orbital', ns)
    coefficients = np.array([list(map(float, o.text.split())) for o in orbitals]).T
    data = json.loads(template.read_text())
    mol = data['Molecule']
    # The importer needs a supported restricted orbital-container type.
    # CASSCF's exported HFTyp is otherwise interpreted as a two-spin list by
    # ORCA 6.1.1 and only half the spatial orbitals are imported.
    mol['HFTyp'] = 'RHF'
    atoms = [e for e in root.iter() if e.tag.endswith('}atom')]
    basis = next(e for e in root.iter() if e.tag.endswith('}basisSet') and e.get('id') == 'ORBITAL')
    groups = {e.get('id'): e for e in basis.findall('m:basisGroup', ns)}
    result, offset, residual = [], 0, 0.
    changed_geometry = False
    for atom, target_atom in zip(atoms, mol['Atoms'], strict=True):
        if atom.get('elementType') != target_atom['ElementLabel']:
            raise ValueError('Atom order differs')
        xyz = [float(atom.get(k)) for k in ('x3', 'y3', 'z3')]
        if np.max(abs(np.array(xyz)-target_atom['Coords'])) > 1e-8:
            if not source_geometry:
                raise ValueError('Geometry differs; template must have source geometry')
            changed_geometry = True
            target_atom['Coords'] = xyz
        associations = [a for a in basis.findall('m:association', ns)
                        if f"@id='{atom.get('id')}'" in a.find('m:atoms', ns).get('{http://www.w3.org/1999/xlink}href')]
        if len(associations) != 1:
            raise ValueError('Ambiguous basis association')
        href = associations[0].find('m:bases', ns).get('{http://www.w3.org/1999/xlink}href')
        shell_index = 0
        for gid in re.findall(r"@id='([^']+)'", href)[1:]:
            group = groups[gid]
            l = int(group.get('minL'))
            if l != int(group.get('maxL')):
                raise ValueError('Mixed angular momentum')
            exps = list(map(float, group.find('m:basisExponents', ns).text.split()))
            t = cart_to_real(l)
            for contraction in group.findall('m:basisContraction', ns):
                cc = list(map(float, contraction.text.split()))
                pairs = [(e, c) for e, c in zip(exps, cc) if c]
                shell = target_atom['Basis'][shell_index]
                shell_index += 1
                if shell['Shell'].lower() != 'spdf'[l] or not np.allclose([e for e,c in pairs], shell['Exponents'], atol=0, rtol=1e-12):
                    raise ValueError('Basis contraction order differs')
                # ORCA renormalizes contractions; retain the scalar difference.
                source_cc = np.array([c for e,c in pairs])
                target_cc = np.array(shell['Coefficients'])
                ratio = np.dot(source_cc,target_cc)/np.dot(target_cc,target_cc)
                if np.max(abs(source_cc-ratio*target_cc)) > 1e-10:
                    raise ValueError('Basis contraction spans differ')
                block = coefficients[offset:offset+t.shape[0]] * ratio
                mapped = np.linalg.lstsq(t, block, rcond=None)[0]
                residual = max(residual, float(np.max(abs(t@mapped-block))))
                result.append(mapped)
                offset += t.shape[0]
        if shell_index != len(target_atom['Basis']):
            raise ValueError('Missing target shells')
    c = np.vstack(result)
    if offset != coefficients.shape[0]:
        raise ValueError('AO count mismatch')
    orth = None
    if changed_geometry:
        mol.pop('S-Matrix', None)
    else:
        s = np.asarray(mol['S-Matrix'])
        orth = float(np.max(abs(c.T@s@c - np.eye(c.shape[1]))))
    if residual > 1e-5 or orth is not None and orth > 1e-4:
        raise ValueError(f'Mapping checks failed: reconstruction={residual}; orthogonality={orth}')
    if c.shape[1] != c.shape[0]:
        raise ValueError('Full MO set required for this import')
    for i, (mo, orb) in enumerate(zip(mol['MolecularOrbitals']['MOs'], orbitals, strict=True)):
        mo['MOCoefficients'] = c[:,i].tolist()
        mo['Occupancy'] = float(orb.get('occupation'))
        mo['OrbitalEnergy'] = float(orb.get('energy'))
    output.write_text(json.dumps(data) + '\n')
    return {'cartesian_reconstruction_max_error':residual, 'orthonormality_max_error':orth,
            'requires_native_overlap_validation': changed_geometry,
            'source_xml':str(xml), 'template_json':str(template), 'output_json':str(output)}


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('xml',type=Path); p.add_argument('template',type=Path); p.add_argument('output',type=Path)
    p.add_argument('--source-geometry',action='store_true',help='Requires subsequent native overlap export and validation')
    a = p.parse_args()
    print(json.dumps(convert(a.xml,a.template,a.output,a.source_geometry),indent=2))
