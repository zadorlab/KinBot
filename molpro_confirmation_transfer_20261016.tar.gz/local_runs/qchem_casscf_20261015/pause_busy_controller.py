"""Temporarily suspend an idle parent while its already-running native child finishes.

Recovery for an older controller imported before the BLAS thread limit fix.
The native child receives no signal. A finally block resumes the parent.
"""
import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import signal
import subprocess
import time


def process(pid):
    result = subprocess.run(['/bin/ps', '-p', str(pid), '-o', 'ppid=,stat=,command='],
                            capture_output=True, text=True)
    fields = result.stdout.strip().split(None, 2)
    return fields if len(fields) == 3 else None


def run(parent, child, record):
    p, c = process(parent), process(child)
    if not p or not c or 'run_panel.py' not in p[2] or int(c[0]) != parent or '/orca ' not in c[2]:
        raise RuntimeError('Expected bookkeeping parent and its native ORCA child are not present')
    data = {'parent_pid': parent, 'child_pid': child,
            'reason': 'Old parent BLAS workers remained busy while waiting for native child',
            'started_utc': datetime.now(timezone.utc).isoformat(), 'native_child_signalled': False}
    record.write_text(json.dumps(data, indent=2)+'\n')
    def interrupted(signum, frame):
        raise SystemExit(128 + signum)
    signal.signal(signal.SIGTERM, interrupted)
    signal.signal(signal.SIGINT, interrupted)
    try:
        os.kill(parent, signal.SIGSTOP)
        print('Suspended bookkeeping parent only:', parent, 'native child:', child, flush=True)
        until = time.monotonic() + 3600
        while time.monotonic() < until:
            current = process(child)
            if current is None or current[1].startswith('Z'):
                break
            if int(current[0]) != parent:
                raise RuntimeError('Native child parent changed')
            time.sleep(2)
    finally:
        try:
            os.kill(parent, signal.SIGCONT)
        except ProcessLookupError:
            pass
        data['resumed_utc'] = datetime.now(timezone.utc).isoformat()
        record.write_text(json.dumps(data, indent=2)+'\n')
        print('Bookkeeping parent resumed:', parent, flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('parent', type=int)
    parser.add_argument('child', type=int)
    parser.add_argument('record', type=Path)
    args = parser.parse_args()
    run(args.parent, args.child, args.record)
