"""Preserve the current native result before reprioritizing an older controller.

New controllers read pause_after_current.json themselves. The first controller
was already running when that feature was added, so this compatibility helper
waits for its result.json and then signals only its verified PID. A possible
next-job startup is retained as interrupted evidence, never accepted as output.
"""
import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import signal
import subprocess
import time
from run_panel import sha, write


def main(configuration, after):
    base=configuration.resolve().parent
    config=json.loads(configuration.read_text())
    panel=base/config['panel_directory']
    state=json.loads((panel/'status.json').read_text())
    pid=state['pid']
    if after not in {j['directory'] for j in config['pilots']}:
        raise ValueError('Boundary job is not part of this panel')
    def identity():
        proc=subprocess.run(['ps','-p',str(pid),'-o','command='],capture_output=True,text=True)
        if proc.returncode:
            return False
        if 'run_panel.py' not in proc.stdout or configuration.name not in proc.stdout:
            raise RuntimeError('Controller PID identity changed; refusing to signal')
        return True
    if state['configuration_sha256']!=sha(configuration):
        raise ValueError('Controller configuration differs from the current file')
    write(panel/'pause_after_current.json',{'reason':'Prioritize optimized-fragment geometry and correction-potential validation',
          'after_job':after,'requested_utc':datetime.now(timezone.utc).isoformat()})
    print('Waiting to preserve completed boundary job:',after,flush=True)
    result=base/after/'result.json'
    while not result.exists():
        if not identity():
            raise RuntimeError('Controller exited before the boundary result was recorded')
        time.sleep(0.1)
    if identity():
        os.kill(pid,signal.SIGTERM)
    deadline=time.monotonic()+45
    while identity() and time.monotonic()<deadline:
        time.sleep(0.1)
    if identity():
        raise RuntimeError('Controller did not exit; no outputs modified')
    state=json.loads((panel/'status.json').read_text())
    state['paused_after_job']=after
    state['pause_reason']='Prioritize geometry foundation; boundary result preserved'
    state['pause_recorded_utc']=datetime.now(timezone.utc).isoformat()
    for name,entry in state['jobs'].items():
        if entry.get('status')=='running' and not (base/name/'result.json').exists():
            entry.update(status='interrupted_for_reprioritization')
            p=base/name/'execution.json'
            if p.exists():
                record=json.loads(p.read_text())
                record.update(status='interrupted_for_reprioritization',interrupted_utc=state['pause_recorded_utc'])
                write(p,record)
    write(panel/'status.json',state)
    print('Controller paused; boundary result and all earlier evidence preserved.',flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('configuration',type=Path);parser.add_argument('--after-job',required=True)
    args=parser.parse_args();main(args.configuration,args.after_job)
