"""Plot discrete native spectra; connecting lines are visual guides only."""
import argparse
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

from kinbot.constants import AUtoKCAL
from run_panel import sha, write


def plot(source):
    source = source.resolve()
    data = json.loads(source.read_text())
    rows = {r['directory']: r for r in data['observations']}
    channels = list(dict.fromkeys(r['channel'] for r in data['observations']))
    labels = {c['id']: c['label'] for c in json.loads(
        (source.parents[2] / 'plot_evidence_recipe.json').read_text())['channels']}
    fig, axes = plt.subplots(2, len(channels), figsize=(12, 7), sharex='col')
    series = []
    for column, channel in enumerate(channels):
        cases = [p for p in data['path_definitions']
                 if rows.get(p['asymptote'], {}).get('channel') == channel]
        for i, case in enumerate(cases):
            far = rows.get(case['asymptote'])
            if far is None:
                continue
            zero = min(s['energy_hartree'] for s in far['states'])
            points = []
            for name in case['path']:
                if name not in rows:
                    continue
                row = rows[name]
                a, b = case['bond_0based']
                xyz = row['geometry_angstrom']
                distance = sum((xyz[a][k]-xyz[b][k])**2 for k in (1, 2, 3))**.5
                low = {m: min(s['energy_hartree'] for s in row['states']
                              if s['multiplicity'] == m) for m in (2, 4)}
                points.append({'directory': name, 'distance_angstrom': distance,
                    'doublet_interaction_kcal_mol': (low[2]-zero)*AUtoKCAL,
                    'quartet_interaction_kcal_mol': (low[4]-zero)*AUtoKCAL,
                    'doublet_minus_quartet_kcal_mol': (low[2]-low[4])*AUtoKCAL})
            # The 30 A common zero is declared above; showing it on the same
            # linear axis would obscure the interaction-region diagnostics.
            visible = sorted((p for p in points if p['distance_angstrom'] < 10),
                             key=lambda p: p['distance_angstrom'])
            x = [p['distance_angstrom'] for p in visible]
            label = 'CAS' + str(tuple(far['active_space']))
            color = ('#1565a6', '#b45f06', '#727272')[i % 3]
            for ax, key in zip(axes[:, column],
                    ('doublet_interaction_kcal_mol', 'doublet_minus_quartet_kcal_mol')):
                ax.plot(x, [p[key] for p in visible], 'o--', color=color,
                        markersize=5, linewidth=1.2, label=label)
            series.append({'case': case['id'], 'zero_hartree': zero, 'points': points})
        axes[0, column].set_title(labels.get(channel, channel))
        axes[0, column].legend(frameon=False, fontsize=9)
        axes[1, column].set_xlabel('Bond separation (Å)')
        for ax in axes[:, column]:
            ax.axhline(0, color='#aaaaaa', linewidth=.7)
            ax.grid(alpha=.15)
            ax.spines[['top', 'right']].set_visible(False)
    axes[0, 0].set_ylabel('Lowest doublet interaction\n(kcal/mol)')
    axes[1, 0].set_ylabel('Lowest doublet − quartet gap\n(kcal/mol)')
    fig.suptitle('ORCA CASPT2: discrete rigid-fragment checks', fontsize=15)
    fig.text(.5, .035, 'Conventional FIC-CASPT2 / aug-cc-pVTZ-F12 orbital basis; shift 0.3 Eh, IPEA 0.\n'
             'One 30 Å zero per model. Dashed lines guide the eye; ranked roots do not establish state tracking.',
             ha='center', fontsize=9)
    fig.tight_layout(rect=(0, .08, 1, .95))
    for extension in ('png', 'pdf'):
        fig.savefig(source.parent / ('radial_checks.' + extension), dpi=180)
    plt.close(fig)
    write(source.parent / 'plotted_values.json', {'source_sha256': sha(source), 'series': series})


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('source', type=Path)
    plot(p.parse_args().source)
