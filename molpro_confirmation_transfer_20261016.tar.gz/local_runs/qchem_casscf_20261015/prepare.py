"""Prepare two local diagnostic jobs, preserving the archived Molpro AO span."""
from pathlib import Path
import json
import re
import xml.etree.ElementTree as ET
import numpy as np

root = Path(__file__).resolve().parent
ns = {'m': 'http://www.molpro.net/schema/molpro-output'}
r = ET.parse(root / 'basis/molpro_source.xml').getroot()
b = next(e for e in r.iter() if e.tag.endswith('basisSet'))
atoms = {e.attrib['id']: e.attrib['elementType'] for e in r.iter() if e.tag.endswith('}atom')}
groups = {e.attrib['id']: e for e in b.findall('m:basisGroup', ns)}
archived = {}
for assoc in b.findall('m:association', ns):
    ah = assoc.find('m:atoms', ns).attrib['{http://www.w3.org/1999/xlink}href']
    bh = assoc.find('m:bases', ns).attrib['{http://www.w3.org/1999/xlink}href']
    symbol = atoms[re.findall(r"@id='([^']+)'", ah)[-1]]
    shells = []
    for gid in re.findall(r"@id='([^']+)'", bh)[1:]:
        g = groups[gid]
        l = int(g.attrib['minL'])
        assert l == int(g.attrib['maxL'])
        exps = list(map(float, g.find('m:basisExponents', ns).text.split()))
        for c in g.findall('m:basisContraction', ns):
            pairs = [(e, float(v)) for e, v in zip(exps, c.text.split()) if float(v)]
            shells.append((l, pairs))
    if symbol in archived:
        assert archived[symbol] == shells
    archived[symbol] = shells

bse = json.loads((root / 'basis/cc-pvtz-f12.json').read_text())
per, extra, residual = {}, {}, {}
for z, symbol in [('1', 'H'), ('6', 'C'), ('16', 'S')]:
    base = []
    for shell in bse['elements'][z]['electron_shells']:
        assert len(shell['angular_momentum']) == 1
        l = shell['angular_momentum'][0]
        for c in shell['coefficients']:
            base.append((l, [(float(e), float(v)) for e, v in zip(shell['exponents'], c) if float(v)]))
    extra[symbol] = []
    for l, pairs in archived[symbol]:
        base_exp = {e for ll, pp in base if ll == l for e, _ in pp}
        if any(e not in base_exp for e, _ in pairs):
            assert len(pairs) == 1 and pairs[0][1] == 1
            extra[symbol].append((l, pairs))
    per[symbol] = base + extra[symbol]
    residual[symbol] = {}
    # BSE removes redundant primitives from contractions. Verify equal spans,
    # rather than requiring the contraction columns themselves to be identical.
    for l in {l for l, _ in archived[symbol]}:
        exps = sorted({e for ll, pp in archived[symbol] if ll == l for e, _ in pp})
        def matrix(shells):
            return np.array([[dict(pp).get(e, 0) for ll, pp in shells if ll == l] for e in exps])
        a, c = matrix(archived[symbol]), matrix(per[symbol])
        assert a.shape == c.shape
        err = max(np.max(np.abs(a @ np.linalg.lstsq(a, c, rcond=None)[0] - c)),
                  np.max(np.abs(c @ np.linalg.lstsq(c, a, rcond=None)[0] - a)))
        assert err < 1e-6, (symbol, l, err)
        residual[symbol][l] = float(err)
    # Retain the archived normalized coefficients exactly; BSE and Molpro
    # differ slightly in published coefficient rounding for sulfur.
    per[symbol] = archived[symbol]

q, o, counts = ['$basis'], ['%basis'], {}
for symbol, shells in per.items():
    q += [symbol + ' 0']
    o += ['  NewGTO ' + symbol]
    counts[symbol] = sum(2*l+1 for l, _ in shells)
    for l, pairs in shells:
        letter = 'SPDFGHI'[l]
        q.append(f'{letter} {len(pairs)} 1.00')
        o.append(f'    {letter} {len(pairs)}')
        for i, (e, c) in enumerate(pairs, 1):
            q.append(f'  {e:.15E} {c:.15E}')
            o.append(f'      {i} {e:.15E} {c:.15E}')
    q.append('****')
    o.append('  end')
q.append('$end')
o.append('end')
qb, ob = '\n'.join(q)+'\n', '\n'.join(o)+'\n'
(root/'basis/aug-cc-pvtz-f12.qchem').write_text(qb)
(root/'basis/aug-cc-pvtz-f12.orca').write_text(ob)
(root/'basis/provenance.json').write_text(json.dumps({
    'archive': 'examples/anl/orbital_reviews/ch3s_ch3ss_potential_validation_20261015.tar.gz',
    'member': '01_pilot/avt_f12__ch3s_cs_cas5_4_center/avt_f12__ch3s_cs_cas5_4_center.natural.orbitals.xml',
    'basis': 'aug-cc-pVTZ-F12', 'base_source': 'https://www.basissetexchange.org/api/basis/cc-pvtz-f12/format/json/?elements=1,6,16',
    'spherical_functions': counts, 'additional_shells': extra, 'span_verification_max_residuals': residual,
}, indent=2)+'\n')

geom1 = '''C -0.133435350000 -0.003555070000 0.001446090000
S 2.965283162891 0.079002940861 -0.032135939594
H -0.785766935826 0.035832642360 -0.895037168904
H -0.759266069809 0.040577529302 0.916409676462
H 0.564675178834 0.858568041327 -0.011025289378'''
geom2 = '''C -0.557524560609 0.017625036865 -0.155670953070
S 0.910423350000 1.087817860000 -0.090958450000
S 3.256779022365 -1.740495978896 0.339455173700
H -0.257044670025 -1.046496732082 -0.058118921401
H -1.260461301114 0.286414476777 0.660288783683
H -1.067114679199 0.159524122154 -1.130700350150'''
d1, d2 = root/'01_qchem_ch3s_cas13_8', root/'02_orca_ch3ss_ss_cas13_9'
for d in (d1, d2):
    d.mkdir(exist_ok=True)
(d1/'input.inp').write_text(f'''$comment
Local state-specific ground-doublet CASSCF diagnostic. Fresh ROHF orbitals.
Same AO basis span as archived Molpro; not the mixed-spin state average.
$end
$molecule
0 2
{geom1}
$end
$rem
JOBTYPE SP
EXCHANGE HF
BASIS GEN
PURECART 1111
CAS_METHOD 2
CAS_M_S 1
CAS_N_ELEC 13
CAS_N_ORB 8
CAS_N_ROOTS 1
CAS_SOLVER 0
CAS_DAVIDSON_TOL 9
ASCI_DIAG 2
CAS_SAVE_NAT_ORBS TRUE
MAX_CASSCF_CYCLES 2000
MAX_SCF_CYCLES 2000
SCF_CONVERGENCE 6
THRESH 12
MEM_TOTAL 8000
MEM_STATIC 1000
ROSCF TRUE
INTEGRAL_SYMMETRY FALSE
POINT_GROUP_SYMMETRY FALSE
SCF_ALGORITHM DIIS_GDM
MOLDEN_FORMAT TRUE
$end
\n'''+qb)
(d2/'input.inp').write_text(f'''# Local SA-CASSCF diagnostic: same geometry/basis/CAS/root weights as Molpro.
# Fresh orbitals; optimized active-orbital character must still be checked.
! CASSCF TightSCF NoSym
%pal nprocs 14 end
%maxcore 600
%scf MaxIter 2000 end
%casscf
  nel 13
  norb 9
  mult 2,4
  nroots 6,6
  bweight 1,1
  MaxIter 2000
  ETol 1e-8
  GTol 1e-5
  SwitchDens 0.0
  ci
    MaxIter 2000
    ETol 1e-9
    RTol 1e-8
  end
end
'''+ob+f'\n* xyz 0 2\n{geom2}\n*\n')
assert counts['C'] + counts['S'] + 3*counts['H'] == 217
assert counts['C'] + 2*counts['S'] + 3*counts['H'] == 291
print('Prepared:', d1, d2, '\nBasis counts:', counts, '\nSpan check:', residual)
