"""Prepare a finite, question-driven VRC comparison from explicit JSON data.

Reference cuts, symmetry operations, candidates and oriented points are data.
This builder neither chooses a point group nor identifies a minimum-energy path.
"""
import argparse
from copy import deepcopy
import json
from pathlib import Path
import numpy as np
from kinbot.orbital_geometry import audit_symmetry
from run_panel import sha, write
from transport_seed import transport


def prepare(specification):
    base = specification.resolve().parent
    spec = json.loads(specification.read_text())
    if spec.get('analysis_only'):
        raise ValueError('An analysis-only comparison is not a calculation recipe')
    source = json.loads((base/spec['source_settings']).read_text())
    config = deepcopy(source)
    config.update(spec['execution'])
    config['pilots'] = []
    config['purpose'] = spec['purpose']
    for channel in spec['channels']:
        geometry = channel['reference_geometry_angstrom']
        symbols = [r[0] for r in geometry]
        xyz = np.array([r[1:] for r in geometry])
        a, b = channel['bond_0based']
        fragments = channel['fragments_0based']
        if (sorted(i for f in fragments for i in f) != list(range(len(xyz)))
                or len(fragments) != 2 or a not in fragments[0] or b not in fragments[1]):
            raise ValueError('Ordered fragments must partition atoms and contain the bond endpoints')
        direction = xyz[b]-xyz[a]
        distance = np.linalg.norm(direction)
        if distance <= 0:
            raise ValueError('Invalid reference separation')
        direction /= distance
        proof = audit_symmetry(symbols, xyz, channel['symmetry_operations'], 1.e-8)
        if not proof['passed']:
            raise ValueError('Reference cut fails its declared geometry symmetry')
        prototypes = [j for j in source['pilots'] if j['channel'] == channel['id']
                      and j['point'] == 'far' and
                      [j['active_electrons'], j['active_orbitals']] in channel['candidate_spaces']]
        if len(prototypes) != len(channel['candidate_spaces']):
            raise ValueError('Candidate definitions are missing or duplicated')
        for old in prototypes:
            prefix = f"{channel['id']}_cas{old['active_electrons']}_{old['active_orbitals']}"
            seen = set()
            for point in channel['points']:
                label = point['label']
                if label in seen or not label.replace('_','').isalnum():
                    raise ValueError('Point labels must be unique safe names')
                target_distance = point['distance_angstrom']
                if not np.isfinite(target_distance) or target_distance <= 0:
                    raise ValueError('Positive finite separation required')
                new = xyz.copy()
                new[fragments[1]] += (target_distance-distance)*direction
                if point.get('rotation'):
                    rotation = point['rotation']
                    ids = fragments[rotation['fragment']]
                    pivot = a if rotation['fragment'] == 0 else b
                    axis = np.asarray(rotation['axis'], dtype=float)
                    if axis.shape != (3,) or not np.isfinite(axis).all() or np.linalg.norm(axis) < 1.e-12:
                        raise ValueError('Invalid rotation axis')
                    axis /= np.linalg.norm(axis)
                    angle = np.deg2rad(rotation['degrees'])
                    v = new[ids]-new[pivot]
                    new[ids] = (v*np.cos(angle)+np.cross(axis,v)*np.sin(angle)
                        + np.outer(v@axis,axis)*(1-np.cos(angle))) + new[pivot]
                if abs(np.linalg.norm(new[b]-new[a])-target_distance)>1.e-8:
                    raise ValueError('Orientation operation changed the reaction coordinate')
                for ids in fragments:
                    if not np.allclose(np.linalg.norm(new[ids,None]-new[ids][None,:],axis=2),
                                       np.linalg.norm(xyz[ids,None]-xyz[ids][None,:],axis=2),atol=1.e-9,rtol=0):
                        raise ValueError('Rigid-fragment operation changed internal geometry')
                directory = base/config['panel_directory']/(prefix+'_'+label)
                job = deepcopy(old)
                for key in ('transport_from_job','processes','maxcore_mb_per_process'):
                    job.pop(key,None)
                job.update(directory=str(directory.relative_to(base)),point=label,
                    geometry_angstrom=[[s,*v.tolist()] for s,v in zip(symbols,new)],
                    fragments_0based=fragments, initial_orbitals=str((directory/'seed/seed_copy.gbw').relative_to(base)),
                    initial_orbitals_validation=str((directory/'seed/seed.validation.json').relative_to(base)),
                    geometry_specification_sha256=sha(specification), geometry_provenance=channel['geometry_provenance'],
                    test_purpose=point['purpose'], reference_cut_is_mep=False,
                    expected_frozen_core_orbitals=len(old['seed_core_orbitals']))
                if not point.get('rotation'):
                    job['geometry_symmetry_audit'] = audit_symmetry(symbols,new,channel['symmetry_operations'],1.e-8)
                    if not job['geometry_symmetry_audit']['passed']:
                        raise ValueError('Radial translation violated declared reference symmetry')
                else:
                    job['geometry_symmetry_audit'] = {'role':'deliberate off-axis test','point_group_enforced':False}
                predecessor = point.get('seed_from')
                if predecessor:
                    if predecessor not in seen:
                        raise ValueError('Orbital predecessor must be an earlier point')
                    job['transport_from_job'] = str(Path(config['panel_directory'])/(prefix+'_'+predecessor))
                else:
                    seed = (base/old['initial_orbitals']).with_suffix('.json')
                    if not (directory/'seed/seed_copy.gbw').exists():
                        transport(seed,job['geometry_angstrom'],[[i] for i in range(len(symbols))],
                                  len(old['seed_core_orbitals']),old['inactive_orbitals'],old['active_orbitals'],
                                  directory/'seed',str(Path(config['executable']).with_name('orca_2json')))
                    job['initialization_note'] = 'Atom-centered transport for small geometry edits; not a cross-geometry wavefunction overlap.'
                seen.add(label)
                config['pilots'].append(job)
    from run_parallel_panel import chains
    chains(config)
    path = base/spec['output_settings']
    if path.exists() and json.loads(path.read_text()) != config:
        raise RuntimeError('Refusing to replace an existing calculation specification')
    write(path,config)
    return path


if __name__ == '__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('specification',type=Path)
    p.add_argument('--run',action='store_true')
    a=p.parse_args(); path=prepare(a.specification); print('Prepared:',path,flush=True)
    if a.run:
        from run_parallel_panel import run
        run(path,wait=True)
