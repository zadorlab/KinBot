"""Render one local pilot from JSON, refusing to overwrite a different input.

This is a diagnostic input builder, not an active-space selection algorithm.
"""
import argparse
import json
import math
from pathlib import Path
from ase.data import atomic_numbers


def render(config, job, base):
    solver = dict(config['solver'], **job.get('solver', {}))
    ne, no = job['active_electrons'], job['active_orbitals']
    if any(len(row)!=4 or row[0] not in atomic_numbers or
           any(not math.isfinite(x) for x in row[1:]) for row in job['geometry_angstrom']):
        raise ValueError('Invalid atomic symbols or coordinates')
    total=sum(atomic_numbers[row[0]] for row in job['geometry_angstrom'])-job['charge']
    if total != 2*job['inactive_orbitals']+ne:
        raise ValueError('Inactive and active electron counts do not match the molecular charge')
    if not 0 < ne <= 2 * no:
        raise ValueError('Invalid active electron/orbital count')
    if not (len(job['multiplicities']) == len(job['roots']) == len(job['block_weights'])):
        raise ValueError('Spin blocks, roots and block weights must match')
    if any((ne - (m - 1)) % 2 or not 0 <= m - 1 <= min(ne, 2*no-ne)
           for m in job['multiplicities']):
        raise ValueError('Spin incompatible with active space')
    iterations = int(solver['max_iterations'])
    if iterations < 1 or any(x < 1 for x in job['roots']):
        raise ValueError('Iteration and root counts must be positive')
    for key in ('casscf_energy_hartree', 'casscf_gradient', 'ci_energy_hartree', 'ci_residual'):
        if not 0 < solver[key] < 1:
            raise ValueError('Invalid convergence threshold: ' + key)
    steps = {'SuperCI_PT', 'TRAH', 'SuperCI', 'DIIS', 'KDIIS', 'SOSCF', 'NR'}
    if solver['orbital_step'] not in steps or solver['switch_step'] not in steps:
        raise ValueError('Unknown orbital optimizer')
    def csv(values):
        return ','.join(str(x) for x in values)
    lines = ['# Generated from orca_settings.json; chemical orbital character requires review.',
             '! CASSCF TightSCF NoSym',
             f"%pal nprocs {int(job.get('processes', config['processes']))} end",
             f"%maxcore {int(job.get('maxcore_mb_per_process', config['maxcore_mb_per_process']))}"]
    if job.get('export_orbitals'):
        lines += ['%output', '  Print[P_ReducedOrbPopMO_L] 1', '  JSONGBWFile true', 'end']
    if job.get('initial_orbitals'):
        checkpoint = (base / job['initial_orbitals']).resolve()
        if not checkpoint.is_file():
            raise FileNotFoundError(checkpoint)
        lines += ['! MOREAD', f'%moinp "{checkpoint}"']
    lines += [f'%scf MaxIter {iterations} end', '%casscf',
              f'  nel {ne}', f'  norb {no}',
              '  mult ' + csv(job['multiplicities']),
              '  nroots ' + csv(job['roots']),
              '  bweight ' + csv(job['block_weights']),
              f'  MaxIter {iterations}',
              f"  ETol {solver['casscf_energy_hartree']:.12g}",
              f"  GTol {solver['casscf_gradient']:.12g}",
              f"  OrbStep {solver['orbital_step']}",
              f"  SwitchStep {solver['switch_step']}",
              f"  SwitchDens {solver['switch_density']:.12g}",
              '  ci', f'    MaxIter {iterations}',
              f"    ETol {solver['ci_energy_hartree']:.12g}",
              f"    RTol {solver['ci_residual']:.12g}", '  end']
    if 'switch_gradient' in solver:
        lines.append(f"  SwitchConv {solver['switch_gradient']:.12g}")
    if job['stage'] == 'CASSCF+CASPT2':
        pt = dict(config['correlation'], **job.get('correlation', {}))
        if pt['method'] != 'FIC_CASPT2' or pt.get('f12'):
            raise ValueError('This pilot renderer supports conventional FIC_CASPT2 only')
        lines += ['  PTMethod FIC_CASPT2', '  PTSettings',
                  f"    CASPT2_rshift {pt['real_shift']:.12g}",
                  f"    CASPT2_IPEAshift {pt['ipea_shift']:.12g}",
                  f'    MaxIter {iterations}']
        for key, keyword in [('norm_threshold', 'NThresh'), ('density3_truncation', 'D3TPre'),
                             ('density4_truncation', 'D4TPre')]:
            if key in pt:
                if not 0 < pt[key] < 1:
                    raise ValueError('Invalid CASPT2 threshold: ' + key)
                lines.append(f'    {keyword} {pt[key]:.12g}')
        lines.append('  end')
    elif job['stage'] != 'CASSCF':
        raise ValueError('Unknown stage')
    lines += ['end', (base/config['basis_file']).read_text().rstrip(),
              f"* xyz {job['charge']} {job['multiplicities'][0]}"]
    for symbol, *xyz in job['geometry_angstrom']:
        if len(xyz) != 3 or not symbol.isalpha():
            raise ValueError('Invalid geometry')
        lines.append(symbol + ' ' + ' '.join(f'{x:.12f}' for x in xyz))
    return '\n'.join(lines + ['*', ''])


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('configuration', type=Path)
    parser.add_argument('directory', help='Exact pilot directory listed in configuration')
    parser.add_argument('--output-name', default='input.inp')
    args = parser.parse_args()
    base = args.configuration.resolve().parent
    config = json.loads(args.configuration.read_text())
    matches = [j for j in config['pilots'] if j['directory'] == args.directory]
    if len(matches) != 1:
        parser.error('Expected exactly one matching pilot')
    text = render(config, matches[0], base)
    directory = base/args.directory
    directory.mkdir(parents=True, exist_ok=True)
    target = directory/args.output_name
    if target.exists() and target.read_text() != text:
        parser.error(f'Refusing to overwrite {target}; archive the previous input first')
    target.write_text(text)
    if matches[0].get('export_orbitals'):
        (directory/(target.stem+'.json.conf')).write_text(json.dumps({
            'MOCoefficients': True, 'Basisset': True,
            '1elIntegrals': ['S'], 'JSONFormats': ['json']}, indent=2)+'\n')
    print(target)
