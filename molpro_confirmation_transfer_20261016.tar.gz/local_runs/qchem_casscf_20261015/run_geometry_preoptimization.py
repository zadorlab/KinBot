"""Run isolated-fragment DFT optimizations as provisional geometry seeds.

All chemistry and numerical settings are explicit JSON data. These jobs cannot
approve a CAS, a correlated equilibrium geometry, or a production potential.
Their execution lock is specified in JSON; all native attempts are preserved.
"""
import argparse
import fcntl
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import time
from datetime import datetime, timezone
from run_panel import sha, write


def render(config, job, base):
    options = config['numerics']
    lines = ['# Provisional isolated-fragment geometry; correlated validation required.',
             '! UKS ' + config['functional'] + ' NORI TightSCF TightOpt Freq NoSym DEFGRID3',
             f"%pal nprocs {config['processes']} end",
             f"%maxcore {config['maxcore_mb_per_process']}",
             f"%scf MaxIter {options['scf_max_iterations']} end", '%geom',
             f"  MaxIter {options['geometry_max_iterations']}"]
    for key, native in [('energy_hartree','TolE'), ('rms_gradient','TolRMSG'),
                        ('maximum_gradient','TolMaxG'), ('rms_step','TolRMSD'),
                        ('maximum_step','TolMaxD')]:
        if not 0 < options[key] < 1:
            raise ValueError(key)
        lines.append(f'  {native} {options[key]:.12g}')
    lines += ['end', (base/config['basis_file']).read_text().rstrip(),
              f"* xyz {job['charge']} {job['multiplicity']}"]
    lines += [s+' '+' '.join(f'{x:.12f}' for x in xyz) for s,*xyz in job['geometry_angstrom']]
    return '\n'.join(lines+['*',''])


def review(directory, job, code, config):
    text = (directory/'geometry.out').read_text(errors='replace')
    frequencies = [float(v) for v in re.findall(r'^\s*\d+:\s+(-?\d+\.\d+)\s+cm\*\*-1', text, re.M)]
    expected = 3*len(job['geometry_angstrom'])
    errors = []
    if code != 0 or 'ORCA TERMINATED NORMALLY' not in text:
        errors.append('Abnormal native termination')
    if 'THE OPTIMIZATION HAS CONVERGED' not in text:
        errors.append('Nuclear optimization convergence not confirmed')
    if not (directory/'geometry.xyz').is_file():
        errors.append('Optimized geometry missing')
    if len(frequencies) != expected:
        errors.append('Complete frequency spectrum not found')
    if any(v < -config['imaginary_frequency_review_threshold_cm_inverse'] for v in frequencies):
        errors.append('Imaginary frequency requires review')
    energies = re.findall(r'FINAL SINGLE POINT ENERGY\s+(-?\d+\.\d+)', text)
    spin = re.findall(r'Expectation value of <S\*\*2>\s*:?\s*([\d.]+)', text)
    return {'preoptimization_completed': not errors, 'errors': errors,
            'frequencies_cm_inverse': frequencies,
            'final_energy_hartree': float(energies[-1]) if energies else None,
            'last_spin_squared': float(spin[-1]) if spin else None,
            'correlated_geometry_accepted': False, 'production_selection_accepted': False}


def run(path, prepare_only=False):
    base = path.resolve().parent
    config = json.loads(path.read_text())
    # Prepare every exact input before waiting for resources.
    for job in config['jobs']:
        directory = base/job['directory']; directory.mkdir(parents=True,exist_ok=True)
        inp = directory/'geometry.inp'; text = render(config,job,base)
        if inp.exists() and inp.read_text() != text:
            raise RuntimeError(f'Refusing to change existing input: {inp}')
        inp.write_text(text)
    if prepare_only:
        return
    lock = (base/config['execution_lock']).open('a')
    print('Waiting for exclusive energy/geometry execution lock', flush=True)
    fcntl.flock(lock, fcntl.LOCK_EX)
    environment = dict(os.environ)
    environment.update(PATH=config['mpi_bin']+os.pathsep+environment['PATH'],
                       OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', VECLIB_MAXIMUM_THREADS='1')
    child = None

    def stop(signum, frame):
        if child is not None and child.poll() is None:
            os.killpg(child.pid,signal.SIGTERM)
            try:
                child.wait(timeout=30)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid,signal.SIGKILL);child.wait()
        raise SystemExit(128+signum)

    signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
    for job in config['jobs']:
        directory=base/job['directory']; output=directory/'geometry.out'; metadata=directory/'execution.json'
        if output.exists():
            record=json.loads(metadata.read_text()) if metadata.exists() else {}
            result=review(directory,job,record.get('returncode'),config)
            if (record.get('status')!='complete'
                    or record.get('input_sha256')!=sha(directory/'geometry.inp')
                    or record.get('basis_sha256')!=sha(base/config['basis_file'])):
                result['errors'].append('Existing execution record is incomplete or has different provenance')
                result['preoptimization_completed']=False
            write(directory/'result.json',result)
            print('Preserved and reviewed existing geometry output:',directory,result['errors'],flush=True)
            continue
        command=[config['executable'],'geometry.inp']
        record={'status':'running','command':command,'configuration_sha256':sha(path),
                'input_sha256':sha(directory/'geometry.inp'),'basis_sha256':sha(base/config['basis_file']),
                'started_utc':datetime.now(timezone.utc).isoformat(),'preoptimization_only':True}
        started=time.monotonic()
        for attempt in range(1,config['io_retries']+2):
            record['attempt']=attempt;write(metadata,record)
            print('RUNNING',job['directory'],'attempt',attempt,flush=True)
            with output.open('x') as out,(directory/'geometry.launcher.stderr').open('x') as err:
                child=subprocess.Popen(command,cwd=directory,env=environment,stdout=out,stderr=err,start_new_session=True)
                record['pid']=child.pid;write(metadata,record);code=child.wait()
            child=None
            messages=output.read_text(errors='replace')+(directory/'geometry.launcher.stderr').read_text(errors='replace')
            if not re.search(r'Input/output error|Stale file handle|Transport endpoint is not connected',messages,re.I) or attempt>config['io_retries']:
                break
            record.update(status='retryable_io',returncode=code);write(metadata,record)
            archive=directory/'attempts'/str(attempt);archive.mkdir(parents=True)
            for artifact in list(directory.iterdir()):
                if artifact.is_file() and artifact.name!='geometry.inp':
                    shutil.move(str(artifact),archive/artifact.name)
            record['status']='running'
        result=review(directory,job,code,config)
        record.update(status='complete' if result['preoptimization_completed'] else 'needs_review',
                      returncode=code,elapsed_seconds=time.monotonic()-started,
                      ended_utc=datetime.now(timezone.utc).isoformat())
        write(metadata,record);write(directory/'result.json',result)
        print(job['directory'],record['status'],result['errors'],flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('configuration',type=Path)
    parser.add_argument('--prepare-only',action='store_true')
    args=parser.parse_args();run(args.configuration,args.prepare_only)
