"""Sequential native ORCA panel with immutable attempts and explicit acceptance.

All chemistry, executable paths, resources and solver controls come from JSON.
Numerical acceptance does not certify the chemical active space or a PES.
"""
import argparse
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import shutil
import subprocess
import time

# Set limits before audit_orca imports numpy. Limiting only subprocess env
# leaves the controller's BLAS pool free to compete with native MPI ranks.
for _thread_variable in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS',
                         'VECLIB_MAXIMUM_THREADS'):
    os.environ[_thread_variable] = '1'

from audit_orca import audit, audit_orbitals, core_projection, active_subspace_overlap
from render_orca import render


def write(path, payload):
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(payload, indent=2) + '\n')
    temporary.replace(path)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def acceptance(result, job, solver):
    errors = []
    expected = {(m, r) for m, n in zip(job['multiplicities'], job['roots']) for r in range(n)}
    if not result['normal_termination']:
        errors.append('Native ORCA termination is incomplete or abnormal')
    if not result['casscf_native_converged']:
        errors.append('Native CASSCF convergence missing')
    if (result.get('native_active_electron_counts') != [job['active_electrons']]
            or result.get('native_active_orbital_counts') != [job['active_orbitals']]):
        errors.append('Native active-space definition does not match the requested space')
    if (job['stage']=='CASSCF+CASPT2' and 'expected_frozen_core_orbitals' in job
            and result.get('native_frozen_core_orbital_counts') != [job['expected_frozen_core_orbitals']]):
        errors.append('Native frozen-core definition differs from the requested validation count')
    gradient = result.get('final_printed_orbital_gradient')
    if gradient is None or gradient > solver['casscf_gradient']:
        errors.append(f'Orbital gradient {gradient} exceeds {solver["casscf_gradient"]}')
    actual = {(s['multiplicity'], s['root_0based']) for s in result['casscf_states']}
    if actual != expected or len(result['casscf_states']) != len(expected):
        errors.append('CASSCF root coverage mismatch')
    if job['stage'] == 'CASSCF+CASPT2':
        actual = {(s['multiplicity'], s['root_0based']) for s in result['caspt2_states']}
        if actual != expected or len(result['caspt2_states']) != len(expected):
            errors.append('CASPT2 root coverage mismatch')
        if result['caspt2_converged_root_count'] != len(expected) or result['caspt2_nonconvergence_messages']:
            errors.append('CASPT2 convergence not confirmed for every root')
    return errors


def finalize(config, job, base, record):
    """Use identical evidence requirements for a new result and a resumed result."""
    directory = base / job['directory']
    solver = dict(config['solver'], **job.get('solver', {}))
    result = audit(directory / 'panel.out')
    errors = acceptance(result, job, solver)
    if record.get('status') != 'complete' or record.get('returncode') != 0:
        errors.append('A complete execution record with return code zero is required')
    for key, path in [('input_sha256', directory / 'panel.inp'),
                      ('basis_sha256', base / config['basis_file'])]:
        if not path.is_file() or record.get(key) != sha(path):
            errors.append(f'Provenance mismatch: {key}')
    if (record.get('solver') != solver or
            record.get('correlation') != dict(config['correlation'], **job.get('correlation', {}))):
        errors.append('Execution settings differ from the requested configuration')
    seed = base / job['initial_orbitals'] if job.get('initial_orbitals') else None
    if seed and (not seed.is_file() or record.get('seed_sha256') != sha(seed)):
        errors.append('Provenance mismatch: seed_sha256')
    if job.get('initial_orbitals_validation'):
        proof_path = base / job['initial_orbitals_validation']
        proof = json.loads(proof_path.read_text()) if proof_path.exists() else {}
        if (proof.get('requires_native_overlap_validation') or
                proof.get('native_orthonormality_max_error', 1) > 1e-5 or
                proof.get('orca_gbw_sha256') != record.get('seed_sha256')):
            errors.append('Imported seed lacks a matching native overlap validation')
    orbital_path = directory / 'panel.json'
    if orbital_path.exists():
        try:
            result['orbital_audit'] = audit_orbitals(orbital_path, job['inactive_orbitals'], job['active_orbitals'])
            if result['orbital_audit']['orthonormality_max_error'] > 1e-6:
                errors.append('Exported MOs are not orthonormal')
            if job.get('seed_core_orbitals'):
                diagnostic = core_projection(orbital_path, seed.with_suffix('.json'),
                    job['seed_core_orbitals'], job['inactive_orbitals'], job['active_orbitals'])
                result['active_core_projection'] = diagnostic
                if diagnostic['maximum_subspace_projection'] > config['maximum_active_core_projection']:
                    errors.append('Active space contains substantial seed-core character')
            if seed and job.get('initial_orbitals_validation'):
                result['active_subspace_overlap'] = active_subspace_overlap(
                    orbital_path, seed.with_suffix('.json'), job['inactive_orbitals'], job['active_orbitals'])
        except (ValueError, KeyError, OSError) as exc:
            errors.append(f'Orbital validation failed: {exc}')
    elif job.get('export_orbitals'):
        errors.append('Requested orbital export missing')
    result.update(numerically_accepted=not errors, errors=errors, chemical_selection_accepted=False,
                  input_sha256=record.get('input_sha256'), elapsed_seconds=record.get('elapsed_seconds'))
    return result


def run(config_path, only=None, wait=False):
    base = config_path.resolve().parent
    config = json.loads(config_path.read_text())
    if config.get('analysis_only'):
        raise ValueError('An analysis-only catalog cannot launch native jobs')
    panel = base / config['panel_directory']
    panel.mkdir(exist_ok=True)
    lock_path = base / config.get('execution_lock', str(panel / 'controller.lock'))
    lock = lock_path.open('a')
    if wait:
        print('Waiting for exclusive execution lock:', lock_path, flush=True)
    fcntl.flock(lock, fcntl.LOCK_EX | (0 if wait else fcntl.LOCK_NB))
    child = None

    def stop(signum, frame):
        if child is not None and child.poll() is None:
            os.killpg(child.pid, signal.SIGTERM)
            try:
                child.wait(timeout=30)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                child.wait()
        raise SystemExit(128 + signum)

    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    environment = dict(os.environ)
    environment['PATH'] = config['mpi_bin'] + os.pathsep + environment['PATH']
    environment['OMP_NUM_THREADS'] = '1'
    environment['OPENBLAS_NUM_THREADS'] = '1'
    environment['VECLIB_MAXIMUM_THREADS'] = '1'
    status = {'started_utc': datetime.now(timezone.utc).isoformat(), 'pid': os.getpid(),
              'configuration_sha256': sha(config_path), 'jobs': {}}
    write(panel / 'status.json', status)
    for job in config['pilots']:
        if only and job['directory'] not in only:
            continue
        name = job['directory']
        directory = base / name
        directory.mkdir(parents=True, exist_ok=True)
        state = status['jobs'][name] = {}
        solver = dict(config['solver'], **job.get('solver', {}))
        if job.get('transport_from_job'):
            source = base / job['transport_from_job']
            source_result = source / 'result.json'
            if not source_result.exists() or not json.loads(source_result.read_text()).get('numerically_accepted'):
                state.update(status='waiting_for_accepted_seed', seed=str(source_result))
                write(panel / 'status.json', status)
                continue
            seed = base / job['initial_orbitals']
            if not seed.exists():
                from transport_seed import transport
                transport(source / 'panel.json', job['geometry_angstrom'], job['fragments_0based'],
                          len(job['seed_core_orbitals']), job['inactive_orbitals'], job['active_orbitals'],
                          seed.parent, str(Path(config['executable']).with_name('orca_2json')))
        if job.get('initial_orbitals') and not (base / job['initial_orbitals']).is_file():
            state.update(status='waiting_for_seed', seed=job['initial_orbitals'])
            write(panel / 'status.json', status)
            continue
        if job.get('seed_requires_accepted'):
            source = base / job['seed_requires_accepted'] / 'result.json'
            if not source.exists() or not json.loads(source.read_text()).get('numerically_accepted'):
                state.update(status='waiting_for_accepted_seed', seed=str(source))
                write(panel / 'status.json', status)
                continue
        text = render(config, job, base)
        input_path = directory / 'panel.inp'
        if input_path.exists() and input_path.read_text() != text:
            raise RuntimeError(f'Input differs: use a new directory: {input_path}')
        input_path.write_text(text)
        write(directory / 'panel.json.conf', {'MOCoefficients': True, 'Basisset': True,
                                             '1elIntegrals': ['S'], 'JSONFormats': ['json']})
        metadata = directory / 'execution.json'
        output = directory / 'panel.out'
        if metadata.exists() and json.loads(metadata.read_text()).get('input_sha256') != sha(input_path):
            raise RuntimeError(f'Execution input hash differs: {metadata}')
        if output.exists():
            # Never silently overwrite either successful or failed native evidence.
            record = json.loads(metadata.read_text()) if metadata.exists() else {}
            result = finalize(config, job, base, record)
            errors = result['errors']
            write(directory / 'result.json', result)
            state.update(status='existing_accepted' if not errors else 'existing_needs_review', errors=errors)
            write(panel / 'status.json', status)
            print(name, state['status'], flush=True)
            continue
        command = [config['executable'], input_path.name]
        record = {'status': 'running', 'command': command, 'input_sha256': sha(input_path),
                  'basis_sha256': sha(base / config['basis_file']), 'started_utc': datetime.now(timezone.utc).isoformat(),
                  'processes': job.get('processes', config['processes']), 'solver': solver,
                  'correlation': dict(config['correlation'], **job.get('correlation', {}))}
        if job.get('initial_orbitals'):
            record['seed_sha256'] = sha(base / job['initial_orbitals'])
        if job.get('initial_orbitals_validation'):
            proof = json.loads((base / job['initial_orbitals_validation']).read_text())
            if (proof.get('requires_native_overlap_validation') or proof.get('native_orthonormality_max_error', 1) > 1e-5
                    or proof.get('orca_gbw_sha256') != record['seed_sha256']):
                raise RuntimeError(f'Unvalidated or changed imported seed for {name}')
        state.update(status='running')
        write(panel / 'status.json', status)
        write(metadata, record)
        print(name, 'RUNNING', flush=True)
        started = time.monotonic()
        for attempt in range(1, config.get('io_retries', 0) + 2):
            record['attempt'] = attempt
            with output.open('x') as stdout, (directory / 'panel.launcher.stderr').open('x') as stderr:
                child = subprocess.Popen(command, cwd=directory, env=environment, stdout=stdout, stderr=stderr,
                                         start_new_session=True)
                record['pid'] = child.pid
                write(metadata, record)
                code = child.wait()
            child = None
            messages = output.read_text(errors='replace') + (directory / 'panel.launcher.stderr').read_text(errors='replace')
            io_failure = bool(re.search(r'Input/output error|Stale file handle|Transport endpoint is not connected', messages, re.I))
            if not io_failure or attempt > config.get('io_retries', 0):
                break
            record.update(status='retryable_io', returncode=code)
            write(metadata, record)
            archive = directory / 'attempts' / str(attempt)
            archive.mkdir(parents=True, exist_ok=False)
            for artifact in list(directory.iterdir()):
                if artifact.is_file() and artifact.name not in ('panel.inp', 'panel.json.conf'):
                    shutil.move(str(artifact), archive / artifact.name)
            print(name, f'I/O retry {attempt}/{config["io_retries"]}; previous files in {archive}', flush=True)
            record['status'] = 'running'
        native = audit(output)
        record.update(returncode=code, elapsed_seconds=time.monotonic() - started,
                      status='complete' if code == 0 and native['normal_termination'] else 'failed',
                      ended_utc=datetime.now(timezone.utc).isoformat())
        write(metadata, record)
        result = finalize(config, job, base, record)
        errors = result['errors']
        write(directory / 'result.json', result)
        state.update(status='numerically_accepted' if not errors else 'needs_review', errors=errors,
                     elapsed_seconds=record['elapsed_seconds'])
        write(panel / 'status.json', status)
        print(name, state['status'], errors, flush=True)
        pause_request = panel / 'pause_after_current.json'
        if pause_request.exists():
            status['paused_after_job'] = name
            status['pause_request'] = json.loads(pause_request.read_text())
            write(panel / 'status.json', status)
            print('Paused after completed job; all outputs preserved:', name, flush=True)
            return
    status['finished_utc'] = datetime.now(timezone.utc).isoformat()
    write(panel / 'status.json', status)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('configuration', type=Path)
    parser.add_argument('--only', action='append')
    parser.add_argument('--wait', action='store_true', help='Wait for the shared execution lock; never overlap energy jobs')
    args = parser.parse_args()
    run(args.configuration, args.only, args.wait)
