"""Run independent orbital-propagation chains within explicit resource limits.

One coordinator holds the shared energy lock. Each worker owns a disjoint chain
of job directories and uses the existing immutable native execution/audit path.
"""
import argparse
from copy import deepcopy
from datetime import datetime, timezone
import fcntl
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
from run_panel import sha, write


def chains(config):
    jobs=config['pilots'];names={j['directory'] for j in jobs}
    if len(names)!=len(jobs):
        raise ValueError('Duplicate job directories')
    groups={name:{name} for name in names}
    seen=set()
    for job in jobs:
        name=job['directory']
        for key in ('transport_from_job','seed_requires_accepted'):
            source=job.get(key)
            if source not in names:
                continue
            if source not in seen:
                raise ValueError('Dependencies must precede dependent jobs')
            merged=groups[name]|groups[source]
            for member in merged:
                groups[member]=merged
        seen.add(name)
    result=[];used=set()
    for job in jobs:
        name=job['directory']
        if name not in used:
            group=groups[name];result.append([j for j in jobs if j['directory'] in group]);used|=group
    return result


def run(configuration,wait=False):
    base=configuration.resolve().parent;config=json.loads(configuration.read_text())
    if config.get('analysis_only'):
        raise ValueError('An analysis-only catalog cannot launch native jobs')
    limits=config['parallel_limits'];count=int(limits['workers'])
    groups=chains(config)
    if count<1:
        raise ValueError('Positive worker count required')
    per_chain=[]
    for group in groups:
        cpus=max(int(j.get('processes',config['processes'])) for j in group)
        memory=max(int(j.get('processes',config['processes']))*int(j.get('maxcore_mb_per_process',config['maxcore_mb_per_process'])) for j in group)
        if min(cpus,memory)<1:
            raise ValueError('Invalid resources')
        per_chain.append((cpus,memory))
    if sum(sorted((x[0] for x in per_chain),reverse=True)[:count])>limits['maximum_total_processes']:
        raise ValueError('Concurrent CPU request exceeds configured budget')
    if sum(sorted((x[1] for x in per_chain),reverse=True)[:count])>limits['maximum_total_requested_memory_mb']:
        raise ValueError('Concurrent working-memory request exceeds configured budget')
    panel=base/config['panel_directory'];panel.mkdir(parents=True,exist_ok=True)
    lock=(base/config['execution_lock']).open('a')
    print('Waiting for shared execution lock:',base/config['execution_lock'],flush=True)
    fcntl.flock(lock,fcntl.LOCK_EX|(0 if wait else fcntl.LOCK_NB))
    environment=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1')
    active={};queue=list(enumerate(groups));finished=[]
    status={'started_utc':datetime.now(timezone.utc).isoformat(),'pid':os.getpid(),
            'configuration_sha256':sha(configuration),'parallel_limits':limits,'jobs':{}}

    def refresh():
        for job in config['pilots']:
            name=job['directory'];directory=base/name
            if (directory/'result.json').exists():
                result=json.loads((directory/'result.json').read_text())
                status['jobs'][name]={'status':'numerically_accepted' if result['numerically_accepted'] else 'needs_review','errors':result['errors']}
            elif (directory/'execution.json').exists():
                record=json.loads((directory/'execution.json').read_text())
                status['jobs'][name]={'status':record['status'],'pid':record.get('pid')}
            else:
                status['jobs'][name]={'status':'waiting'}
        status['active_workers']=[{'index':i,'pid':v[0].pid} for i,v in active.items()]
        status['finished_workers']=finished
        write(panel/'status.json',status)

    def stop(signum,frame):
        for process,stream in active.values():
            if process.poll() is None:
                process.terminate()
        for process,stream in active.values():
            try:
                process.wait(timeout=40)
            except subprocess.TimeoutExpired:
                # Retain this allocation record rather than claiming a clean stop.
                status.setdefault('shutdown_unresolved_workers',[]).append(process.pid)
            stream.close()
        status['interrupted_utc']=datetime.now(timezone.utc).isoformat();refresh()
        raise SystemExit(128+signum)

    signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
    pause_request=panel/'pause_before_launch.json'
    if pause_request.exists():
        status['paused_utc']=datetime.now(timezone.utc).isoformat()
        status['pause_request']=json.loads(pause_request.read_text())
        refresh()
        print('Paused before launching workers; all outputs preserved.',flush=True)
        return
    try:
        while queue or active:
            while queue and len(active)<count:
                index,group=queue.pop(0)
                worker_folder=panel/'_controllers'/f'{index:02d}';worker_folder.mkdir(parents=True,exist_ok=True)
                worker=deepcopy(config);worker.update(pilots=group,panel_directory=str(worker_folder.relative_to(base)),
                     execution_lock=str((worker_folder/'controller.lock').relative_to(base)))
                worker.pop('parallel_limits',None)
                worker_path=base/(config['panel_directory'].replace('/','_')+f'_worker_{index:02d}.json')
                if worker_path.exists() and json.loads(worker_path.read_text())!=worker:
                    raise RuntimeError(f'Existing worker configuration differs: {worker_path}')
                write(worker_path,worker)
                stream=(worker_folder/'controller.log').open('a')
                process=subprocess.Popen([sys.executable,'-u',str(base/'run_panel.py'),str(worker_path)],
                                         stdout=stream,stderr=subprocess.STDOUT,env=environment,start_new_session=True)
                active[index]=(process,stream)
                print('RUNNING chain',index,group[0]['directory'],flush=True)
            refresh()
            time.sleep(2)
            for index,(process,stream) in list(active.items()):
                code=process.poll()
                if code is not None:
                    stream.close();finished.append({'index':index,'returncode':code});del active[index]
                    print('FINISHED chain',index,'returncode',code,flush=True)
    except BaseException:
        # Never release the shared resource lock while an owned worker is active.
        for process,stream in active.values():
            if process.poll() is None:
                process.terminate()
        for process,stream in active.values():
            process.wait()
            stream.close()
        raise
    status['finished_utc']=datetime.now(timezone.utc).isoformat();refresh()


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('configuration',type=Path)
    p.add_argument('--wait',action='store_true');a=p.parse_args();run(a.configuration,a.wait)
