"""Compare declared numerical controls, retaining native warnings and hashes."""
import argparse
import json
from pathlib import Path
import re
from audit_orca import audit
from run_panel import sha, write

KCAL = 627.5094740631


def summarize(configuration, baseline_configuration):
    base = configuration.resolve().parent
    config = json.loads(configuration.read_text())
    baseline = json.loads(baseline_configuration.read_text())
    catalog = {j['directory']: j for c in (baseline, config) for j in c['pilots']}
    owners = {j['directory']: c for c in (baseline, config) for j in c['pilots']}
    rows = []
    for job in config['pilots']:
        reference = job.get('comparison_reference', job['control_of'])
        original = catalog[reference]
        for key in ('geometry_angstrom', 'active_electrons', 'active_orbitals',
                    'inactive_orbitals', 'multiplicities', 'roots', 'block_weights', 'charge'):
            if job[key] != original[key]:
                raise ValueError(f'Unmatched {key}: {job["directory"]} and {reference}')
        row = {'directory': job['directory'], 'reference': reference, 'status': 'waiting'}
        def settings(j):
            c=owners[j['directory']]
            return {'correlation': dict(c['correlation'], **j.get('correlation', {})),
                    'solver': dict(c['solver'], **j.get('solver', {})),
                    'processes': j.get('processes',c['processes']),
                    'maxcore_mb_per_process': j.get('maxcore_mb_per_process',c['maxcore_mb_per_process']),
                    'seed': j.get('initial_orbitals')}
        current_settings, reference_settings = settings(job), settings(original)
        row['changed_settings']={k:{'reference':reference_settings[k],'control':v}
                                 for k,v in current_settings.items() if reference_settings[k]!=v}
        directory = base/job['directory']; source = base/reference
        if not (directory/'result.json').exists():
            rows.append(row); continue
        result = json.loads((directory/'result.json').read_text())
        native = audit(directory/'panel.out')
        text = (directory/'panel.out').read_text(errors='replace')
        match = re.search(r'NThresh \(linear dependencies\)\s*\.\.\.\s*([\d.eE+-]+)', text)
        row.update(status='numerically_complete' if result['numerically_accepted'] else 'needs_review',
                   native_norm_threshold=float(match[1]) if match else None,
                   input_sha256=sha(directory/'panel.inp'), output_sha256=sha(directory/'panel.out'),
                   native_review_flags=native['native_review_flags'])
        if not (source/'result.json').exists():
            row['comparison_status'] = 'reference_unavailable'; rows.append(row); continue
        refresult = json.loads((source/'result.json').read_text())
        if not result['numerically_accepted'] or not refresult['numerically_accepted']:
            row['comparison_status'] = 'incomplete_or_failed_result'; rows.append(row); continue
        refnative = audit(source/'panel.out')
        # At unchanged geometry/space these are root-index diagnostics, not
        # evidence of tracking electronic states across a geometry change.
        states = {(s['multiplicity'], s['root_0based']): s['energy_hartree'] for s in native['caspt2_states']}
        refstates = {(s['multiplicity'], s['root_0based']): s['energy_hartree'] for s in refnative['caspt2_states']}
        if states.keys() != refstates.keys():
            raise ValueError('Different root coverage')
        zero, refzero = min(states.values()), min(refstates.values())
        row['states'] = [{'multiplicity': m, 'root_0based': r,
                          'absolute_change_kcal_mol': (states[m,r]-refstates[m,r])*KCAL,
                          'common_zero_spectrum_change_kcal_mol':
                              ((states[m,r]-zero)-(refstates[m,r]-refzero))*KCAL}
                         for m,r in sorted(states)]
        row.update(comparison_status='compared', reference_output_sha256=sha(source/'panel.out'),
                   maximum_absolute_change_kcal_mol=max(abs(s['absolute_change_kcal_mol']) for s in row['states']),
                   maximum_spectrum_change_kcal_mol=max(abs(s['common_zero_spectrum_change_kcal_mol']) for s in row['states']))
        rows.append(row)
    return {'configuration_sha256': sha(configuration), 'comparisons': rows,
            'interpretation': 'Numerical sensitivity only. Native warnings remain unresolved by cutoff insensitivity alone; no active space selected.'}


if __name__ == '__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('configuration',type=Path)
    parser.add_argument('baseline_configuration',type=Path)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    write(args.output,summarize(args.configuration,args.baseline_configuration))
