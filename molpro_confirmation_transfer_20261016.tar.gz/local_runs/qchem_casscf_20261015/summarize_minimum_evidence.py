"""Summarize explicitly selected VRC observables without choosing a CAS.

The recipe supplies comparison reports and state labels. Full spectra remain
in those reports. A comparison against an expanded space is not ground truth,
and neither a maximum over averaged roots nor a scalar flag is a CAS decision.
"""
import argparse
import json
from pathlib import Path
from run_panel import sha, write


def summarize(recipe_path, output):
    base = recipe_path.resolve().parent
    recipe = json.loads(recipe_path.read_text())
    result = {'schema': 1, 'recipe_sha256': sha(recipe_path),
              'purpose': recipe['purpose'], 'production_approved': False,
              'selection': None, 'comparisons': []}
    for item in recipe['comparisons']:
        path = base / item['report']
        report = json.loads(path.read_text())
        matches = [row for row in report['comparisons'] if row['id'] == item['comparison']]
        if len(matches) != 1:
            raise ValueError('Expected one explicitly named comparison')
        comparison = matches[0]
        target, anchor = item['target_state'], item['spin_anchor_state']
        row = {key: comparison[key] for key in
               ('id', 'candidate', 'reference', 'state_assignment', 'missing')}
        row.update(report=str(path.resolve()), report_sha256=sha(path),
                   target_state=target, spin_anchor_state=anchor,
                   reference_adequacy_verified=comparison['reference_adequacy_verified'],
                   interpretation=item['interpretation'], raw=[], angular=[])
        for source, destination, field in (
                ('raw_comparisons', 'raw', 'candidate_minus_reference_kcal_mol'),
                ('angular_residuals', 'angular', 'corrected_candidate_minus_reference_kcal_mol')):
            for measured in comparison[source]:
                values = measured[field]
                row[destination].append({'point': measured['point'],
                    'target_difference_kcal_mol': values[target],
                    'spin_anchor_difference_kcal_mol': values[anchor],
                    'spin_gap_difference_kcal_mol': values[target] - values[anchor],
                    'maximum_over_entire_reported_spectrum_kcal_mol': max(map(abs, values.values()))})
        result['comparisons'].append(row)
    write(output, result)
    return output


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('recipe', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    print(summarize(args.recipe, args.output))
