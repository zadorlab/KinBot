"""Read-only status and matched CASPT2 spectrum screen; never selects a CAS.

One common far-point zero is used for all roots/spins of each active space.
Sorted same-spin spectra are a screening diagnostic, not state tracking.
"""
import argparse
from collections import Counter, defaultdict
from datetime import datetime, timezone
import json
from pathlib import Path
import re
import time
from audit_orca import audit

HARTREE_TO_KCAL = 627.5094740631


def read(path):
    return json.loads(path.read_text()) if path.exists() else None


def live(path):
    if not path.exists():
        return {}
    text = path.read_text(errors='replace')
    iterations = re.findall(r'MACRO-ITERATION\s+(\d+)', text)
    gradients = re.findall(r'\|\|g\|\|\s*=\s*([-+\d.eE]+)', text)
    pt_done = len(re.findall(r'CASPT2 calculation converged in', text))
    stage = ('terminated' if 'ORCA TERMINATED NORMALLY' in text else
             'CASPT2' if '< CASPT2 >' in text or pt_done else
             'CASSCF' if iterations else 'startup/SCF')
    alerts = [line.strip() for line in text.splitlines()
              if re.search(r'ERROR|WARNING|NOT CONVERG|not converge|insufficient memory', line)]
    return {'phase': stage, 'macro_iteration': int(iterations[-1]) if iterations else None,
            'gradient': float(gradients[-1]) if gradients else None,
            'caspt2_converged_roots': pt_done,
            'output_age_seconds': round(time.time()-path.stat().st_mtime),
            'native_alerts': list(dict.fromkeys(alerts))[-8:]}


def summarize(configuration):
    base = configuration.resolve().parent
    config = read(configuration)
    controller = read(base/config['panel_directory']/'status.json') or {}
    data = {'updated_utc': datetime.now(timezone.utc).isoformat(), 'jobs': [], 'comparisons': [], 'angular_comparisons': [],
            'interpretation': [
                'Largest tested space is a comparator, not an exact reference.',
                'All root energies share one far-point zero per active space; no root-specific offsets.',
                'Sorted same-spin spectra do not establish state identity or PES continuity.',
                'No production CAS is selected by this report.']}
    groups = defaultdict(dict)
    for job in config['pilots']:
        directory = base/job['directory']
        result = read(directory/'result.json')
        execution = read(directory/'execution.json') or {}
        state = controller.get('jobs', {}).get(job['directory'], {})
        space = (job['active_electrons'], job['active_orbitals'])
        row = {'directory': job['directory'], 'channel': job['channel'], 'space': list(space),
               'point': job['point'], 'status': state.get('status', 'not_started')}
        if result:
            native = audit(directory/'panel.out')
            review = read(directory/'independent_review.json') or result
            row.update(status='accepted_numerically' if result['numerically_accepted'] else 'needs_review',
                       errors=result['errors'], gradient=result.get('final_printed_orbital_gradient'),
                       caspt2_converged_roots=result['caspt2_converged_root_count'],
                       elapsed_seconds=result.get('elapsed_seconds'),
                       processes=execution.get('processes'),
                       native_review_flags=native['native_review_flags'],
                       active_subspace_overlap=review.get('active_subspace_overlap'),
                       minimum_reference_weight=min((s['reference_weight'] for s in native['caspt2_states']
                           if s['reference_weight'] is not None), default=None),
                       minimum_denominator_hartree=min((x for s in native['caspt2_denominators']
                           for x in s['classes_hartree'].values()), default=None))
            if result['numerically_accepted']:
                groups[job['channel']].setdefault(space, {})[job['point']] = (job, result)
        elif (directory/'panel.out').exists():
            row.update(live(directory/'panel.out'))
        data['jobs'].append(row)
    for channel, spaces in groups.items():
        # Compare only to the largest planned space, never a smaller fallback
        # merely because its result finished first.
        comparator = max(((j['active_electrons'], j['active_orbitals'])
                          for j in config['pilots'] if j['channel'] == channel), key=lambda s:s[1])
        ref = spaces.get(comparator, {})
        if 'far' not in ref:
            continue
        refzero = min(s['energy_hartree'] for s in ref['far'][1]['caspt2_states'])
        for space, points in spaces.items():
            if 'far' not in points:
                continue
            zero = min(s['energy_hartree'] for s in points['far'][1]['caspt2_states'])
            for point in sorted(set(points) & set(ref)):
                job, result = points[point]
                refjob, reference = ref[point]
                if job['geometry_angstrom'] != refjob['geometry_angstrom']:
                    raise ValueError(f'Unmatched geometries: {channel} {point}')
                for mult in job['multiplicities']:
                    es = sorted(s['energy_hartree'] for s in result['caspt2_states'] if s['multiplicity'] == mult)
                    rs = sorted(s['energy_hartree'] for s in reference['caspt2_states'] if s['multiplicity'] == mult)
                    if len(es) != len(rs):
                        raise ValueError('Different state counts require an explicit physical state assignment')
                    de = [(e-zero-r+refzero)*HARTREE_TO_KCAL for e, r in zip(es, rs)]
                    data['comparisons'].append({'channel': channel, 'space': list(space),
                        'comparator': list(comparator), 'point': point, 'multiplicity': mult,
                        'energies_relative_common_far_zero_kcal_mol': [(e-zero)*HARTREE_TO_KCAL for e in es],
                        'difference_from_comparator_kcal_mol': de, 'maximum_absolute_difference': max(map(abs,de))})
            if all(p in points and p in ref for p in ('center', 'tilted')):
                for mult in points['center'][0]['multiplicities']:
                    spectra = [[sorted(s['energy_hartree'] for s in family[p][1]['caspt2_states']
                                if s['multiplicity'] == mult) for p in ('center', 'tilted')]
                               for family in (points, ref)]
                    changes = [[(b-a)*HARTREE_TO_KCAL for a,b in zip(center,tilted,strict=True)]
                               for center,tilted in spectra]
                    delta = [a-b for a,b in zip(*changes,strict=True)]
                    data['angular_comparisons'].append({'channel': channel, 'space': list(space),
                        'comparator': list(comparator), 'multiplicity': mult,
                        'tilted_minus_center_kcal_mol': changes[0],
                        'comparator_tilted_minus_center_kcal_mol': changes[1],
                        'difference_from_comparator_kcal_mol': delta,
                        'maximum_absolute_difference': max(map(abs,delta))})
    data['counts'] = dict(Counter(row['status'] for row in data['jobs']))
    return data


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('configuration', type=Path)
    parser.add_argument('--json', type=Path, help='Write derived summary only; native files remain untouched')
    args = parser.parse_args()
    data = summarize(args.configuration)
    print(data['updated_utc'], data['counts'])
    for row in data['jobs']:
        if row['status'] == 'not_started':
            continue
        print(row['directory'].split('/')[-1], row['status'],
              f"phase={row.get('phase', '-')} g={row.get('gradient')} PTroots={row.get('caspt2_converged_roots')}")
        if row.get('errors') or row.get('native_alerts'):
            print(' ', row.get('errors') or row.get('native_alerts'))
        if row.get('native_review_flags'):
            print('  NATIVE REVIEW:', sorted(set(a['text'] for a in row['native_review_flags'])))
    for row in data['comparisons']:
        if row['point'] != 'far' and row['space'] != row['comparator']:
            print('SCREEN', row['channel'], row['space'], row['point'], 'mult', row['multiplicity'],
                  'maximum relative-spectrum difference', round(row['maximum_absolute_difference'], 6), 'kcal/mol')
    if args.json:
        args.json.write_text(json.dumps(data, indent=2)+'\n')
