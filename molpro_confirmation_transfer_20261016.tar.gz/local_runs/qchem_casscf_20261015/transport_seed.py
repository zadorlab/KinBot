"""Transport reviewed orbitals with rigid fragments, then orthonormalize by block.

This avoids projecting a sulfur atom's orbitals onto its old position after a
large separation change. Atom lists and partitions are explicit JSON data.
Native ORCA computes the target AO overlap before any energy job is submitted.
"""
import argparse
import hashlib
import json
import math
from pathlib import Path
import subprocess
import numpy as np
from molpro_to_orca import cart_to_real


POWERS = [np.array([[0,0,0]]), np.eye(3,dtype=int),
          np.array([[2,0,0],[0,2,0],[0,0,2],[1,1,0],[1,0,1],[0,1,1]]),
          np.array([[3,0,0],[0,3,0],[0,0,3],[2,1,0],[2,0,1],[1,2,0],[0,2,1],[1,0,2],[0,1,2],[1,1,1]])]


def angular(l, xyz):
    powers = POWERS[l]
    norm = np.array([math.prod(math.prod(range(1,2*int(k),2)) for k in p) for p in powers])
    return np.prod(xyz[:,None,:]**powers[None,:,:],axis=2)/np.sqrt(norm)[None,:] @ cart_to_real(l)


def rotation(l, r):
    points = np.random.default_rng(8459).normal(size=(40,3))
    points /= np.linalg.norm(points,axis=1)[:,None]
    a = angular(l, points)
    b = angular(l, points @ r.T)
    # Geometries use row vectors: old @ R = new, so old x = new x @ R.T.
    d = np.linalg.lstsq(a,b,rcond=None)[0]
    if np.max(abs(a@d-b)) > 1e-12 or np.max(abs(d.T@d-np.eye(2*l+1))) > 1e-12:
        raise ValueError('Angular rotation failed')
    return d


def invoke(executable, directory, stem, import_json):
    args = [executable, stem+'.json', '-gbw'] if import_json else [executable,stem+'.gbw']
    r = subprocess.run(args,cwd=directory,capture_output=True,text=True)
    (directory/(stem+('.import.log' if import_json else '.export.log'))).write_text(r.stdout+r.stderr)
    if r.returncode:
        raise RuntimeError(r.stdout+r.stderr)


def transport(seed, geometry, fragments, core, closed, active, directory, executable):
    directory.mkdir(parents=True,exist_ok=True)
    source = json.loads(seed.read_text());m=source['Molecule'];m['HFTyp']='RHF'
    if m.get('CoordinateUnits') != 'Angs':
        raise ValueError('Rigid-fragment transport requires coordinates explicitly in Angstrom')
    old=np.array([a['Coords'] for a in m['Atoms']]);new=np.array([a[1:] for a in geometry])
    if [a['ElementLabel'] for a in m['Atoms']] != [a[0] for a in geometry]:
        raise ValueError('Atom identities/order differ')
    if sorted(i for f in fragments for i in f) != list(range(len(old))):
        raise ValueError('Fragments must partition all atoms exactly once')
    rotations={};residuals=[]
    for f in fragments:
        x=old[f]-old[f].mean(axis=0);y=new[f]-new[f].mean(axis=0)
        if len(f)==1:
            r=np.eye(3)
        else:
            u,s,v=np.linalg.svd(x.T@y)
            fix=np.eye(3);fix[-1,-1]=np.linalg.det(u@v)
            r=u@fix@v
        residual=float(np.max(np.linalg.norm(x@r-y,axis=1)))
        if residual > 2e-7:
            raise ValueError(f'Fragment is not rigid: {f} residual={residual}')
        residuals.append(residual)
        for i in f:rotations[i]=r
    c=np.array([o['MOCoefficients'] for o in m['MolecularOrbitals']['MOs']]).T
    start=0
    for i,atom in enumerate(m['Atoms']):
        for shell in atom['Basis']:
            l='spdf'.index(shell['Shell']);n=2*l+1
            c[start:start+n]=rotation(l,rotations[i])@c[start:start+n]
            start+=n
        atom['Coords']=new[i].tolist()
    if start!=len(c):raise ValueError('Basis dimension mismatch')
    for i,o in enumerate(m['MolecularOrbitals']['MOs']):o['MOCoefficients']=c[:,i].tolist()
    m.pop('S-Matrix',None)
    # Compute the target metric using native ORCA before constructing the final seed.
    (directory/'transport.json').write_text(json.dumps(source)+'\n')
    (directory/'transport_copy.json.conf').write_text(json.dumps({'MOCoefficients':True,'Basisset':True,'1elIntegrals':['S'],'JSONFormats':['json']}))
    invoke(executable,directory,'transport',True)
    invoke(executable,directory,'transport_copy',False)
    target=json.loads((directory/'transport_copy.json').read_text());s=np.array(target['Molecule']['S-Matrix'])
    q=np.empty((len(c),0));minimums=[]
    for a,b in zip([0,core,closed,closed+active],[core,closed,closed+active,len(c)],strict=True):
        if a==b:continue
        v=c[:,a:b].copy()
        # Reorthogonalize twice against previous blocks for diffuse AO metrics.
        for _ in range(2):v-=q@(q.T@s@v)
        w,u=np.linalg.eigh(v.T@s@v)
        if w.min()<1e-8:raise ValueError('Transported orbital block lost rank')
        minimums.append(float(w.min()));v=v@(u/np.sqrt(w))@u.T
        q=np.column_stack((q,v))
    error=float(abs(q.T@s@q-np.eye(len(c))).max())
    if error>1e-7:raise ValueError(f'Transported orbitals are not orthonormal: {error}')
    target['Molecule']['HFTyp']='RHF'
    for i,o in enumerate(target['Molecule']['MolecularOrbitals']['MOs']):o['MOCoefficients']=q[:,i].tolist()
    (directory/'seed.json').write_text(json.dumps(target)+'\n')
    (directory/'seed_copy.json.conf').write_text((directory/'transport_copy.json.conf').read_text())
    invoke(executable,directory,'seed',True);invoke(executable,directory,'seed_copy',False)
    exported=json.loads((directory/'seed_copy.json').read_text())['Molecule']
    qc=np.array([o['MOCoefficients'] for o in exported['MolecularOrbitals']['MOs']]).T
    error=float(abs(qc.T@np.array(exported['S-Matrix'])@qc-np.eye(len(c))).max())
    if error>1e-7:raise ValueError('Native reimport orthonormality failed')
    proof={'source_json':str(seed),'source_sha256':hashlib.sha256(seed.read_bytes()).hexdigest(),
           'fragments_0based':fragments,'fragment_rigid_fit_max_errors_angstrom':residuals,
           'orthogonalization_block_min_eigenvalues':minimums,'native_orthonormality_max_error':error,
           'orca_gbw_sha256':hashlib.sha256((directory/'seed_copy.gbw').read_bytes()).hexdigest(),
           'requires_native_overlap_validation':False,'core':core,'inactive':closed,'active':active}
    (directory/'seed.validation.json').write_text(json.dumps(proof,indent=2)+'\n')
    return proof


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('configuration',type=Path);a=p.parse_args()
    path=a.configuration.resolve();base=path.parent;c=json.loads(path.read_text())
    for j in c['pilots']:
        if j.get('transported'):continue
        directory=base/j['directory']/'seed'
        proof=transport((base/j['initial_orbitals']).with_suffix('.json'),j['geometry_angstrom'],j['fragments_0based'],
                        len(j['seed_core_orbitals']),j['inactive_orbitals'],j['active_orbitals'],directory,
                        str(Path(c['executable']).with_name('orca_2json')))
        j['original_seed']=j['initial_orbitals'];j['initial_orbitals']=str((directory/'seed_copy.gbw').relative_to(base))
        j['initial_orbitals_validation']=str((directory/'seed.validation.json').relative_to(base));j['transported']=True
        temporary=path.with_suffix('.tmp');temporary.write_text(json.dumps(c,indent=2)+'\n');temporary.replace(path)
        print(j['directory'],proof['native_orthonormality_max_error'],flush=True)
