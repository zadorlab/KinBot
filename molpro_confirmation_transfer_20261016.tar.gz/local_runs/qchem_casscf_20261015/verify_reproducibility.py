"""Verify an evidence archive and replay analysis in an isolated extraction.

No electronic-structure calculation is launched. The retained native outputs
are re-read using the archived analysis code and general KinBot helper modules.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import subprocess
import sys
import tarfile
import tempfile


def digest(data):
    return hashlib.sha256(data).hexdigest()


def verify(archive_path, index):
    archive_path = archive_path.resolve()
    target = archive_path.with_suffix(archive_path.suffix + '.verified.json')
    if target.exists():
        raise FileExistsError(target)
    expected_digest = archive_path.with_suffix(archive_path.suffix + '.sha256').read_text().split()[0]
    actual_digest = digest(archive_path.read_bytes())
    if actual_digest != expected_digest:
        raise ValueError('Archive checksum mismatch')
    with tempfile.TemporaryDirectory(prefix='kinbot_native_replay_') as work:
        work = Path(work)
        with tarfile.open(archive_path) as archive:
            members = archive.getmembers()
            names = [m.name for m in members]
            if len(set(names)) != len(names):
                raise ValueError('Duplicate archive members')
            for member in members:
                name = PurePosixPath(member.name)
                if not member.isfile() or name.is_absolute() or '..' in name.parts:
                    raise ValueError('Unsafe archive member: ' + member.name)
            manifest = json.load(archive.extractfile('reproducibility_manifest.json'))
            if set(names) != set(manifest['files']) | {'reproducibility_manifest.json'}:
                raise ValueError('Inventory and archive members differ')
            for member in members:
                data = archive.extractfile(member).read()
                if member.name != 'reproducibility_manifest.json':
                    declared = manifest['files'][member.name]
                    if digest(data) != declared['sha256'] or len(data) != declared['bytes']:
                        raise ValueError('Member checksum mismatch: ' + member.name)
                destination = work / member.name
                destination.parent.mkdir(parents=True, exist_ok=True)
                destination.write_bytes(data)

        environment = dict(os.environ, PYTHONPATH=str(work / 'source'),
            OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1', VECLIB_MAXIMUM_THREADS='1',
            MPLCONFIGDIR=str(work / 'mpl_config'))
        commands = []

        def run(*arguments):
            result = subprocess.run([sys.executable, *arguments], cwd=work,
                env=environment, text=True, capture_output=True, timeout=180)
            commands.append({'arguments': list(arguments), 'returncode': result.returncode,
                             'stdout': result.stdout, 'stderr': result.stderr})
            if result.returncode:
                raise RuntimeError(result.stdout + '\n' + result.stderr)
            return result.stdout

        output = 'curated_evidence/independent_replay'
        run('curate_minimum_evidence.py', 'curated_evidence_recipe.json', output)
        original = json.loads((work / index).read_text())
        repeated = json.loads((work / output / 'native_evidence.json').read_text())
        for key in ('observations', 'missing', 'configuration_sha256', 'path_definitions'):
            if original[key] != repeated[key]:
                raise ValueError('Native analysis replay differs: ' + key)
        recipe = json.loads((work / 'curated_evidence_recipe.json').read_text())
        paths = []
        for spec in recipe['path_specifications']:
            path = Path(run('assess_path_checks.py', spec).strip())
            report = json.loads(path.read_text())
            paths.append({'specification': spec, 'cases': report['cases']})
        run('summarize_minimum_evidence.py', 'minimum_evidence_recipe.json',
            'replayed_minimum_evidence.json')
        run('plot_minimum_evidence.py', output + '/native_evidence.json')
        run('make_replay.py', 'minimum_ss_radial_settings.json', 'fresh_energy_replay.json',
            '--directory', 'fresh_energy_replay')
        result = {'schema': 1, 'created_utc': datetime.now(timezone.utc).isoformat(),
            'archive': str(archive_path), 'sha256': actual_digest,
            'verified_members': len(manifest['files']),
            'native_points_reparsed': len(repeated['observations']),
            'missing_native_points': repeated['missing'],
            'curated_observations_exactly_reproduced': True,
            'source_modules': 'Archived source/kinbot; current checkout excluded from PYTHONPATH.',
            'commands': commands, 'path_assessments': paths,
            'fresh_energy_replay_created_not_executed': True,
            'production_approved': False,
            'temporary_extraction_removed_after_verification': True}
    target.write_text(json.dumps(result, indent=2) + '\n')
    print(target)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('archive', type=Path)
    parser.add_argument('--curated-index', required=True)
    args = parser.parse_args()
    verify(args.archive, args.curated_index)
