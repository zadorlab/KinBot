"""Refresh evidence-bound comparisons as independent native panels finish.

Only closed result records trigger assessment; running native output is never
treated as a result. This observer cannot approve chemical or production use.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import time
from assess_decision_panel import collect
from run_panel import write


def watch(configuration):
    base=configuration.resolve().parent
    options=json.loads(configuration.read_text())
    signatures={}
    status={'pid':os.getpid(),'status':'watching','reports':{}}
    record=base/options['status_file']
    while True:
        finished=True
        for relative in options['specifications']:
            spec_path=base/relative
            spec=json.loads(spec_path.read_text())
            settings_path=base/spec['output_settings']
            settings=json.loads(settings_path.read_text())
            digest=hashlib.sha256()
            for p in [spec_path,settings_path,base/'selection_policy.json']:
                digest.update(p.read_bytes())
            for job in settings['pilots']:
                p=base/job['directory']/'result.json'
                digest.update(job['directory'].encode())
                digest.update(p.read_bytes() if p.exists() else b'MISSING')
            signature=digest.hexdigest()
            if signatures.get(relative)!=signature:
                output=collect(spec_path)
                signatures[relative]=signature
                status['reports'][relative]=str(output.resolve())
                report=json.loads(output.read_text())
                print(relative, [(c['id'],c['status'],len(c['missing'])) for c in report['comparisons']],flush=True)
            state=base/settings['panel_directory']/'status.json'
            finished &= state.exists() and bool(json.loads(state.read_text()).get('finished_utc'))
        status['status']='finished' if finished else 'watching'
        write(record,status)
        if finished:
            return
        time.sleep(options.get('poll_seconds',10))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('configuration',type=Path)
    watch(parser.parse_args().configuration)
