"""General dispatch behavior with a synthetic small-molecule task graph."""

import json
import hashlib
import os
from pathlib import Path
import shutil
import shlex
import subprocess
import sys
from tempfile import TemporaryDirectory
from unittest.mock import patch

from ase import Atoms
from ase.calculators.calculator import Calculator, all_changes
from ase.io import read, write
import numpy as np
import pytest

from tests.anl_fixture import dispatch_spec
from kinbot.ase_modules.calculators.factory import build_calculator
from kinbot.anl.dispatch import (
    _geometry_hash, _job_active, _mark_preflight_unavailable, _molpro_stack_mw,
    _molpro_total_mw, _runtime_profile, _slurm_script, advance, main, prepare,
    SchedulerUnavailableError, drive_run,
    recover_gaussian_vpt2_symmetry,
    migrate_cfour_vcc_keyword, preflight,
    preflight_until_scheduler_ready, refresh_status, reparse_failed,
    reroute_cfour_higher_order_to_mrcc,
    resume_mrcc_failed,
    retry_failed, run_task,
    validate_spec,
)
from kinbot.anl.site import render_site_setup
from kinbot.anl.tasks import cfour_energy_task, mrcc_task
from kinbot.anl.validation import interface_validation_spec


def test_anl_slurm_script_imports_site_node_exclusion(tmp_path):
    task = validate_spec(dispatch_spec())['tasks'][0]
    with patch.dict(os.environ, {'SBATCH_EXCLUDE': 'node16'}, clear=True):
        script = _slurm_script(task, tmp_path, sys.executable)
    assert '#SBATCH --exclude=node16\n' in script


def _write_spec(directory, spec):
    path = Path(directory) / 'spec.json'
    path.write_text(json.dumps(spec))
    return path


def test_prepare_accepts_an_in_memory_workflow():
    with TemporaryDirectory() as temporary:
        root = Path(temporary)
        run_dir = prepare(dispatch_spec(), root / 'run')
        saved = json.loads((run_dir / 'workflow.json').read_text())
        assert saved['schema'] == 1
        assert saved['name'] == 'synthetic-qc-dispatch'


def test_status_reports_workflow_not_prepared_before_handoff(tmp_path):
    assert refresh_status(tmp_path / 'future-run') == {
        'workflow': 'not_prepared'}


def _mock_execution(run_dir, ident, *, geometry=None):
    task_dir = Path(run_dir) / 'tasks' / ident
    task = json.loads((task_dir / 'task.json').read_text())
    spec = task['task']
    if geometry:
        write(task_dir / geometry, Atoms(
            symbols=task['molecule']['symbols'],
            positions=read(task_dir / 'geometry.xyz').positions))
        details = {'final_geometry_sha256': _geometry_hash(read(task_dir / geometry))}
    else:
        details = {}
    names = {'geometry.xyz', 'task.json'}
    if spec['kind'] == 'external':
        names.update({spec['input_name'], spec.get('stdout', 'stdout.txt'),
                      spec.get('stderr', 'stderr.txt')})
        names.update(spec['required_outputs'])
        names.update(spec.get('files_from_env', {}))
    else:
        names.update({'final.xyz', 'optimization.log'})
        if spec['profile']['calculator'] == 'molpro':
            generated = [f'{ident}_step_0001{suffix}'
                         for suffix in ('.inp', '.out', '.log', '.xyz')]
            names.update(generated)
            details['generated_files'] = generated
    for name in names:
        path = task_dir / name
        if not path.exists():
            path.write_text('mock output\n')
    artifacts = {name: hashlib.sha256((task_dir / name).read_bytes()).hexdigest()
                 for name in names}
    (task_dir / 'execution.json').write_text(json.dumps({
        'schema': 1,
        'task_id': ident, 'geometry_sha256': task['geometry_sha256'],
        'status': 'executed', 'details': details, 'artifacts': artifacts,
    }))


def test_general_graph_stages_geometry_then_all_independent_jobs():
    spec = validate_spec(dispatch_spec())
    with TemporaryDirectory() as temporary:
        root = Path(temporary)
        run_dir = prepare(_write_spec(root, spec), root / 'run')
        assert {path.name for path in (run_dir / 'tasks').iterdir()} == {'l2_geometry'}
        l2_script = (run_dir / 'tasks' / 'l2_geometry' / 'job.slurm').read_text()
        assert l2_script.index('#SBATCH --exclusive') < l2_script.index('set -euo pipefail')
        assert '#SBATCH --ntasks=1\n' in l2_script
        assert '#SBATCH --cpus-per-task=4\n' in l2_script

        _mock_execution(run_dir, 'l2_geometry', geometry='final.xyz')
        state = advance(run_dir)
        assert state['tasks']['l2_geometry']['status'] == 'complete'
        assert state['tasks']['l3_geometry']['status'] == 'staged'
        assert 'harmonic' not in state['tasks']
        molpro_record = json.loads(
            (run_dir / 'tasks' / 'l3_geometry' / 'task.json').read_text())
        assert molpro_record['task']['kind'] == 'ase_optimize'
        assert molpro_record['task']['profile']['calculator'] == 'molpro'
        assert molpro_record['task']['profile']['optimizer'] == 'sella'
        assert not list((run_dir / 'tasks' / 'l3_geometry').glob('*.inp'))
        molpro_script = (run_dir / 'tasks' / 'l3_geometry' / 'job.slurm').read_text()
        assert '#SBATCH --ntasks=8\n' in molpro_script
        assert '#SBATCH --cpus-per-task=1\n' in molpro_script
        assert 'export OMP_NUM_THREADS=1' in molpro_script
        assert 'export MKL_NUM_THREADS=1' in molpro_script

        _mock_execution(run_dir, 'l3_geometry', geometry='final.xyz')
        state = advance(run_dir)
        assert all(state['tasks'][task['id']]['status'] == 'staged'
                   for task in spec['tasks'][2:])
        for task in spec['tasks']:
            script = (run_dir / 'tasks' / task['id'] / 'job.slurm').read_text()
            assert script.count('#SBATCH --exclusive') == 1
            assert script.index('#SBATCH --exclusive') < script.index('set -euo pipefail')
            backend = (task['backend'] if task['kind'] == 'external'
                       else task['profile']['calculator'])
            if backend == 'molpro':
                assert f"#SBATCH --ntasks={task['resources']['cores']}\n" in script
                assert '#SBATCH --cpus-per-task=1\n' in script
            else:
                assert '#SBATCH --ntasks=1\n' in script
                assert f"#SBATCH --cpus-per-task={task['resources']['cores']}\n" in script
        f12 = (run_dir / 'tasks' / 'f12_tz' / 'f12_tz.inp').read_text()
        harmonic = (run_dir / 'tasks' / 'harmonic' / 'harmonic.inp').read_text()
        assert 'frequencies,numerical' in harmonic
        assert 'set,charge=0\nset,spin=0' in harmonic
        assert 'uccsd(t)-f12b,scale_trip=1' in f12
        assert 'kb_f12b=energy' in f12
        assert '-m' in spec['tasks'][3]['command']
        assert '{molpro_stack_mw}' in spec['tasks'][3]['command']
        cfour = (run_dir / 'tasks' / 'cfour_dboc' / 'ZMAT').read_text()
        assert 'COORD=CARTESIAN' in cfour
        assert 'DBOC=ON' in cfour
        assert 'MEM_UNIT=MB\nMEMORY_SIZE=11200)' in cfour
        assert max(map(len, cfour.splitlines())) <= 72
        gaussian = (run_dir / 'tasks' / 'gaussian_vpt2' / 'vpt2.com').read_text()
        vpt2_task = next(task for task in spec['tasks']
                         if task['id'] == 'gaussian_vpt2')
        assert vpt2_task['geometry_from'] == 'l2_geometry'
        assert vpt2_task['depends_on'] == ['l3_geometry']
        assert state['tasks']['gaussian_vpt2']['geometry_from'] == 'l2_geometry'
        assert 'B2PLYP/cc-pVTZ' in gaussian
        assert 'EmpiricalDispersion=GD3BJ' in gaussian
        assert 'Freq=Anharmonic' in gaussian
        assert 'Opt=' not in gaussian
        assert '\n0 1\n' in gaussian


def _fallback_dispatch_spec():
    source = dispatch_spec()
    primary = json.loads(json.dumps(source['tasks'][0]))
    primary['failure_policy'] = 'skip_component'
    primary['component_families'] = ['primary_geometry']
    fallback = json.loads(json.dumps(source['tasks'][1]))
    fallback['id'] = 'fallback_geometry'
    fallback['geometry_from'] = 'initial'
    fallback.pop('depends_on', None)
    fallback['fallback_on'] = [primary['id']]
    fallback['failure_policy'] = 'skip_component'
    fallback['component_families'] = ['fallback_geometry']
    return {
        'schema': 1, 'name': 'conditional-fallback',
        'molecule': source['molecule'], 'limits': {'max_nodes': 2},
        'tasks': [primary, fallback],
    }


def test_conditional_fallback_is_not_staged_when_primary_completes(tmp_path):
    run_dir = prepare(_fallback_dispatch_spec(), tmp_path / 'run')
    assert not (run_dir / 'tasks' / 'fallback_geometry').exists()
    _mock_execution(run_dir, 'l2_geometry', geometry='final.xyz')
    state = advance(run_dir)
    assert state['tasks']['l2_geometry']['status'] == 'complete'
    assert state['tasks']['fallback_geometry']['status'] == 'skipped'
    assert state['tasks']['fallback_geometry']['skip_reason'] == \
        'higher tier completed; fallback not needed'


def test_conditional_fallback_stages_after_primary_is_unavailable(tmp_path):
    run_dir = prepare(_fallback_dispatch_spec(), tmp_path / 'run')
    state_path = run_dir / 'state.json'
    state = json.loads(state_path.read_text())
    state['tasks']['l2_geometry']['status'] = 'unavailable'
    state['tasks']['l2_geometry']['unavailable_reason'] = 'resource ceiling'
    state_path.write_text(json.dumps(state))
    state = advance(run_dir)
    assert state['tasks']['fallback_geometry']['status'] == 'staged'
    assert (run_dir / 'tasks' / 'fallback_geometry' / 'job.slurm').is_file()


def test_frequency_only_vpt2_requires_matching_l2_geometry_surface():
    spec = dispatch_spec()
    vpt2 = next(task for task in spec['tasks'] if task['id'] == 'gaussian_vpt2')
    vpt2['result_parser']['method'] = 'B3LYP'
    vpt2['input_template'] = vpt2['input_template'].replace('B2PLYP/', 'B3LYP/')
    with pytest.raises(ValueError, match='matching Gaussian geometry source'):
        validate_spec(spec)

    lower = dispatch_spec()
    l2 = next(task for task in lower['tasks'] if task['id'] == 'l2_geometry')
    l2['profile']['method'] = 'B3LYP'
    l2['profile']['calculator_kwargs'].pop('EmpiricalDispersion')
    lower_vpt2 = next(task for task in lower['tasks']
                      if task['id'] == 'gaussian_vpt2')
    lower_vpt2['input_template'] = lower_vpt2['input_template'].replace(
        'B2PLYP/', 'B3LYP/').replace('EmpiricalDispersion=GD3BJ ', '')
    lower_vpt2['result_parser']['method'] = 'B3LYP'
    lower_vpt2['result_parser'].pop('dispersion')
    validate_spec(lower)


def test_retry_rewrites_old_cfour_keyword_line_without_changing_workflow():
    with TemporaryDirectory() as temporary:
        root = Path(temporary)
        original = dispatch_spec()
        cfour = next(task for task in original['tasks'] if task['id'] == 'cfour_dboc')
        cfour['geometry_from'] = 'initial'
        cfour['input_template'] = (
            'Test molecule\n{{CARTESIAN}}\n\n'
            '*CFOUR(CALC=SCF,BASIS=cc-pVTZ,DBOC=ON,COORD=CARTESIAN,'
            'UNITS=ANGSTROM,CHARGE={{CHARGE}},MULTIPLICITY={{MULT}},'
            'MEM_UNIT=MB,MEMORY_SIZE={{WORK_MEMORY_MB}})\n')
        spec = {'schema': 1, 'name': 'cfour-retry',
                'molecule': original['molecule'], 'limits': {'max_nodes': 1},
                'tasks': [cfour]}
        run_dir = prepare(_write_spec(root, spec), root / 'run')
        workflow_hash = hashlib.sha256((run_dir / 'workflow.json').read_bytes()).hexdigest()
        task_dir = run_dir / 'tasks' / 'cfour_dboc'
        head, keyword_block = (task_dir / 'ZMAT').read_text().split('*CFOUR(', 1)
        old_input = (head + '*CFOUR('
                     + ','.join(keyword_block.rstrip().removesuffix(')').splitlines())
                     + ')\n')
        (task_dir / 'ZMAT').write_text(old_input)
        state_path = run_dir / 'state.json'
        state = json.loads(state_path.read_text())
        state['tasks']['cfour_dboc'].update(
            status='failed', input_sha256=hashlib.sha256(old_input.encode()).hexdigest())
        state_path.write_text(json.dumps(state))
        archive = retry_failed(run_dir, 'cfour_dboc')
        assert (archive / 'ZMAT').read_text() == old_input
        new_input = (task_dir / 'ZMAT').read_text()
        assert 'CHARGE=0\nMULTIPLICITY=1\nMEM_UNIT=MB' in new_input
        assert max(map(len, new_input.splitlines())) <= 72
        assert hashlib.sha256((run_dir / 'workflow.json').read_bytes()).hexdigest() == workflow_hash


def test_scheduler_respects_node_cap_after_geometry():
    with TemporaryDirectory() as temporary:
        root = Path(temporary)
        run_dir = prepare(_write_spec(root, dispatch_spec()), root / 'run')
        _mock_execution(run_dir, 'l2_geometry', geometry='final.xyz')
        advance(run_dir)
        _mock_execution(run_dir, 'l3_geometry', geometry='final.xyz')
        advance(run_dir)
        submitted = []

        def fake_sbatch(argv, **kwargs):
            ident = Path(kwargs['cwd']).name
            submitted.append(ident)
            return type('Response', (), {'returncode': 0,
                                         'stdout': f'{100 + len(submitted)}\n',
                                         'stderr': ''})()

        with patch('kinbot.anl.dispatch.subprocess.run', side_effect=fake_sbatch):
            state = advance(run_dir, submit=True)
        assert len(submitted) == 3
        assert sum(item['status'] == 'submitted' for item in state['tasks'].values()) == 3
        assert set(submitted) <= {task['id'] for task in dispatch_spec()['tasks'][2:]}

        with patch('kinbot.anl.dispatch._job_active', return_value=True), \
                patch('kinbot.anl.dispatch.subprocess.run', side_effect=fake_sbatch):
            advance(run_dir, submit=True)
        assert len(submitted) == 3


def test_selected_submission_keeps_other_ready_jobs_staged():
    with TemporaryDirectory() as temporary:
        root = Path(temporary)
        run_dir = prepare(_write_spec(root, dispatch_spec()), root / 'run')
        _mock_execution(run_dir, 'l2_geometry', geometry='final.xyz')
        advance(run_dir)
        _mock_execution(run_dir, 'l3_geometry', geometry='final.xyz')
        advance(run_dir)
        with patch('kinbot.anl.dispatch.subprocess.run', return_value=type(
                'Response', (), {'returncode': 0, 'stdout': '123\n', 'stderr': ''})()):
            state = advance(run_dir, submit=True, submit_only={'molpro_dz_sp'})
        assert state['tasks']['molpro_dz_sp']['status'] == 'submitted'
        assert all(state['tasks'][task['id']]['status'] == 'staged'
                   for task in dispatch_spec()['tasks'][2:] if task['id'] != 'molpro_dz_sp')
        with pytest.raises(ValueError, match='Unknown submission'):
            advance(run_dir, submit_only={'missing_task'})


def test_generic_external_task_runs_with_isolated_io_and_accepted_geometry():
    spec = {
        'schema': 1, 'name': 'generic-test',
        'molecule': {'symbols': ['H', 'H'],
                     'positions': [[0, 0, 0], [0, 0, 0.74]],
                     'charge': 0, 'multiplicity': 1},
        'limits': {'max_nodes': 1, 'max_cores_per_node': 2,
                   'max_memory_mb_per_node': 1024},
        'tasks': [{
            'id': 'geometry', 'kind': 'external', 'backend': 'fake',
            'geometry_from': 'initial', 'geometry_output': 'final.xyz',
            'resources': {'cores': 1, 'memory_mb': 512, 'walltime': '00:10:00'},
            'input_name': 'job.inp', 'input_template': '{{XYZ}}\n',
            'command': [sys.executable, '-c',
                        "from pathlib import Path; "
                        "Path('final.xyz').write_text(Path('geometry.xyz').read_text()); "
                        "Path('job.out').write_text('DONE')"],
            'stdout': 'launcher.stdout', 'stderr': 'launcher.stderr',
            'required_outputs': ['job.out', 'final.xyz'],
            'success_marker': {'file': 'job.out', 'contains': 'DONE'},
        }],
    }
    with TemporaryDirectory() as temporary:
        root = Path(temporary)
        run_dir = prepare(_write_spec(root, spec), root / 'run')
        result = run_task(run_dir / 'tasks' / 'geometry' / 'task.json')
        assert result['status'] == 'executed'
        assert 'job.out' in result['artifacts']
        state = advance(run_dir)
        assert state['tasks']['geometry']['status'] == 'complete'
        with pytest.raises(RuntimeError, match='already has execution'):
            run_task(run_dir / 'tasks' / 'geometry' / 'task.json')


def test_program_failure_text_is_rejected_even_with_zero_exit_status():
    spec = dispatch_spec()
    spec['tasks'] = [{
        'id': 'check', 'kind': 'external', 'backend': 'fake',
        'resources': {'cores': 1, 'memory_mb': 512,
                      'walltime': '00:10:00'},
        'input_name': 'check.inp', 'input_template': '{{XYZ}}\n',
        'command': [sys.executable, '-c',
                    "from pathlib import Path; "
                    "Path('check.out').write_text('DONE\\nFatal error\\n')"],
        'required_outputs': ['check.out'],
        'success_marker': {'file': 'check.out', 'contains': 'DONE'},
        'failure_markers': [{'file': 'check.out', 'contains': 'Fatal error'}],
    }]
    with TemporaryDirectory() as temporary:
        root = Path(temporary)
        run_dir = prepare(_write_spec(root, spec), root / 'run')
        with pytest.raises(RuntimeError, match='Failure marker'):
            run_task(run_dir / 'tasks' / 'check' / 'task.json')
        assert advance(run_dir)['tasks']['check']['status'] == 'failed'


def test_ase_sella_runner_with_analytic_toy_calculator():
    class Quadratic(Calculator):
        implemented_properties = ['energy', 'forces']

        def __init__(self, target):
            super().__init__()
            self.target = target

        def calculate(self, atoms=None, properties=('energy',),
                      system_changes=all_changes):
            super().calculate(atoms, properties, system_changes)
            assert atoms.info['charge'] == 0
            assert atoms.info['spin'] == 1
            delta = atoms.positions - self.target
            self.results = {'energy': float(np.sum(delta * delta)),
                            'forces': -2 * delta}

    spec = dispatch_spec()
    spec['tasks'] = [spec['tasks'][0]]
    with TemporaryDirectory() as temporary:
        root = Path(temporary)
        run_dir = prepare(_write_spec(root, spec), root / 'run')
        target = read(run_dir / 'tasks' / 'l2_geometry' / 'geometry.xyz').positions.copy()
        target[1, 0] += 0.04
        with patch('kinbot.ase_modules.calculators.factory.build_calculator',
                   return_value=Quadratic(target)):
            result = run_task(run_dir / 'tasks' / 'l2_geometry' / 'task.json')
        assert result['status'] == 'executed'
        assert result['details']['optimizer'] == 'sella'
        assert (run_dir / 'tasks' / 'l2_geometry' / 'final.xyz').is_file()
        assert advance(run_dir)['tasks']['l2_geometry']['status'] == 'complete'


def test_gaussian_ase_input_rendering_without_gaussian_executable():
    spec = dispatch_spec()
    task = spec['tasks'][0]
    atoms = Atoms(symbols=spec['molecule']['symbols'],
                  positions=spec['molecule']['positions'])
    profile = _runtime_profile(task)
    with TemporaryDirectory() as directory:
        calc = build_calculator(profile, directory,
                                {'name': 'ch4', 'charge': 0, 'mult': 1})
        calc.write_input(atoms, ['energy', 'forces'])
        gaussian = (Path(directory) / 'ch4.com').read_text()
    assert '%nprocshared=4' in gaussian
    assert '%mem=11200MB' in gaussian
    assert 'B2PLYP/cc-pVTZ' in gaussian
    assert 'EmpiricalDispersion(GD3BJ)' in gaussian
    assert 'integral(UltraFine)' in gaussian
    assert '\n0 1\n' in gaussian
    assert 'force' in gaussian.lower()


def test_validation_rejects_cycles_and_oversized_exclusive_jobs():
    spec = dispatch_spec()
    spec['tasks'][0]['geometry_from'] = 'l3_geometry'
    with pytest.raises(ValueError, match='cycle'):
        validate_spec(spec)
    spec = dispatch_spec()
    spec['tasks'][1]['resources']['cores'] = 17
    with pytest.raises(ValueError, match='exceeds'):
        validate_spec(spec)
    spec = dispatch_spec()
    spec['tasks'][1]['profile']['calculator_kwargs'] = {'nproc': 4}
    with pytest.raises(ValueError, match='Molpro nproc'):
        validate_spec(spec)
    spec = dispatch_spec()
    spec['tasks'][6]['input_name'] = 'dboc.inp'
    with pytest.raises(ValueError, match='ZMAT'):
        validate_spec(spec)
    spec = dispatch_spec()
    spec['tasks'][3]['stdout'] = 'execution.json'
    with pytest.raises(ValueError, match='reserved'):
        validate_spec(spec)
    spec = dispatch_spec()
    spec['tasks'][0]['profile']['calculator_kwargs']['nprocshared'] = 8
    with pytest.raises(ValueError, match='must match Slurm cores'):
        validate_spec(spec)
    assert _molpro_total_mw({'cores': 8, 'memory_mb': 32000}) == 1800
    assert _molpro_stack_mw({'cores': 8, 'memory_mb': 32000}) == 225
    spec = dispatch_spec()
    spec['tasks'][1]['resources']['memory_mb'] = 2000
    with pytest.raises(ValueError, match='per-process overhead'):
        validate_spec(spec)


def test_auto_cores_use_safe_node_memory_and_efficient_rank_counts():
    spec = dispatch_spec()
    spec['limits'] = {'max_nodes': 2}
    spec['tasks'] = [dict(spec['tasks'][1], geometry_from='initial'),
                     spec['tasks'][0]]
    spec['tasks'][0]['resources'] = {'walltime': '24:00:00'}
    spec['tasks'][1]['resources'] = {'walltime': '08:00:00'}
    node_groups = [
        {'name': 'day', 'default': True, 'cores': 96,
         'memory_mb': 126000, 'seconds': 86400},
        {'name': 'day', 'default': True, 'cores': 64,
         'memory_mb': 64000, 'seconds': 86400},
    ]
    with TemporaryDirectory() as temporary, \
            patch('kinbot.anl.site._partitions', return_value=node_groups):
        root = Path(temporary)
        run_dir = prepare(_write_spec(root, spec), root / 'run')
        resolved = json.loads((run_dir / 'workflow.json').read_text())
        molpro = resolved['tasks'][0]['resources']
        gaussian = resolved['tasks'][1]['resources']
        assert molpro['partition'] == gaussian['partition'] == 'day'
        assert molpro['memory_mb'] == gaussian['memory_mb'] == 64000
        assert molpro['use_all_node_memory'] is True
        assert gaussian['use_all_node_memory'] is True
        assert molpro['cores'] == 4
        assert gaussian['cores'] == 12
        assert _molpro_stack_mw(molpro) >= molpro['min_stack_mw']
        script = (run_dir / 'tasks' / 'l3_geometry' / 'job.slurm').read_text()
        assert '#SBATCH --ntasks=4\n' in script
        assert '#SBATCH --cpus-per-task=1\n' in script
        assert '#SBATCH --mem=0\n' in script


def test_auto_molpro_cores_fail_when_node_cannot_meet_stack_minimum():
    spec = dispatch_spec()
    spec['limits'] = {'max_nodes': 1}
    spec['tasks'] = [dict(spec['tasks'][1], geometry_from='initial')]
    spec['tasks'][0]['resources'] = {'walltime': '24:00:00',
                                     'min_stack_mw': 512}
    node_groups = [{'name': 'day', 'default': True, 'cores': 16,
                    'memory_mb': 3000, 'seconds': 86400}]
    with TemporaryDirectory() as temporary, \
            patch('kinbot.anl.site._partitions', return_value=node_groups):
        root = Path(temporary)
        with pytest.raises(RuntimeError, match='cannot support one core'):
            prepare(_write_spec(root, spec), root / 'run')


def test_auto_molpro_skips_faster_partition_without_enough_rank_memory():
    spec = dispatch_spec(auto_resources=True)
    spec['tasks'] = [dict(spec['tasks'][1], geometry_from='initial')]
    node_groups = [
        {'name': 'short', 'default': True, 'cores': 32,
         'memory_mb': 3000, 'seconds': 86400},
        {'name': 'day', 'default': False, 'cores': 96,
         'memory_mb': 64000, 'seconds': 172800},
    ]
    with TemporaryDirectory() as temporary, \
            patch('kinbot.anl.site._partitions', return_value=node_groups):
        root = Path(temporary)
        run_dir = prepare(_write_spec(root, spec), root / 'run')
        resolved = json.loads((run_dir / 'workflow.json').read_text())
        assert resolved['tasks'][0]['resources']['partition'] == 'day'
        assert resolved['tasks'][0]['resources']['cores'] == 4


def test_auto_resource_ceiling_allows_a_lower_method_specific_rank_cap():
    spec = dispatch_spec(auto_resources=True)
    assert spec['limits'] == {'max_nodes': 3}
    spec['tasks'][1]['resources']['max_cores'] = 8
    node_groups = [{'name': 'day', 'default': True, 'cores': 96,
                    'memory_mb': 512000, 'seconds': 86400}]
    with TemporaryDirectory() as temporary, \
            patch('kinbot.anl.site._partitions', return_value=node_groups):
        root = Path(temporary)
        run_dir = prepare(_write_spec(root, spec), root / 'run')
        resolved = json.loads((run_dir / 'workflow.json').read_text())
        by_id = {task['id']: task for task in resolved['tasks']}
        assert by_id['l3_geometry']['resources']['cores'] == 8
        assert by_id['harmonic']['resources']['cores'] == 16
        assert by_id['harmonic']['resources']['use_all_node_memory'] is True
        script = (run_dir / 'tasks' / 'l2_geometry' / 'job.slurm').read_text()
        assert '#SBATCH --mem=0\n' in script


def test_missing_sbatch_does_not_leave_uncertain_submission_state():
    with TemporaryDirectory() as temporary:
        root = Path(temporary)
        run_dir = prepare(_write_spec(root, dispatch_spec()), root / 'run')
        with patch('kinbot.anl.dispatch.subprocess.run',
                   side_effect=FileNotFoundError('sbatch')):
            with pytest.raises(FileNotFoundError):
                advance(run_dir, submit=True)
        state = json.loads((run_dir / 'state.json').read_text())
        assert state['tasks']['l2_geometry']['status'] == 'staged'


def test_completed_geometry_or_artifact_mutation_blocks_children():
    with TemporaryDirectory() as temporary:
        root = Path(temporary)
        run_dir = prepare(_write_spec(root, dispatch_spec()), root / 'run')
        _mock_execution(run_dir, 'l2_geometry', geometry='final.xyz')
        advance(run_dir)
        final = run_dir / 'tasks' / 'l2_geometry' / 'final.xyz'
        final.write_text(final.read_text().replace('0.630', '0.635'))
        with pytest.raises(RuntimeError, match='artifact|geometry'):
            advance(run_dir)


def test_staged_input_mutation_blocks_submission():
    with TemporaryDirectory() as temporary:
        root = Path(temporary)
        run_dir = prepare(_write_spec(root, dispatch_spec()), root / 'run')
        job = run_dir / 'tasks' / 'l2_geometry' / 'job.slurm'
        job.write_text(job.read_text().replace('--exclusive', '--oversubscribe'))
        with pytest.raises(RuntimeError, match='staged job.slurm changed'):
            advance(run_dir, submit=True)


def test_failed_task_can_be_archived_and_retried():
    spec = dispatch_spec()
    spec['tasks'] = [{
        'id': 'sample', 'kind': 'external', 'backend': 'fake',
        'resources': {'cores': 1, 'memory_mb': 512,
                      'walltime': '00:10:00'},
        'input_name': 'sample.inp',
        'input_template': '{{XYZ}}\n',
        'command': [sys.executable, '-c', 'raise SystemExit(2)'],
        'required_outputs': ['sample.out'],
    }]
    with TemporaryDirectory() as temporary:
        root = Path(temporary)
        run_dir = prepare(_write_spec(root, spec), root / 'run')
        with pytest.raises(RuntimeError, match='Program exited'):
            run_task(run_dir / 'tasks' / 'sample' / 'task.json')
        assert advance(run_dir)['tasks']['sample']['status'] == 'failed'
        archive = retry_failed(run_dir, 'sample')
        assert (archive / 'execution.json').is_file()
        assert not (run_dir / 'tasks' / 'sample' / 'execution.json').exists()
        assert advance(run_dir)['tasks']['sample']['status'] == 'staged'


def test_gaussian_framework_group_failure_has_narrow_same_geometry_recovery():
    spec = dispatch_spec()
    with TemporaryDirectory() as temporary:
        root = Path(temporary)
        run_dir = prepare(_write_spec(root, spec), root / 'run')
        _mock_execution(run_dir, 'l2_geometry', geometry='final.xyz')
        advance(run_dir)
        _mock_execution(run_dir, 'l3_geometry', geometry='final.xyz')
        advance(run_dir)
        directory = run_dir / 'tasks' / 'gaussian_vpt2'
        original_geometry = (directory / 'geometry.xyz').read_bytes()
        original_input = (directory / 'vpt2.com').read_text()
        (directory / 'vpt2.log').write_text(
            'Second-order Perturbative Anharmonic Analysis\n'
            'ERROR: Inconsistency found in framework group definition:\n'
            'New: C1 - Old: T\n'
            'Error termination via Lnk1e in l717.exe\n')
        (directory / 'execution.json').write_text(json.dumps({
            'schema': 1, 'task_id': 'gaussian_vpt2',
            'geometry_sha256': json.loads(
                (directory / 'task.json').read_text())['geometry_sha256'],
            'status': 'failed', 'error': 'Program exited with status 1.',
        }))
        state_path = run_dir / 'state.json'
        state = json.loads(state_path.read_text())
        state['tasks']['gaussian_vpt2']['status'] = 'failed'
        state_path.write_text(json.dumps(state))

        archive = recover_gaussian_vpt2_symmetry(
            run_dir, 'gaussian_vpt2')
        assert (archive / 'vpt2.com').read_text() == original_input
        assert (archive / 'vpt2.log').is_file()
        assert (directory / 'geometry.xyz').read_bytes() == original_geometry
        recovered = (directory / 'vpt2.com').read_text()
        assert 'Freq=Anharmonic' in recovered
        assert 'NoSymm' not in recovered
        assert 'Symmetry=(PG=C1)' in recovered
        assert 'B2PLYP/cc-pVTZ' in recovered
        workflow = json.loads((run_dir / 'workflow.json').read_text())
        task = next(item for item in workflow['tasks']
                    if item['id'] == 'gaussian_vpt2')
        assert task['recovery']['geometry_changed'] is False
        state = json.loads(state_path.read_text())
        assert state['tasks']['gaussian_vpt2']['status'] == 'staged'
        assert state['tasks']['gaussian_vpt2']['attempt'] == 2


def test_gaussian_framework_recovery_adds_c1_to_prior_symmetry_retry():
    spec = dispatch_spec()
    task = next(item for item in spec['tasks']
                if item['id'] == 'gaussian_vpt2')
    task['input_template'] = task['input_template'].replace(' NoSymm', '')
    with TemporaryDirectory() as temporary:
        root = Path(temporary)
        run_dir = prepare(_write_spec(root, spec), root / 'run')
        _mock_execution(run_dir, 'l2_geometry', geometry='final.xyz')
        advance(run_dir)
        _mock_execution(run_dir, 'l3_geometry', geometry='final.xyz')
        advance(run_dir)
        directory = run_dir / 'tasks' / 'gaussian_vpt2'
        original_geometry = (directory / 'geometry.xyz').read_bytes()
        (directory / 'vpt2.log').write_text(
            'Framework group T[O(C),X(H4)]\n'
            'ERROR: Inconsistency found in framework group definition:\n'
            'New: TD - Old: T\n'
            'Error termination via Lnk1e in l717.exe\n')
        state_path = run_dir / 'state.json'
        state = json.loads(state_path.read_text())
        state['tasks']['gaussian_vpt2'].update(status='failed', attempt=2)
        state_path.write_text(json.dumps(state))

        archive = recover_gaussian_vpt2_symmetry(
            run_dir, 'gaussian_vpt2')
        assert archive.name == '2'
        assert 'Symmetry=(PG=C1)' not in (archive / 'vpt2.com').read_text()
        assert (directory / 'geometry.xyz').read_bytes() == original_geometry
        recovered = (directory / 'vpt2.com').read_text()
        assert recovered.count('Symmetry=(PG=C1)') == 1
        assert 'Freq=Anharmonic Symmetry=(PG=C1)' in recovered
        workflow = json.loads((run_dir / 'workflow.json').read_text())
        recovered_task = next(item for item in workflow['tasks']
                              if item['id'] == 'gaussian_vpt2')
        assert recovered_task['recovery']['observed_framework_change'] == \
            'New: TD - Old: T'
        state = json.loads(state_path.read_text())
        assert state['tasks']['gaussian_vpt2']['attempt'] == 3


def test_gaussian_symmetry_recovery_rejects_unrelated_failure():
    spec = dispatch_spec()
    with TemporaryDirectory() as temporary:
        root = Path(temporary)
        run_dir = prepare(_write_spec(root, spec), root / 'run')
        _mock_execution(run_dir, 'l2_geometry', geometry='final.xyz')
        advance(run_dir)
        _mock_execution(run_dir, 'l3_geometry', geometry='final.xyz')
        advance(run_dir)
        directory = run_dir / 'tasks' / 'gaussian_vpt2'
        (directory / 'vpt2.log').write_text(
            'SCF convergence failure\nError termination via Lnk1e\n')
        state_path = run_dir / 'state.json'
        state = json.loads(state_path.read_text())
        state['tasks']['gaussian_vpt2']['status'] = 'failed'
        state_path.write_text(json.dumps(state))
        with pytest.raises(RuntimeError, match='not the framework-group'):
            recover_gaussian_vpt2_symmetry(run_dir, 'gaussian_vpt2')


def test_gaussian_symmetry_recovery_accepts_general_named_group_change():
    spec = dispatch_spec()
    with TemporaryDirectory() as temporary:
        root = Path(temporary)
        run_dir = prepare(_write_spec(root, spec), root / 'run')
        _mock_execution(run_dir, 'l2_geometry', geometry='final.xyz')
        advance(run_dir)
        _mock_execution(run_dir, 'l3_geometry', geometry='final.xyz')
        advance(run_dir)
        directory = run_dir / 'tasks' / 'gaussian_vpt2'
        (directory / 'vpt2.log').write_text(
            'ERROR: Inconsistency found in framework group definition:\n'
            'New: C2V - Old: CS\n'
            'Error termination via Lnk1e in l717.exe\n')
        state_path = run_dir / 'state.json'
        state = json.loads(state_path.read_text())
        state['tasks']['gaussian_vpt2']['status'] = 'failed'
        state_path.write_text(json.dumps(state))
        recover_gaussian_vpt2_symmetry(run_dir, 'gaussian_vpt2')
        workflow = json.loads((run_dir / 'workflow.json').read_text())
        recovered = next(task for task in workflow['tasks']
                         if task['id'] == 'gaussian_vpt2')
        assert recovered['recovery']['observed_framework_change'] == \
            'New: C2V - Old: CS'


def test_failed_task_does_not_stop_independent_work_and_blocks_only_children():
    def task(ident, depends_on=()):
        record = {
            'id': ident, 'kind': 'external', 'backend': 'fake',
            'resources': {'cores': 1, 'memory_mb': 512,
                          'walltime': '00:10:00'},
            'input_name': f'{ident}.inp',
            'input_template': '{{XYZ}}\n',
            'command': [sys.executable, '-c', 'pass'],
            'required_outputs': [f'{ident}.out'],
        }
        if depends_on:
            record['depends_on'] = list(depends_on)
        return record

    spec = {
        'schema': 1, 'name': 'independent-failure',
        'molecule': dispatch_spec()['molecule'],
        'limits': {'max_nodes': 2},
        'tasks': [task('failed'), task('independent'),
                  task('child', ('failed',))],
    }
    with TemporaryDirectory() as temporary:
        root = Path(temporary)
        run_dir = prepare(_write_spec(root, spec), root / 'run')
        state_path = run_dir / 'state.json'
        state = json.loads(state_path.read_text())
        state['tasks']['failed']['status'] = 'failed'
        state_path.write_text(json.dumps(state))

        response = subprocess.CompletedProcess(
            ['sbatch'], 0, stdout='12345\n', stderr='')
        with patch('kinbot.anl.dispatch.subprocess.run', return_value=response):
            state = advance(run_dir, submit=True)

        assert state['tasks']['failed']['status'] == 'failed'
        assert state['tasks']['independent']['status'] == 'submitted'
        assert state['tasks']['independent']['job_id'] == '12345'
        assert state['tasks']['child']['status'] == 'blocked'
        assert state['tasks']['child']['blocked_by'] == ['failed']

        retry_failed(run_dir, 'failed')
        state = json.loads(state_path.read_text())
        assert state['tasks']['failed']['status'] == 'staged'
        assert 'child' not in state['tasks']
        with patch('kinbot.anl.dispatch._job_active', return_value=True):
            assert advance(run_dir)['tasks'].get('child') is None


def test_runtime_failure_makes_optional_component_unavailable_and_skips_unsent_work():
    def task(ident, *, skips=()):
        record = {
            'id': ident, 'kind': 'external', 'backend': 'fake',
            'resources': {'cores': 1, 'memory_mb': 512,
                          'walltime': '00:10:00'},
            'input_name': f'{ident}.inp',
            'input_template': '{{XYZ}}\n',
            'command': [sys.executable, '-c', 'pass'],
            'required_outputs': [f'{ident}.out'],
            'failure_policy': 'skip_component',
            'component_families': ['expensive_correction'],
        }
        if skips:
            record['failure_skips'] = list(skips)
        return record

    spec = {
        'schema': 1, 'name': 'optional-component-failure',
        'molecule': dispatch_spec()['molecule'],
        'limits': {'max_nodes': 2},
        'tasks': [task('small', skips=('large',)), task('large')],
    }
    with TemporaryDirectory() as temporary:
        root = Path(temporary)
        run_dir = prepare(_write_spec(root, spec), root / 'run')
        state_path = run_dir / 'state.json'
        state = json.loads(state_path.read_text())
        entry = state['tasks']['small']
        (run_dir / 'tasks' / 'small' / 'execution.json').write_text(
            json.dumps({
                'schema': 1, 'task_id': 'small',
                'geometry_sha256': entry['geometry_sha256'],
                'status': 'failed', 'failure_phase': 'execution',
                'error': 'Program exited with status 137.',
            }))

        state = advance(run_dir)
        assert state['tasks']['small']['status'] == 'unavailable'
        assert state['tasks']['small']['unavailable_reason'] == \
            'Program exited with status 137.'
        assert state['tasks']['large']['status'] == 'skipped'
        assert state['tasks']['large']['resume_status'] == 'staged'

        retry_failed(run_dir, 'small')
        state = json.loads(state_path.read_text())
        assert state['tasks']['small']['status'] == 'staged'
        assert state['tasks']['large']['status'] == 'staged'


def test_failed_l3_geometry_stages_single_points_on_l2_and_skips_only_frequency():
    spec = interface_validation_spec(dispatch_spec()['molecule'])
    for task in spec['tasks']:
        task['resources'].update(
            cores=4, memory_mb=64000, partition='test')
    with TemporaryDirectory() as temporary:
        root = Path(temporary)
        run_dir = prepare(_write_spec(root, spec), root / 'run')
        _mock_execution(run_dir, 'l2_geometry', geometry='final.xyz')
        state = advance(run_dir)
        l2_hash = state['tasks']['l2_geometry']['final_geometry_sha256']
        l3 = state['tasks']['l3_geometry']
        (run_dir / 'tasks' / 'l3_geometry' / 'execution.json').write_text(
            json.dumps({
                'schema': 1, 'task_id': 'l3_geometry',
                'geometry_sha256': l3['geometry_sha256'],
                'status': 'failed', 'failure_phase': 'execution',
                'error': 'optimizer exhausted its step limit',
            }))

        state = advance(run_dir)
        assert state['tasks']['l3_geometry']['status'] == 'unavailable'
        assert state['tasks']['harmonic']['status'] == 'skipped'
        for ident in ('f12_tz', 'f12_qz', 'cfour_dboc'):
            assert state['tasks'][ident]['status'] == 'staged'
            assert state['tasks'][ident]['geometry_from'] == 'l2_geometry'
            assert state['tasks'][ident]['geometry_sha256'] == l2_hash


def test_l3_preflight_failure_uses_the_same_l2_single_point_fallback():
    spec = interface_validation_spec(dispatch_spec()['molecule'])
    for task in spec['tasks']:
        task['resources'].update(
            cores=4, memory_mb=64000, partition='test')
    with TemporaryDirectory() as temporary:
        root = Path(temporary)
        run_dir = prepare(_write_spec(root, spec), root / 'run')
        _mock_execution(run_dir, 'l2_geometry', geometry='final.xyz')
        state = advance(run_dir)
        l2_hash = state['tasks']['l2_geometry']['final_geometry_sha256']
        _mark_preflight_unavailable(
            spec, state, 'l3_geometry', 'calculator unavailable')
        (run_dir / 'state.json').write_text(json.dumps(state))

        state = advance(run_dir)
        assert state['tasks']['l3_geometry']['status'] == 'unavailable'
        assert state['tasks']['harmonic']['status'] == 'skipped'
        for ident in ('f12_tz', 'f12_qz', 'cfour_dboc'):
            assert state['tasks'][ident]['status'] == 'staged'
            assert state['tasks'][ident]['geometry_from'] == 'l2_geometry'
            assert state['tasks'][ident]['geometry_sha256'] == l2_hash


def test_parser_failure_of_optional_component_remains_a_hard_failure():
    tasks = []
    for ident in ('first', 'second'):
        tasks.append({
            'id': ident, 'kind': 'external', 'backend': 'fake',
            'resources': {'cores': 1, 'memory_mb': 512,
                          'walltime': '00:10:00'},
            'input_name': f'{ident}.inp',
            'input_template': '{{XYZ}}\n',
            'command': [sys.executable, '-c', 'pass'],
            'required_outputs': [f'{ident}.out'],
            'failure_policy': 'skip_component',
            'component_families': ['correction'],
            **({'failure_skips': ['second']} if ident == 'first' else {}),
        })
    spec = {
        'schema': 1, 'name': 'optional-component-parser-failure',
        'molecule': dispatch_spec()['molecule'],
        'limits': {'max_nodes': 2}, 'tasks': tasks,
    }
    with TemporaryDirectory() as temporary:
        root = Path(temporary)
        run_dir = prepare(_write_spec(root, spec), root / 'run')
        state = json.loads((run_dir / 'state.json').read_text())
        entry = state['tasks']['first']
        (run_dir / 'tasks' / 'first' / 'execution.json').write_text(
            json.dumps({
                'schema': 1, 'task_id': 'first',
                'geometry_sha256': entry['geometry_sha256'],
                'status': 'failed', 'failure_phase': 'validation',
                'error': 'parsed method disagrees with request',
            }))
        state = advance(run_dir)
        assert state['tasks']['first']['status'] == 'failed'
        assert state['tasks']['second']['status'] == 'staged'


def test_time_limited_mrcc_task_can_resume_with_saved_amplitudes():
    molecule = dispatch_spec()['molecule']
    task = mrcc_task(
        'high', 'CCSDTQ(P)', 'cc-pVDZ', multiplicity=1,
        geometry_from='initial', walltime='24:00:00', max_cores=4,
        partition='day')
    task['resources'].update(
        cores=4, memory_mb=126000, use_all_node_memory=True)
    spec = {'schema': 1, 'name': 'mrcc-resume', 'molecule': molecule,
            'limits': {'max_nodes': 1}, 'tasks': [task]}
    partitions = [{
        'name': 'week', 'default': False, 'cores': 96,
        'memory_mb': 126000, 'seconds': 7 * 24 * 3600,
    }]
    with TemporaryDirectory() as temporary:
        root = Path(temporary)
        run_dir = prepare(_write_spec(root, spec), root / 'run')
        directory = run_dir / 'tasks' / 'high'
        (directory / 'fort.16').write_bytes(b'saved amplitudes')
        (directory / 'high.out').write_text('unfinished native output\n')
        (directory / 'high.err').write_text('time limit\n')
        (directory / 'slurm.stderr').write_text('DUE TO TIME LIMIT\n')
        state_path = run_dir / 'state.json'
        state = json.loads(state_path.read_text())
        state['tasks']['high'].update(status='failed', error='time limit')
        state_path.write_text(json.dumps(state))

        with patch('kinbot.anl.site._partitions', return_value=partitions):
            archive = resume_mrcc_failed(
                run_dir, 'high', max_cores=8, partition='week')

        assert (archive / 'high.out').read_text() == \
            'unfinished native output\n'
        assert (archive / 'resume_manifest.json').is_file()
        assert (directory / 'fort.16').read_bytes() == b'saved amplitudes'
        assert not (directory / 'high.out').exists()
        assert 'rest=1\n' in (directory / 'MINP').read_text()
        assert '#SBATCH --time=7-00:00:00\n' in \
            (directory / 'job.slurm').read_text()
        assert '#SBATCH --partition=week\n' in \
            (directory / 'job.slurm').read_text()
        workflow = json.loads((run_dir / 'workflow.json').read_text())
        resumed = workflow['tasks'][0]
        assert resumed['resources']['cores'] == 8
        assert resumed['resources']['memory_mb'] == 126000
        assert resumed['restart']['checkpoint'] == 'fort.16'
        state = json.loads(state_path.read_text())
        assert state['tasks']['high']['status'] == 'staged'
        assert state['tasks']['high']['restart_checkpoint_bytes'] == 16
        assert advance(run_dir)['tasks']['high']['status'] == 'staged'


def test_failed_cfour_ccsdt_q_can_be_rerouted_to_direct_mrcc():
    molecule = dispatch_spec()['molecule']
    task = cfour_energy_task(
        'high', 'CCSDT(Q)', 'cc-pVDZ', multiplicity=1,
        geometry_from='initial', partition='day')
    task['resources'].update(
        cores=8, memory_mb=126000, use_all_node_memory=True)
    spec = {'schema': 1, 'name': 'cfour-migration', 'molecule': molecule,
            'limits': {'max_nodes': 1}, 'tasks': [task]}
    with TemporaryDirectory() as temporary:
        root = Path(temporary)
        run_dir = prepare(_write_spec(root, spec), root / 'run')
        directory = run_dir / 'tasks' / 'high'
        old_input = (directory / 'ZMAT').read_text()
        (directory / 'high.out').write_text(
            'calling xncc\nThe final electronic energy is -1.0 a.u.\n')
        state_path = run_dir / 'state.json'
        state = json.loads(state_path.read_text())
        state['tasks']['high'].update(status='failed', error='wrong driver')
        state_path.write_text(json.dumps(state))

        archive = reroute_cfour_higher_order_to_mrcc(run_dir, 'high')

        assert (archive / 'ZMAT').read_text() == old_input
        new_input = (directory / 'MINP').read_text()
        assert 'calc=CCSDT(Q)' in new_input
        assert 'ccprog=mrcc' in new_input
        assert 'scftype=RHF' in new_input
        workflow = json.loads((run_dir / 'workflow.json').read_text())
        assert workflow['tasks'][0]['backend'] == 'mrcc'
        assert workflow['tasks'][0]['command'] == ['dmrcc']
        state = json.loads(state_path.read_text())
        assert state['tasks']['high']['status'] == 'staged'
        assert 'direct MRCC' in state['tasks']['high']['migration']
        assert advance(run_dir)['tasks']['high']['status'] == 'staged'


def test_parser_failure_can_be_recovered_without_rerunning_native_job():
    with TemporaryDirectory() as temporary:
        root = Path(temporary)
        spec = dispatch_spec()
        vpt2 = next(task for task in spec['tasks']
                    if task['id'] == 'gaussian_vpt2')
        vpt2['input_template'] = vpt2['input_template'].replace(
            'NoSymm', 'Symmetry=(PG=C1)')
        run_dir = prepare(_write_spec(root, spec), root / 'run')
        _mock_execution(run_dir, 'l2_geometry', geometry='final.xyz')
        advance(run_dir)
        _mock_execution(run_dir, 'l3_geometry', geometry='final.xyz')
        advance(run_dir)

        directory = run_dir / 'tasks' / 'gaussian_vpt2'
        output = """#p B2PLYP/cc-pVTZ Freq=Anharmonic Symmetry=(PG=C1) EmpiricalDispersion=G
 D3BJ
 Framework group  C1[X(CH4)]
 Fundamental Bands
 Mode(n) Status E(harm) E(anharm) I(harm) I(anharm)
    1(1) active 1000.00 980.00 0.10 0.11
 Overtones
 Anharmonic Zero Point Energy
 Harmonic       : cm-1 = 500.00000 ; Kcal/mol = 1.430
 Anharmonic Pot.: cm-1 = -10.00000 ; Kcal/mol = -0.029
 Watson+Coriolis: cm-1 = 0.00000 ; Kcal/mol = 0.000
 Total Anharm   : cm-1 = 490.00000 ; Kcal/mol = 1.401
"""
        output += ' Gaussian archive payload\n' * 700
        output += ' Normal termination of Gaussian 16\n'
        (directory / 'vpt2.log').write_text(output)
        (directory / 'vpt2.err').write_text('')

        state_path = run_dir / 'state.json'
        state = json.loads(state_path.read_text())
        state['tasks']['gaussian_vpt2'].update(
            status='failed', execution='failed', error='old parser error')
        state_path.write_text(json.dumps(state))
        failed = {
            'schema': 1,
            'task_id': 'gaussian_vpt2',
            'geometry_sha256': state['tasks']['gaussian_vpt2']['geometry_sha256'],
            'status': 'failed',
            'error': 'Gaussian output dispersion disagrees with the requested level.',
            'traceback': 'details[\"parsed_result\"] = parse_result(output, request)',
        }
        (directory / 'execution.json').write_text(json.dumps(failed))

        with patch('kinbot.anl.dispatch.subprocess.run',
                   side_effect=AssertionError('native program must not rerun')):
            result = reparse_failed(run_dir, 'gaussian_vpt2')
        assert result['status'] == 'executed'
        assert result['details']['reparsed_without_execution'] is True
        assert result['details']['returncode_source'] == \
            'original_parser_path_and_native_success_marker'
        assert result['details']['parsed_result']['dispersion'] == 'GD3BJ'
        assert 'execution.failed.json' in result['artifacts']
        assert (directory / 'execution.failed.json').is_file()
        assert json.loads((directory / 'execution.failed.json').read_text()) == failed
        saved_state = json.loads(state_path.read_text())
        assert saved_state['tasks']['gaussian_vpt2']['status'] == 'complete'
        assert 'error' not in saved_state['tasks']['gaussian_vpt2']
        assert reparse_failed(run_dir, 'gaussian_vpt2') == result


@pytest.mark.parametrize(
    ('ident', 'method', 'native_results', 'expected'),
    (
        (
            'ccsdtq_dz', 'CCSDT(Q)',
            'Total CCSDT energy [au]: -39.716126916675\n'
            'Total CCSDT[Q] energy [au]: -39.716201539184\n'
            'Total CCSDT(Q)/A energy [au]: -39.716240924926\n'
            'Total CCSDT(Q)/B energy [au]: -39.716241160157\n',
            -39.716241160157,
        ),
        (
            'ccsdtqp_dz', 'CCSDTQ(P)',
            'Total CCSDTQ energy [au]: -39.716248102779\n'
            'Total CCSDTQ[P] energy [au]: -39.716252624143\n'
            'Total CCSDTQ(P)/A energy [au]: -39.716252624143\n'
            'Total CCSDTQ(P)/B energy [au]: -39.716252675414\n',
            -39.716252675414,
        ),
    ),
)
def test_advance_automatically_reparses_old_successful_mrcc_output(
        ident, method, native_results, expected):
    with TemporaryDirectory() as temporary:
        root = Path(temporary)
        task = mrcc_task(
            ident, method, 'cc-pVDZ', multiplicity=2,
            reference='ROHF', geometry_from='initial')
        task['resources'].update(
            cores=1, memory_mb=4096, partition='test')
        spec = {
            'schema': 1, 'name': 'automatic-parser-recovery',
            'molecule': {
                'symbols': ['C', 'H', 'H', 'H'],
                'positions': [[0., 0., 0.], [0., 0., 1.],
                              [0.94, 0., -0.33], [-0.47, 0.81, -0.33]],
                'charge': 0, 'multiplicity': 2,
            },
            'limits': {'max_nodes': 1}, 'tasks': [task],
        }
        run_dir = prepare(_write_spec(root, spec), root / 'run')
        directory = run_dir / 'tasks' / ident
        output = f"""Input file:
basis=cc-pVDZ
calc={method}
ccprog=mrcc
scftype=ROHF
rohftype=semicanonical
rohfcore=semicanonical
core=frozen
{native_results}Normal termination of mrcc.
"""
        (directory / f'{ident}.out').write_text(output)
        (directory / f'{ident}.err').write_text('')
        state_path = run_dir / 'state.json'
        state = json.loads(state_path.read_text())
        entry = state['tasks'][ident]
        entry.update(status='failed', execution='failed',
                     error='old parser error')
        state_path.write_text(json.dumps(state))
        failed = {
            'schema': 1, 'task_id': ident,
            'geometry_sha256': entry['geometry_sha256'],
            'status': 'failed',
            'error': f'Expected exactly one MRCC {method} total energy; found 0.',
            'traceback': 'details["parsed_result"] = parse_result(output, request)',
        }
        (directory / 'execution.json').write_text(json.dumps(failed))

        recovered = advance(run_dir)
        assert recovered['tasks'][ident]['status'] == 'complete'
        assert recovered['tasks'][ident]['automatically_reparsed'] is True
        execution = json.loads((directory / 'execution.json').read_text())
        parsed = execution['details']['parsed_result']
        assert parsed['energy_hartree'] == pytest.approx(expected)
        assert parsed['selected_perturbative_variant'] == 'B'
        assert json.loads(
            (directory / 'execution.failed.json').read_text()) == failed


def test_reparse_recovers_native_mrcc_success_misclassified_as_execution_failure():
    with TemporaryDirectory() as temporary:
        root = Path(temporary)
        ident = 'ccsdtqp_dz'
        task = mrcc_task(
            ident, 'CCSDTQ(P)', 'cc-pVDZ', multiplicity=2,
            reference='ROHF', geometry_from='initial')
        task['resources'].update(
            cores=1, memory_mb=4096, partition='test')
        spec = {
            'schema': 1, 'name': 'native-success-recovery',
            'molecule': {
                'symbols': ['C', 'H', 'H', 'H'],
                'positions': [[0., 0., 0.], [0., 0., 1.],
                              [0.94, 0., -0.33], [-0.47, 0.81, -0.33]],
                'charge': 0, 'multiplicity': 2,
            },
            'limits': {'max_nodes': 1}, 'tasks': [task],
        }
        run_dir = prepare(_write_spec(root, spec), root / 'run')
        directory = run_dir / 'tasks' / ident
        (directory / f'{ident}.out').write_text(
            'Input file:\n'
            'basis=cc-pVDZ\ncalc=CCSDTQ(P)\nccprog=mrcc\n'
            'scftype=ROHF\nrohftype=semicanonical\n'
            'rohfcore=semicanonical\ncore=frozen\n'
            'Total CCSDTQ energy [au]: -39.716248102779\n'
            'Total CCSDTQ(P)/A energy [au]: -39.716252624143\n'
            'Total CCSDTQ(P)/B energy [au]: -39.716252675414\n'
            'Normal termination of mrcc.\n')
        (directory / f'{ident}.err').write_text('')
        state_path = run_dir / 'state.json'
        state = json.loads(state_path.read_text())
        entry = state['tasks'][ident]
        entry.update(status='failed', execution='failed',
                     error='Program exited with status 1.')
        state_path.write_text(json.dumps(state))
        failed = {
            'schema': 1, 'task_id': ident,
            'geometry_sha256': entry['geometry_sha256'],
            'status': 'failed',
            'error': 'Program exited with status 1.',
            'traceback': ('Traceback: _run_external raised RuntimeError after '
                          'the site launcher returned nonzero.'),
        }
        (directory / 'execution.json').write_text(json.dumps(failed))

        with patch('kinbot.anl.dispatch.subprocess.run',
                   side_effect=AssertionError('native program must not rerun')):
            result = reparse_failed(run_dir, ident)
        assert result['status'] == 'executed'
        assert result['details']['returncode'] == 1
        assert result['details']['returncode_source'] == \
            'preserved_dispatch_failure_and_native_success_marker'
        assert result['details']['native_success_recovered'] is True
        assert result['details']['parsed_result']['energy_hartree'] == \
            pytest.approx(-39.716252675414)
        assert result['details']['parsed_result'][
            'selected_perturbative_variant'] == 'B'
        assert json.loads(
            (directory / 'execution.failed.json').read_text()) == failed

        with (directory / f'{ident}.out').open('a') as output:
            output.write('changed after recovery\n')
        with pytest.raises(RuntimeError, match='artifact .* changed'):
            reparse_failed(run_dir, ident)


def test_native_success_recovery_rejects_changed_staged_input():
    with TemporaryDirectory() as temporary:
        root = Path(temporary)
        ident = 'ccsdtq_dz'
        task = mrcc_task(
            ident, 'CCSDT(Q)', 'cc-pVDZ', multiplicity=1,
            reference='RHF', geometry_from='initial')
        task['resources'].update(
            cores=1, memory_mb=4096, partition='test')
        spec = {
            'schema': 1, 'name': 'reject-changed-input',
            'molecule': {
                'symbols': ['H', 'H'],
                'positions': [[0., 0., 0.], [0., 0., 0.74]],
                'charge': 0, 'multiplicity': 1,
            },
            'limits': {'max_nodes': 1}, 'tasks': [task],
        }
        run_dir = prepare(_write_spec(root, spec), root / 'run')
        directory = run_dir / 'tasks' / ident
        (directory / f'{ident}.out').write_text(
            'Input file:\n'
            'basis=cc-pVDZ\ncalc=CCSDT(Q)\nccprog=mrcc\n'
            'scftype=RHF\ncore=frozen\n'
            'Total CCSDT(Q)/B energy [au]: -1.0\n'
            'Normal termination of mrcc.\n')
        (directory / f'{ident}.err').write_text('')
        state_path = run_dir / 'state.json'
        state = json.loads(state_path.read_text())
        entry = state['tasks'][ident]
        entry.update(status='failed', execution='failed', error='old failure')
        state_path.write_text(json.dumps(state))
        (directory / 'execution.json').write_text(json.dumps({
            'schema': 1, 'task_id': ident,
            'geometry_sha256': entry['geometry_sha256'],
            'status': 'failed', 'error': 'old failure',
        }))
        with (directory / 'MINP').open('a') as inp:
            inp.write('edited=true\n')

        with pytest.raises(RuntimeError, match='staged MINP changed'):
            reparse_failed(run_dir, ident)
        assert not (directory / 'execution.failed.json').exists()


def _monatomic_geometry_spec():
    source = dispatch_spec()
    task = next(item for item in source['tasks']
                if item['id'] == 'l3_geometry')
    task['geometry_from'] = 'initial'
    return {
        'schema': 1, 'name': 'monatomic-geometry-identity',
        'molecule': {
            'symbols': ['H'], 'positions': [[0., 0., 0.]],
            'charge': 0, 'multiplicity': 2,
        },
        'limits': {'max_nodes': 1}, 'tasks': [task],
    }


def test_monatomic_geometry_completes_without_qc_or_slurm():
    with TemporaryDirectory() as temporary:
        root = Path(temporary)
        run_dir = prepare(
            _write_spec(root, _monatomic_geometry_spec()), root / 'run')
        with patch('kinbot.anl.dispatch.subprocess.run',
                   side_effect=AssertionError('must not submit or run QC')):
            state = advance(run_dir, submit=True)
        assert state['tasks']['l3_geometry']['status'] == 'complete'
        directory = run_dir / 'tasks' / 'l3_geometry'
        execution = json.loads((directory / 'execution.json').read_text())
        assert execution['details']['optimizer'] == 'identity_monatomic'
        assert execution['details']['calculation_performed'] is False
        assert execution['details']['generated_files'] == []
        assert read(directory / 'final.xyz').get_chemical_symbols() == ['H']
        assert not list(directory.glob('l3_geometry_step_*'))


def test_failed_legacy_monatomic_geometry_is_recovered_without_qc():
    with TemporaryDirectory() as temporary:
        root = Path(temporary)
        spec = _monatomic_geometry_spec()
        child = next(item for item in dispatch_spec()['tasks']
                     if item['id'] == 'harmonic')
        spec['tasks'].append(child)
        run_dir = prepare(
            _write_spec(root, spec), root / 'run')
        directory = run_dir / 'tasks' / 'l3_geometry'
        state_path = run_dir / 'state.json'
        state = json.loads(state_path.read_text())
        entry = state['tasks']['l3_geometry']
        entry.update(status='failed', execution='failed',
                     error='legacy atomic force evaluation failed')
        state['tasks']['harmonic'] = {
            'status': 'blocked', 'geometry_from': 'l3_geometry',
            'blocked_by': ['l3_geometry'],
        }
        state_path.write_text(json.dumps(state))
        failed = {
            'schema': 1, 'task_id': 'l3_geometry',
            'geometry_sha256': entry['geometry_sha256'],
            'status': 'failed',
            'error': 'legacy atomic force evaluation failed',
            'traceback': 'old calculator traceback',
        }
        (directory / 'execution.json').write_text(json.dumps(failed))

        with patch('kinbot.anl.dispatch.subprocess.run',
                   side_effect=AssertionError('must not submit or run QC')):
            recovered = advance(run_dir, submit=False)
        assert recovered['tasks']['l3_geometry']['status'] == 'complete'
        assert recovered['tasks']['harmonic']['status'] == 'staged'
        execution = json.loads((directory / 'execution.json').read_text())
        assert execution['details']['recovered_without_qc_execution'] is True
        assert json.loads(
            (directory / 'execution.failed.json').read_text()) == failed


def test_failed_one_electron_f12_scale_nan_is_recovered_without_qc():
    molecule = {
        'symbols': ['H'], 'positions': [[0., 0., 0.]],
        'charge': 0, 'multiplicity': 2,
    }
    generated = interface_validation_spec(molecule)
    task = next(item for item in generated['tasks'] if item['id'] == 'f12_tz')
    task['geometry_from'] = 'initial'
    task.pop('geometry_fallback', None)
    task['resources'] = {
        'cores': 4, 'memory_mb': 50000, 'walltime': '04:00:00',
        'min_stack_mw': 1024,
    }
    task['input_template'] = task['input_template'].replace(
        'rhf\n\n', 'rhf\nuccsd(t)-f12b,scale_trip=1\n')
    task['result_parser'].pop('rank_exact_electrons')
    task['result_parser'].pop('effective_method')
    spec = {
        'schema': 1, 'name': 'old-one-electron-f12',
        'molecule': molecule,
        'limits': {'max_nodes': 1, 'max_cores_per_node': 8,
                   'max_memory_mb_per_node': 64000},
        'tasks': [task],
    }
    output = """basis=cc-pVTZ-F12
rhf
uccsd(t)-f12b,scale_trip=1
 PROGRAMS   *        TOTAL  UCCSD(T)   RHF-SCF       INT
 Number of N-1 electron functions:               1
 Number of N-2 electron functions:               0
 New reference energy                 -0.499946213253
 RMP2-F12 correlation energy           0.000000000000
 Starting UCCSD calculation
 New reference energy                 -0.499946213253
 UCCSD-F12b singles energy            -0.000000000000
 UCCSD-F12b pair energy                0.000000000000
 UCCSD-F12b correlation energy        -0.000000000000
 Scale factor for triples energy                  NaN
 ? Error
 ? NaN detected by ieee_is_nan
 ? The problem occurs in is_nan
 GLOBAL ERROR fehler on processor   0
"""
    with TemporaryDirectory() as temporary:
        root = Path(temporary)
        run_dir = prepare(_write_spec(root, spec), root / 'run')
        directory = run_dir / 'tasks' / 'f12_tz'
        (directory / 'f12_tz.out').write_text(output)
        (directory / 'launcher.stdout').write_text('')
        (directory / 'launcher.stderr').write_text('MPI abort after Molpro NaN\n')
        failed = {
            'schema': 1, 'task_id': 'f12_tz',
            'geometry_sha256': json.loads(
                (directory / 'task.json').read_text())['geometry_sha256'],
            'status': 'failed', 'error': 'Program exited with status 255.',
            'traceback': 'RuntimeError: Program exited with status 255.',
        }
        (directory / 'execution.json').write_text(json.dumps(failed))
        state_path = run_dir / 'state.json'
        state = json.loads(state_path.read_text())
        state['tasks']['f12_tz'].update(
            status='failed', execution='failed', error=failed['error'])
        state_path.write_text(json.dumps(state))

        with patch('kinbot.anl.dispatch.subprocess.run',
                   side_effect=AssertionError('must not submit or rerun QC')):
            recovered = advance(run_dir, submit=False)
        assert recovered['tasks']['f12_tz']['status'] == 'complete'
        assert recovered['tasks']['f12_tz'][
            'automatically_recovered_rank_exact'] is True
        execution = json.loads((directory / 'execution.json').read_text())
        assert execution['details']['recovered_without_execution'] is True
        assert execution['details']['returncode'] == 255
        assert execution['details']['parsed_result']['energy_hartree'] == \
            pytest.approx(-0.499946213253)
        assert json.loads(
            (directory / 'execution.failed.json').read_text()) == failed
        workflow = json.loads((run_dir / 'workflow.json').read_text())
        assert workflow['tasks'][0]['result_parser'][
            'rank_exact_electrons'] == 1


def test_failed_job_missing_from_squeue_can_be_reconciled_and_retried():
    with TemporaryDirectory() as temporary:
        root = Path(temporary)
        run_dir = prepare(_write_spec(root, dispatch_spec()), root / 'run')
        state_file = run_dir / 'state.json'
        state = json.loads(state_file.read_text())
        entry = state['tasks']['l2_geometry']
        entry.update(status='submitted', job_id='52301030')
        state_file.write_text(json.dumps(state))
        (run_dir / 'tasks' / 'l2_geometry' / 'execution.json').write_text(json.dumps({
            'schema': 1, 'task_id': 'l2_geometry',
            'geometry_sha256': entry['geometry_sha256'], 'status': 'failed',
            'error': 'MPI initialization failed',
        }))
        with patch('kinbot.anl.dispatch.subprocess.run', return_value=
                   subprocess.CompletedProcess([], 1, '',
                       'slurm_load_jobs error: Unable to contact slurm controller')):
            with pytest.raises(RuntimeError, match='squeue failed'):
                advance(run_dir)
        assert json.loads(state_file.read_text())['tasks']['l2_geometry']['status'] == 'submitted'
        invalid_id = subprocess.CompletedProcess(
            [], 1, '', 'slurm_load_jobs error: Invalid job id specified')
        with patch('kinbot.anl.dispatch.subprocess.run', return_value=invalid_id):
            assert advance(run_dir)['tasks']['l2_geometry']['status'] == 'failed'
            archive = retry_failed(run_dir, 'l2_geometry')
        assert (archive / 'execution.json').is_file()
        assert (run_dir / 'tasks' / 'l2_geometry' / 'job.slurm').is_file()
        assert json.loads(state_file.read_text())['tasks']['l2_geometry']['status'] == 'staged'


def test_scheduler_query_timeout_is_bounded():
    error = subprocess.TimeoutExpired(['squeue'], 30)
    with patch('kinbot.anl.dispatch.subprocess.run', side_effect=error) as run, \
            patch('kinbot.anl.dispatch.time.sleep') as sleep:
        with pytest.raises(SchedulerUnavailableError,
                           match='timed out 3 times'):
            _job_active('123')
    assert run.call_count == 3
    assert sleep.call_count == 2
    assert all(call.kwargs['timeout'] == 30 for call in run.call_args_list)


def test_queue_exit_reads_final_retry_result_after_scheduler_query(tmp_path, monkeypatch):
    run_dir = prepare(dispatch_spec(), tmp_path / 'run')
    state_file = run_dir / 'state.json'
    state = json.loads(state_file.read_text())
    entry = state['tasks']['l2_geometry']
    entry.update(status='submitted', job_id='123')
    state_file.write_text(json.dumps(state))
    outcome = run_dir / 'tasks/l2_geometry/execution.json'
    outcome.write_text(json.dumps({
        'schema': 1, 'task_id': 'l2_geometry',
        'geometry_sha256': entry['geometry_sha256'], 'status': 'failed',
        'error': 'Input/output error from the first in-allocation attempt',
    }))

    def finished_during_query(job_id):
        _mock_execution(run_dir, 'l2_geometry', geometry='final.xyz')
        return False

    monkeypatch.setattr('kinbot.anl.dispatch._job_active', finished_during_query)
    result = advance(run_dir)
    assert result['tasks']['l2_geometry']['status'] == 'complete'
    assert result['tasks']['l3_geometry']['status'] == 'staged'


def test_queue_exit_allows_delayed_result_publication_without_resubmission(tmp_path, monkeypatch):
    run_dir = prepare(dispatch_spec(), tmp_path / 'run')
    state_file = run_dir / 'state.json'
    state = json.loads(state_file.read_text())
    state['tasks']['l2_geometry'].update(status='submitted', job_id='123')
    state_file.write_text(json.dumps(state))
    monkeypatch.setattr('kinbot.anl.dispatch._job_active', lambda _: False)
    monkeypatch.setattr('kinbot.anl.dispatch.time.time', lambda: 100.)
    result = advance(run_dir)
    assert result['tasks']['l2_geometry']['status'] == 'submitted'
    assert result['tasks']['l2_geometry']['missing_since'] == 100.
    monkeypatch.setattr('kinbot.anl.dispatch.time.time', lambda: 120.)
    _mock_execution(run_dir, 'l2_geometry', geometry='final.xyz')
    result = advance(run_dir)
    assert result['tasks']['l2_geometry']['status'] == 'complete'
    assert 'missing_since' not in result['tasks']['l2_geometry']


def test_queue_exit_missing_result_grace_expires_and_resets_if_live(tmp_path, monkeypatch):
    run_dir = prepare(dispatch_spec(), tmp_path / 'run')
    state_file = run_dir / 'state.json'
    state = json.loads(state_file.read_text())
    state['tasks']['l2_geometry'].update(status='submitted', job_id='123')
    state_file.write_text(json.dumps(state))
    monkeypatch.setattr('kinbot.anl.dispatch._job_active', lambda _: False)
    monkeypatch.setattr('kinbot.anl.dispatch.time.time', lambda: 100.)
    advance(run_dir)
    monkeypatch.setattr('kinbot.anl.dispatch._job_active', lambda _: True)
    assert 'missing_since' not in advance(run_dir)['tasks']['l2_geometry']
    monkeypatch.setattr('kinbot.anl.dispatch._job_active', lambda _: False)
    monkeypatch.setattr('kinbot.anl.dispatch.time.time', lambda: 150.)
    assert advance(run_dir)['tasks']['l2_geometry']['status'] == 'submitted'
    monkeypatch.setattr('kinbot.anl.dispatch.time.time', lambda: 211.)
    result = advance(run_dir)['tasks']['l2_geometry']
    assert result['status'] == 'failed'
    assert result['failure_phase'] == 'scheduler'


def test_scheduler_query_launch_error_is_bounded():
    error = OSError(11, 'Resource temporarily unavailable')
    with patch('kinbot.anl.dispatch.subprocess.run', side_effect=error) as run, \
            patch('kinbot.anl.dispatch.time.sleep') as sleep:
        with pytest.raises(SchedulerUnavailableError,
                           match='could not start 3 times'):
            _job_active('123')
    assert run.call_count == 3
    assert sleep.call_count == 2


def test_in_process_driver_waits_for_scheduler_recovery():
    state = {'tasks': {'probe': {'status': 'complete'}}}
    spec = {'tasks': [{'id': 'probe'}]}
    with TemporaryDirectory() as temporary:
        run_dir = Path(temporary)
        (run_dir / 'drive.lock').touch()
        with patch('kinbot.anl.dispatch.advance', side_effect=[
                SchedulerUnavailableError('squeue unavailable'), state
        ]) as advance_mock, \
                patch('kinbot.anl.dispatch._load',
                      return_value=(run_dir, spec, state)), \
                patch('kinbot.anl.dispatch.time.sleep') as sleep:
            returncode, summary = drive_run(run_dir, interval=7.)
    assert returncode == 0
    assert summary == {'probe': 'complete'}
    assert advance_mock.call_count == 2
    sleep.assert_called_once_with(7.)


def test_automatic_preflight_waits_only_for_scheduler_recovery():
    expected = {'slurm_scripts_tested': 1}
    with patch('kinbot.anl.dispatch.preflight', side_effect=[
            SchedulerUnavailableError('controller unavailable'), expected
    ]) as check, patch('kinbot.anl.dispatch.time.sleep') as sleep:
        result = preflight_until_scheduler_ready(
            '/graph', skip_optional=True, interval=7.)
    assert result == expected
    assert check.call_count == 2
    sleep.assert_called_once_with(7.)


def test_preflight_classifies_slurm_test_timeout_as_unavailable():
    with TemporaryDirectory() as temporary:
        root = Path(temporary)
        run_dir = prepare(_write_spec(root, dispatch_spec()), root / 'run')

        def execute(command, **kwargs):
            if command[0] == 'bash':
                return subprocess.CompletedProcess(command, 0, '', '')
            if command[:2] == ['sbatch', '--test-only']:
                raise subprocess.TimeoutExpired(command, 30)
            raise AssertionError(command)

        with patch('kinbot.anl.dispatch.shutil.which', return_value='/bin/x'), \
                patch('kinbot.anl.dispatch.subprocess.run',
                      side_effect=execute):
            with pytest.raises(SchedulerUnavailableError,
                               match='test-only submission timed out'):
                preflight(run_dir)


def test_preflight_classifies_transient_slurm_launch_as_unavailable():
    with TemporaryDirectory() as temporary:
        root = Path(temporary)
        run_dir = prepare(_write_spec(root, dispatch_spec()), root / 'run')

        def execute(command, **kwargs):
            if command[0] == 'bash':
                return subprocess.CompletedProcess(command, 0, '', '')
            if command[:2] == ['sbatch', '--test-only']:
                raise OSError(11, 'Resource temporarily unavailable')
            raise AssertionError(command)

        with patch('kinbot.anl.dispatch.shutil.which', return_value='/bin/x'), \
                patch('kinbot.anl.dispatch.subprocess.run',
                      side_effect=execute):
            with pytest.raises(SchedulerUnavailableError,
                               match='could not start'):
                preflight(run_dir)


def test_submission_controller_failure_restages_without_uncertain_state():
    with TemporaryDirectory() as temporary:
        root = Path(temporary)
        run_dir = prepare(_write_spec(root, dispatch_spec()), root / 'run')
        unavailable = subprocess.CompletedProcess(
            [], 1, '', 'sbatch: error: Unable to contact slurm controller')
        with patch('kinbot.anl.dispatch.subprocess.run',
                   return_value=unavailable):
            with pytest.raises(SchedulerUnavailableError,
                               match='sbatch is unavailable'):
                advance(run_dir, submit=True, submit_only=['l2_geometry'])
        state = json.loads((run_dir / 'state.json').read_text())
        assert state['tasks']['l2_geometry']['status'] == 'staged'


def test_status_refreshes_finished_job_without_submitting(capsys):
    with TemporaryDirectory() as temporary:
        root = Path(temporary)
        run_dir = prepare(_write_spec(root, dispatch_spec()), root / 'run')
        state_file = run_dir / 'state.json'
        state = json.loads(state_file.read_text())
        state['tasks']['l2_geometry'].update(status='submitted', job_id='1234')
        state_file.write_text(json.dumps(state))
        _mock_execution(run_dir, 'l2_geometry', geometry='final.xyz')
        with patch('kinbot.anl.dispatch._job_active', return_value=False), \
                patch('kinbot.anl.dispatch.subprocess.run',
                      side_effect=AssertionError('status must not submit')):
            main(['status', str(run_dir)])
        summary = json.loads(capsys.readouterr().out)
        assert summary['l2_geometry'] == 'complete'
        assert summary['l3_geometry'] == 'staged'
        assert json.loads(state_file.read_text())['tasks']['l2_geometry']['status'] == 'complete'


def test_preflight_reports_missing_program_before_submission():
    with TemporaryDirectory() as temporary:
        root = Path(temporary)
        spec = dispatch_spec()
        spec['tasks'][0]['profile']['command'] = str(root / 'missing_g16')
        run_dir = prepare(_write_spec(root, spec), root / 'run')
        with patch('kinbot.anl.dispatch.shutil.which', return_value='/bin/true'):
            with pytest.raises(RuntimeError, match='Missing executable'):
                preflight(run_dir)


def test_preflight_reports_silent_site_setup_exit_status():
    with TemporaryDirectory() as temporary:
        root = Path(temporary)
        run_dir = prepare(_write_spec(root, dispatch_spec()), root / 'run')
        (run_dir / 'site_setup.sh').write_text('exit 7\n')
        with patch('kinbot.anl.dispatch.shutil.which', return_value='/bin/true'):
            with pytest.raises(RuntimeError, match='exit status 7 without diagnostics'):
                preflight(run_dir)


def test_preflight_sources_site_setup_and_validates_slurm_without_submitting():
    with TemporaryDirectory() as temporary:
        root = Path(temporary)
        run_dir = prepare(_write_spec(root, dispatch_spec()), root / 'run')
        bindir = root / 'bin'
        bindir.mkdir()
        for program in ('sbatch', 'squeue'):
            executable = bindir / program
            executable.write_text('#!/usr/bin/env bash\nexit 0\n')
            executable.chmod(0o755)
        backend_programs = {'gaussian': 'g16', 'molpro': 'molpro',
                            'cfour': 'xcfour'}
        for backend, program in backend_programs.items():
            backend_dir = root / backend
            backend_dir.mkdir()
            executable = backend_dir / program
            executable.write_text('#!/usr/bin/env bash\nexit 0\n')
            executable.chmod(0o755)
        genbas = root / 'GENBAS'
        genbas.write_text('basis fixture\n')
        (run_dir / 'site_setup.sh').write_text(
            'case "$KINBOT_BACKEND" in\n'
            + ''.join(f'  {backend}) export PATH={root / backend}:$PATH ;;\n'
                      for backend in backend_programs)
            + '  *) exit 7 ;;\n'
            + 'esac\n'
            + 'if [ "$KINBOT_BACKEND" = cfour ]; then '
            + f'export CFOUR_GENBAS={genbas}; fi\n'
            f'export PYTHONPATH={Path(__file__).resolve().parents[1]}:${{PYTHONPATH:-}}\n'
        )
        with patch.dict(os.environ, {'PATH': f'{bindir}:{os.environ["PATH"]}'}):
            result = preflight(run_dir)
        assert result['slurm_scripts_tested'] == 1
        assert result['exclusive_jobs_checked'] == 1
        assert result['programs'] == ['g16', 'molpro', 'xcfour']


def test_prepare_discovers_vendor_setup_and_cfour_genbas():
    with TemporaryDirectory() as temporary:
        root = Path(temporary)
        gaussian = root / 'gaussian' / 'g16'
        molpro = root / 'molpro' / 'bin'
        cfour = root / 'cfour' / 'bin'
        for directory, program in ((gaussian, 'g16'), (molpro, 'molpro'),
                                   (cfour, 'xcfour')):
            directory.mkdir(parents=True)
            executable = directory / program
            executable.write_text('#!/usr/bin/env bash\nexit 0\n')
            executable.chmod(0o755)
        (gaussian / 'bsd').mkdir()
        (gaussian / 'bsd' / 'g16.profile').write_text(
            'false  # vendor profiles may use an unsuccessful probe\n'
            'export PROFILE_SOURCED=yes\n'
            'export PROFILE_SCRATCH="$GAUSS_SCRDIR"\n'
            'export GAUSS_SCRDIR=/profile-default\n')
        (root / 'cfour' / 'basis').mkdir()
        genbas = root / 'cfour' / 'basis' / 'GENBAS'
        genbas.write_text('basis fixture\n')
        (root / 'cfour' / 'payload').mkdir()
        (cfour / 'xcfour').replace(root / 'cfour' / 'payload' / 'xcfour')
        (cfour / 'xcfour').symlink_to(root / 'cfour' / 'payload' / 'xcfour')
        spec = dispatch_spec()
        for task in spec['tasks']:
            task['resources']['partition'] = 'chosen_by_user'
        blocked_scratch = root / 'not-a-directory'
        blocked_scratch.write_text('blocks mkdir\n')
        node_scratch = root / 'node-scratch'
        site_scratch = root / 'site-scratch'
        base_path = os.environ['PATH']
        environment = {'PATH': f'{gaussian}:{molpro}:{cfour}:{base_path}',
                       'LOADEDMODULES': 'molpro/molpro24:cfour/2.1',
                       'CFOUR_GENBAS': '',
                       'GAUSS_SCRDIR': str(blocked_scratch),
                       'SLURM_TMPDIR': str(node_scratch),
                       'SCRATCH': str(site_scratch)}
        with patch.dict(os.environ, environment):
            run_dir = prepare(_write_spec(root, spec), root / 'run')
            setup = (run_dir / 'site_setup.sh').read_text()
            assert 'module load molpro/molpro24' in setup
            assert 'module load cfour/2.1' in setup
            assert 'export I_MPI_FABRICS=shm' in setup
            for backend in ('gaussian', 'molpro', 'cfour'):
                program = {'gaussian': 'g16', 'molpro': 'molpro',
                           'cfour': 'xcfour'}[backend]
                command = (
                    'set -euo pipefail\n'
                    'module() { test "$1" = load; export LOADED_MODULE="$2"; }\n'
                    f'export KINBOT_BACKEND={backend}\n'
                    'source site_setup.sh\n'
                    f'command -v {program}\n'
                    'printf "|%s|%s|%s|%s|%s|%s" "${PROFILE_SOURCED:-}" '
                    '"${g16root:-}" "${CFOUR_GENBAS:-}" "${LOADED_MODULE:-}" '
                    '"${GAUSS_SCRDIR:-}" "${PROFILE_SCRATCH:-}"\n'
                )
                child_env = os.environ.copy()
                child_env['PATH'] = base_path
                result = subprocess.run(['bash', '-c', command], cwd=run_dir,
                                        env=child_env, capture_output=True,
                                        text=True, check=True)
                if backend == 'gaussian':
                    assert result.stdout.startswith(f'{gaussian / "g16"}\n')
                    assert f'|yes|{root / "gaussian"}|' in result.stdout
                    assert result.stdout.endswith(f'|{node_scratch}|{node_scratch}')
                    gaussian_command = command
                elif backend == 'cfour':
                    assert result.stdout.startswith(f'{cfour / "xcfour"}\n')
                    assert f'|{genbas}|cfour/2.1' in result.stdout
                    cfour_command = command
                else:
                    assert result.stdout.startswith(f'{molpro / "molpro"}\n')
                    assert '|molpro/molpro24|' in result.stdout
            override = root / 'different-GENBAS'
            override.write_text('override fixture\n')
            child_env['CFOUR_GENBAS'] = str(override)
            result = subprocess.run(['bash', '-c', cfour_command],
                                    cwd=run_dir, env=child_env, capture_output=True,
                                    text=True, check=True)
            assert f'|{override}|cfour/2.1' in result.stdout
            child_env['SLURM_TMPDIR'] = str(blocked_scratch)
            result = subprocess.run(['bash', '-c', gaussian_command],
                                    cwd=run_dir, env=child_env, capture_output=True,
                                    text=True, check=True)
            assert result.stdout.endswith(f'|{site_scratch}|{site_scratch}')
            explicit_scratch = root / 'explicit-scratch'
            child_env['GAUSS_SCRDIR'] = str(explicit_scratch)
            result = subprocess.run(['bash', '-c', gaussian_command],
                                    cwd=run_dir, env=child_env, capture_output=True,
                                    text=True, check=True)
            assert result.stdout.endswith(f'|{explicit_scratch}|{explicit_scratch}')
            (gaussian / 'bsd' / 'g16.profile').write_text('false\n')
            result = subprocess.run(['bash', '-c', gaussian_command],
                                    cwd=run_dir, env=child_env, capture_output=True,
                                    text=True, check=False)
            assert result.returncode == 1
            assert 'Gaussian profile failed with exit status 1' in result.stderr


def test_mrcc_discovery_uses_configuration_without_site_paths():
    with TemporaryDirectory() as temporary:
        root = Path(temporary) / 'installed-anywhere'
        root.mkdir()
        for program in ('dmrcc', 'scf', 'mrcc'):
            executable = root / program
            executable.write_text('#!/usr/bin/env bash\nexit 0\n')
            executable.chmod(0o755)
        environment = {
            'PATH': '/usr/bin:/bin', 'LOADEDMODULES': '',
            'KINBOT_MRCC_COMMAND': str(root / 'dmrcc'),
        }
        with patch.dict(os.environ, environment, clear=True):
            setup = render_site_setup(
                {'mrcc': {'dmrcc', 'scf', 'mrcc'}})
        assert str(root) in setup
        assert '/opt/mrcc' not in setup
        # Write only after rendering so this shell check exercises the exact
        # generated setup without inheriting the configured login environment.
        Path(temporary, 'setup.sh').write_text(setup)
        result = subprocess.run(
            ['bash', '-c', 'export KINBOT_BACKEND=mrcc; source setup.sh; '
                           'command -v dmrcc; command -v scf; command -v mrcc'],
            cwd=temporary, env={'PATH': '/usr/bin:/bin'},
            capture_output=True, text=True, check=True)
        assert result.stdout.splitlines() == [str(root / name)
                                              for name in ('dmrcc', 'scf', 'mrcc')]


def test_mrcc_discovery_searches_conventional_versioned_installations():
    with TemporaryDirectory() as temporary:
        prefix = Path(temporary) / 'opt'
        install = prefix / 'MRCC' / 'mrcc-2026' / 'bin'
        install.mkdir(parents=True)
        for program in ('dmrcc', 'scf', 'mrcc'):
            executable = install / program
            executable.write_text('#!/usr/bin/env bash\nexit 0\n')
            executable.chmod(0o755)
        environment = {'PATH': '/usr/bin:/bin', 'LOADEDMODULES': '',
                       'HOME': str(Path(temporary) / 'home')}
        with patch.dict(os.environ, environment, clear=True), \
                patch('kinbot.anl.site._automatic_install_bases',
                      return_value=[prefix]):
            setup = render_site_setup({'mrcc': {'dmrcc', 'scf', 'mrcc'}})
        assert str(install) in setup
        assert 'module load' not in setup


def test_unloaded_environment_module_is_discovered_and_recorded():
    with TemporaryDirectory() as temporary:
        root = Path(temporary)
        install = root / 'mrcc-2026' / 'bin'
        install.mkdir(parents=True)
        for program in ('dmrcc', 'scf', 'mrcc'):
            executable = install / program
            executable.write_text('#!/usr/bin/env bash\nexit 0\n')
            executable.chmod(0o755)
        modules_home = root / 'modules'
        (modules_home / 'init').mkdir(parents=True)
        (modules_home / 'init' / 'bash').write_text(
            'module() {\n'
            '  if [ "$1" = -t ] && [ "$2" = avail ]; then\n'
            '    echo mrcc/mrcc-2026\n'
            '  elif [ "$1" = load ] && [ "$2" = mrcc/mrcc-2026 ]; then\n'
            f'    export PATH={install}:$PATH\n'
            '  else\n'
            '    return 1\n'
            '  fi\n'
            '}\n')
        environment = {
            'PATH': '/usr/bin:/bin', 'LOADEDMODULES': '',
            'MODULESHOME': str(modules_home), 'HOME': str(root / 'home'),
        }
        with patch.dict(os.environ, environment, clear=True), \
                patch('kinbot.anl.site._automatic_install_bases',
                      return_value=[]):
            setup = render_site_setup({'mrcc': {'dmrcc', 'scf', 'mrcc'}})
        assert 'module load mrcc/mrcc-2026' in setup
        setup_path = root / 'setup.sh'
        setup_path.write_text(setup)
        result = subprocess.run(
            ['bash', '-c', 'export KINBOT_BACKEND=mrcc; source setup.sh; '
                           'command -v dmrcc; command -v scf; command -v mrcc'],
            cwd=root, env=environment, capture_output=True, text=True,
            check=True)
        assert result.stdout.splitlines() == [str(install / name)
                                              for name in ('dmrcc', 'scf', 'mrcc')]


def test_generated_site_setup_is_valid_for_every_scientific_backend():
    with TemporaryDirectory() as temporary:
        root = Path(temporary) / 'software installs'
        programs = {
            'cfour': {'xcfour'},
            'gaussian': {'g16'},
            'molpro': {'molpro'},
            'mrcc': {'dmrcc', 'scf', 'mrcc'},
            'nwchem': {'nwchem'},
            'orca': {'orca'},
            'qchem': {'qchem'},
        }
        environment = {'PATH': '/usr/bin:/bin', 'LOADEDMODULES': '',
                       'HOME': str(Path(temporary) / 'home')}
        expected = {}
        for backend, names in programs.items():
            directory = root / backend / 'bin'
            directory.mkdir(parents=True)
            for name in names:
                executable = directory / name
                executable.write_text('#!/usr/bin/env bash\nexit 0\n')
                executable.chmod(0o755)
                environment[
                    f'KINBOT_{name.upper()}_EXECUTABLE'] = shlex.quote(
                        str(executable))
                expected[(backend, name)] = executable
        with patch.dict(os.environ, environment, clear=True), \
                patch('kinbot.anl.site._automatic_install_bases',
                      return_value=[]), \
                patch('kinbot.anl.site._module_system_available',
                      return_value=False):
            setup = render_site_setup(programs)
        setup_path = Path(temporary) / 'site setup.sh'
        setup_path.write_text(setup)
        subprocess.run(['bash', '-n', setup_path], check=True)
        for backend, names in programs.items():
            result = subprocess.run(
                ['bash', '-c',
                 f'export KINBOT_BACKEND={backend}; '
                 f'source {shlex.quote(str(setup_path))}; '
                 'for name in "$@"; do command -v -- "$name"; done',
                 'kinbot-site-test', *sorted(names)],
                env=environment, capture_output=True, text=True, check=True)
            assert result.stdout.splitlines() == [
                str(expected[(backend, name)]) for name in sorted(names)]


def test_preflight_refreshes_a_stale_generated_mrcc_site_setup():
    with TemporaryDirectory() as temporary:
        root = Path(temporary)
        install = root / 'mrcc-installed-later'
        install.mkdir()
        for program in ('dmrcc', 'scf', 'mrcc'):
            executable = install / program
            executable.write_text('#!/usr/bin/env bash\nexit 0\n')
            executable.chmod(0o755)
        task = mrcc_task(
            'ccsdtq_dz', 'CCSDT(Q)', 'cc-pVDZ', multiplicity=1,
            geometry_from='initial')
        task['resources'].update(
            cores=1, memory_mb=4096, partition='test')
        spec = {
            'schema': 1, 'name': 'late-mrcc-site',
            'molecule': {
                'symbols': ['H', 'H'],
                'positions': [[0., 0., 0.], [0., 0., 0.74]],
                'charge': 0, 'multiplicity': 1,
            },
            'limits': {'max_nodes': 1}, 'tasks': [task],
        }
        with patch.dict(os.environ, {
                'PATH': '/usr/bin:/bin', 'LOADEDMODULES': ''}, clear=True):
            run_dir = prepare(spec, root / 'run')
        assert str(install) not in (run_dir / 'site_setup.sh').read_text()

        bindir = root / 'scheduler'
        bindir.mkdir()
        for program in ('sbatch', 'squeue'):
            executable = bindir / program
            executable.write_text('#!/usr/bin/env bash\nexit 0\n')
            executable.chmod(0o755)
        environment = {
            'PATH': f'{bindir}:/usr/bin:/bin', 'LOADEDMODULES': '',
            'KINBOT_MRCC_ROOT': str(install),
        }
        with patch.dict(os.environ, environment, clear=True):
            result = preflight(run_dir)
        assert result['site_setup_refreshed'] is True
        assert result['slurm_scripts_tested'] == 1
        setup = (run_dir / 'site_setup.sh').read_text()
        assert str(install) in setup
        assert setup.count('KinBot preflight site refresh') == 1


def test_prepare_selects_fitting_slurm_partition_and_keeps_explicit_choice():
    display = ('short-cpu*|96|126000|30:00|up\n'
               'day-long-cpu|96|126000|1-00:00:00|up\n'
               'week-long-cpu|96|126000|7-00:00:00|up\n'
               'drained|96|126000|31-00:00:00|down\n')
    spec = dispatch_spec()
    spec['tasks'][0]['resources']['partition'] = 'week-long-cpu'
    actual_which = shutil.which

    def which(program):
        return '/usr/bin/sinfo' if program == 'sinfo' else actual_which(program)

    with TemporaryDirectory() as temporary:
        root = Path(temporary)
        with patch('kinbot.anl.site.shutil.which', side_effect=which), \
                patch('kinbot.anl.site.subprocess.run', return_value=
                      subprocess.CompletedProcess([], 0, display, '')):
            run_dir = prepare(_write_spec(root, spec), root / 'run')
        prepared = json.loads((run_dir / 'workflow.json').read_text())
        partitions = {task['id']: task['resources']['partition']
                      for task in prepared['tasks']}
        assert partitions['l2_geometry'] == 'week-long-cpu'
        assert set(partitions.values()) == {'week-long-cpu', 'day-long-cpu'}
        script = (run_dir / 'tasks' / 'l2_geometry' / 'job.slurm').read_text()
        assert '#SBATCH --partition=week-long-cpu\n' in script
        with patch('kinbot.anl.site.shutil.which', side_effect=which), \
                patch('kinbot.anl.site.subprocess.run', return_value=
                      subprocess.CompletedProcess([], 0, display.splitlines()[0] + '\n', '')):
            with pytest.raises(RuntimeError, match='no available Slurm partition'):
                prepare(_write_spec(root, spec), root / 'impossible')
        assert not (root / 'impossible').exists()


def test_automatic_graph_caps_jobs_to_an_explicit_short_partition():
    display = 'short-cpu*|96|126000|30:00|up\n'
    spec = dispatch_spec(auto_resources=True)
    spec['intent'] = {'cap_walltime_to_explicit_partition': True}
    for task in spec['tasks']:
        task['resources']['partition'] = 'short-cpu'
    actual_which = shutil.which

    def which(program):
        return '/usr/bin/sinfo' if program == 'sinfo' else actual_which(program)

    with TemporaryDirectory() as temporary:
        root = Path(temporary)
        with patch('kinbot.anl.site.shutil.which', side_effect=which), \
                patch('kinbot.anl.site.subprocess.run', return_value=
                      subprocess.CompletedProcess([], 0, display, '')):
            run_dir = prepare(_write_spec(root, spec), root / 'run')
        prepared = json.loads((run_dir / 'workflow.json').read_text())
        for task in prepared['tasks']:
            resources = task['resources']
            assert resources['partition'] == 'short-cpu'
            assert resources['walltime'] == '00:30:00'
            assert resources['requested_walltime'] != resources['walltime']
            assert resources['walltime_capped_to_partition'] == 'short-cpu'
            script = run_dir / 'tasks' / task['id'] / 'job.slurm'
            if script.is_file():
                assert '#SBATCH --time=00:30:00\n' in script.read_text()
