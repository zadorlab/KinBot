"""Final CBH/ANL, ROTD_py, MESSPF, and MESS orchestration checks."""

import json
from dataclasses import asdict
from types import SimpleNamespace

import pytest

import kinbot.anl.end_to_end as end_to_end
from kinbot.anl.atct import ATcTRecord
from kinbot.anl.cbh import FormationEnthalpy
from kinbot.anl.end_to_end import (_audit_handoff, _literature_checks,
                                   _mess_rotd_statistical_factors,
                                   _write_cbh_thermochemistry_models,
                                   _write_mess_input, component_breakdown, run)


def test_rendered_mess_rotd_statistical_factors_are_read_separately(tmp_path):
    source = tmp_path / 'mess_0000.inp'
    source.write_text('''Bimolecular b_1
  Fragment f1
    RRHO
      Core RigidRotor
        SymmetryFactor 6.0
      End ! Core
      ElectronicLevels[1/cm] 1
        0.0 2
    End
  Fragment f2
    RRHO
      Core RigidRotor
        SymmetryFactor 6.0
      End ! Core
      ElectronicLevels[1/cm] 1
        0.0 2
    End
  GroundEnergy[kcal/mol] 0.0
End
Barrier vrc b_1 w_1
  Variational
    RRHO
      Core Rotd
        File rotd_channel_Ne_0.out
        SymmetryFactor 72.0
      End ! Core
      ElectronicLevels[1/cm] 1
        0.0 1
    End ! RRHO
  End
End
''')

    with source.open('a') as stream:
        stream.write('Bimolecular another_channel\n  Fragment x\n    RRHO\n'
                     '  Fragment y\n    RRHO\n  GroundEnergy[kcal/mol] 0.0\nEnd\n')
    factors = _mess_rotd_statistical_factors(
        source, 'rotd_channel_Ne_0.out')

    assert factors['fragment_rotational_symmetries'] == [6., 6.]
    assert factors['fragment_multiplicities'] == [2, 2]
    assert factors['reactive_surface_multiplicity'] == 1
    assert factors['mess_symmetry_factor'] == 72.


def _composite(path, offset):
    values = {
        'reference_cbs': -40.0 + offset,
        'hoe_high': -39.8 + offset,
        'hoe_low': -39.7 + offset,
        'core_valence_cbs': -0.02 + offset,
        'scalar_relativistic': -0.005 + offset,
        'dboc': 0.002 + offset,
        'spin_orbit': offset,
        'harmonic_zpe': 0.1 + offset,
        'vpt2_correction': -0.01 + offset,
    }
    path.write_text(json.dumps({
        'schema': 1, 'status': 'complete',
        'components': {
            key: {'value_hartree': value} for key, value in values.items()},
    }))
    return values


def test_component_breakdown_uses_each_anl_term_once(tmp_path):
    left_path, right_path = tmp_path / 'left.json', tmp_path / 'right.json'
    left = _composite(left_path, 0.)
    right = _composite(right_path, .001)
    reaction = SimpleNamespace(stoichiometry={'left': -1, 'right': 1})
    result = component_breakdown(
        reaction, {'left': left_path, 'right': right_path})
    assert result['reference_cbs']['hartree'] == pytest.approx(.001)
    # The identical offset cancels inside each species' high-low correction.
    assert result['higher_order']['hartree'] == pytest.approx(0.)
    expected = ((right['reference_cbs'] - left['reference_cbs'])
                + ((right['hoe_high'] - right['hoe_low'])
                   - (left['hoe_high'] - left['hoe_low']))
                + sum(right[key] - left[key] for key in (
                    'core_valence_cbs', 'scalar_relativistic', 'dboc',
                    'spin_orbit', 'harmonic_zpe', 'vpt2_correction')))
    assert result['total_zero_k_reaction']['hartree'] == pytest.approx(expected)


def test_component_breakdown_reads_direct_rank_exact_zero(tmp_path):
    left_path, right_path = tmp_path / 'left.json', tmp_path / 'right.json'
    left = _composite(left_path, 0.)
    right = _composite(right_path, .001)
    for path in (left_path, right_path):
        record = json.loads(path.read_text())
        record['components'].pop('hoe_high')
        record['components'].pop('hoe_low')
        record['components']['higher_order_correction'] = {
            'value_hartree': 0.}
        path.write_text(json.dumps(record))
    reaction = SimpleNamespace(stoichiometry={'left': -1, 'right': 1})
    result = component_breakdown(
        reaction, {'left': left_path, 'right': right_path})
    assert result['higher_order']['hartree'] == 0.
    expected = ((right['reference_cbs'] - left['reference_cbs'])
                + sum(right[key] - left[key] for key in (
                    'core_valence_cbs', 'scalar_relativistic', 'dboc',
                    'spin_orbit', 'harmonic_zpe', 'vpt2_correction')))
    assert result['total_zero_k_reaction']['hartree'] == pytest.approx(expected)


def test_component_breakdown_accepts_different_declared_component_inventories(
        tmp_path):
    left_path, right_path = tmp_path / 'left.json', tmp_path / 'right.json'
    left_path.write_text(json.dumps({
        'components': {
            'reference_cbs': {'value_hartree': -10.},
            'harmonic_zpe': {'value_hartree': .1},
        },
        'electronic_terms': [
            {'component': 'reference_cbs', 'coefficient': 1}],
        'zero_point_terms': [
            {'component': 'harmonic_zpe', 'coefficient': 1}],
    }))
    right_path.write_text(json.dumps({
        'components': {
            'reference_cbs': {'value_hartree': -9.8},
            'dboc': {'value_hartree': .002},
            'harmonic_zpe': {'value_hartree': .08},
        },
        'electronic_terms': [
            {'component': 'reference_cbs', 'coefficient': 1},
            {'component': 'dboc', 'coefficient': 1}],
        'zero_point_terms': [
            {'component': 'harmonic_zpe', 'coefficient': 1}],
    }))
    reaction = SimpleNamespace(stoichiometry={'left': -1, 'right': 1})
    result = component_breakdown(
        reaction, {'left': left_path, 'right': right_path})
    assert result['reference_cbs']['hartree'] == pytest.approx(.2)
    assert result['dboc']['hartree'] == pytest.approx(.002)
    assert result['harmonic_zpe']['hartree'] == pytest.approx(-.02)
    assert result['core_valence_cbs']['hartree'] == 0.
    assert result['total_zero_k_reaction']['hartree'] == pytest.approx(.182)


def test_mess_continuation_disables_new_vrc_work_and_requires_production(
        tmp_path):
    run = tmp_path / 'run'
    run.mkdir()
    source = run / 'production.json'
    source.write_text(json.dumps({
        'title': 'fixture', 'me': 0, 'run_me': 0,
        'vrc_tst_scan': {'parent': ['reaction']}, 'rotdpy_run': 1,
    }))
    rotdpy = run / 'rotdPy' / 'reaction.py'
    rotdpy.parent.mkdir()
    rotdpy.write_text('# fixture\n')
    handoff = tmp_path / 'handoff.json'
    handoff.write_text('{}\n')
    manifest = {
        'run_dir': str(run), 'kinbot_input': str(source),
        'mess': {'mess_command': 'mess --flag',
                 'messpf_command': 'messpf', 'collider': 'He',
                 'epsilon': 252.3, 'epsilon_unit': 'K', 'sigma': 4.302,
                 'queue_job_limit': 8},
    }
    actual_run, output = _write_mess_input(
        tmp_path, manifest, handoff.resolve(), rotdpy.resolve())
    generated = json.loads(output.read_text())
    assert actual_run == run.resolve()
    assert generated['me'] == generated['run_me'] == 1
    assert generated['run_messpf'] == 1
    assert generated['anl_handoff_manifest'] == str(handoff.resolve())
    assert generated['rotdpy_directory'] == str(rotdpy.parent.resolve())
    assert generated['rotdpy_mess_mode'] == 'production'
    assert generated['rotdpy_run'] == 0
    assert generated['vrc_tst_scan'] == 0
    assert generated['vrc_tst_noscan'] == 0
    assert generated['reaction_search'] == 1
    assert generated['profiled_l1_reuse_only'] == 1
    assert generated['profiled_route_file'] == (
        '.kinbot_theory_jobs.full_verification.json')
    assert generated['high_level'] == 1
    assert generated['allow_l2_without_conf'] == 1
    assert generated['rotor_scan'] == 1
    assert generated['collider'] == 'He'
    assert generated['epsilon'] == 252.3
    assert generated['epsilon_unit'] == 'K'
    assert generated['sigma'] == 4.302
    assert generated['queue_job_limit'] == 8


def test_external_cbh_reference_models_come_from_completed_composites(
        tmp_path, monkeypatch):
    methane = ATcTRecord(
        'methane*0', 'methane', 'CH4 (g)', 'g', 'C', -66., -75., .01,
        False, '1.220', 'a' * 64)
    hydrogen = ATcTRecord(
        'hydrogen*0', 'hydrogen', 'H2 (g)', 'g', '[H][H]', 0., 0., .0,
        True, '1.220', 'a' * 64)
    formation = FormationEnthalpy(
        'CC', 0, 'ANL0-F12', -60., -72.,
        {'C': methane, '[H][H]': hydrogen}, '1.220', 'a' * 64,
        {'CC': 'ethane', 'C': 'methane', '[H][H]': 'hydrogen'},
        {'CC': -1, 'C': 2, '[H][H]': -1},
        {'CC': {'C': 2, 'H': 6}, 'C': {'C': 1, 'H': 4},
         '[H][H]': {'H': 2}})
    solved = {'ethane': {'formation': asdict(formation)}}
    composite_files = {}
    for name in ('ethane', 'methane', 'hydrogen'):
        path = tmp_path / f'{name}.json'
        path.write_text('{}\n')
        composite_files[name] = path
    composites = {
        'ethane': {'smiles': 'CC', 'path': composite_files['ethane']},
        'methane': {
            'smiles': 'C', 'path': composite_files['methane'], 'charge': 0,
            'multiplicity': 1, 'l2_geometry': {
                'symbols': ['C', 'H', 'H', 'H', 'H'],
                'positions': [[0., 0., 0.]] * 5, 'source': 'methane.xyz'}},
        'hydrogen': {
            'smiles': '[H][H]', 'path': composite_files['hydrogen'],
            'charge': 0, 'multiplicity': 1, 'l2_geometry': {
                'symbols': ['H', 'H'], 'positions': [[0., 0., 0.],
                                                    [0., 0., .74]],
                'source': 'hydrogen.xyz'}},
    }
    specification = {
        name: {'assembly': {'interface_run': str(tmp_path / name)}}
        for name in composites}
    handoff = {'species': {'ethane': {'composite': 'ethane'}}}

    class Point:
        def __init__(self, **values):
            self.__dict__.update(values)
            self.dihed = []
            self.sigma_ext = 1.

        def characterize(self):
            return None

    monkeypatch.setattr(end_to_end, 'StationaryPoint', Point)
    monkeypatch.setattr(end_to_end, 'calculate_symmetry', lambda point: None)
    monkeypatch.setattr(end_to_end, '_verified_task_result',
                        lambda *args: (None, None,
                            {'result_parser': {'file': 'vpt2.log'}},
                            {'artifacts': {'vpt2.log': 'b' * 64}},
                            tmp_path / 'vpt2.log',
                            {'harmonic_fundamentals_cm_inverse': [1000.]}))

    def attach(point, *args, **kwargs):
        point.anl_thermochemistry_frequency_source = {'kind': 'vpt2'}
        return [950.]

    monkeypatch.setattr(end_to_end, 'attach_task_vpt2_frequencies', attach)
    output = _write_cbh_thermochemistry_models(
        tmp_path, specification, composites, solved, handoff)
    models = json.loads(output.read_text())['species']
    assert set(models) == {'C', '[H][H]'}
    assert models['C']['frequencies_cm_inverse'] == [950.]
    assert models['[H][H]']['source']['composite_sha256'] == \
        end_to_end._sha256(composite_files['hydrogen'])


def test_failed_continuation_reports_current_kinbot_log_tail(
        tmp_path, monkeypatch):
    run_dir = tmp_path / 'run'
    run_dir.mkdir()
    (run_dir / 'kinbot.log').write_text('setup\nuseful native failure\n')
    monkeypatch.setattr(end_to_end, 'prepare', lambda source: {
        'kinbot_input': str(run_dir / 'input.json'),
        'run_dir': str(run_dir),
    })
    monkeypatch.setattr(end_to_end, '_read_json', lambda *args: {
        'mess_command': 'mess', 'messpf_command': 'messpf'})
    monkeypatch.setattr(end_to_end, '_command_available', lambda *args: None)
    monkeypatch.setattr(end_to_end.subprocess, 'run', lambda *args, **kwargs:
                        SimpleNamespace(returncode=1))
    with pytest.raises(RuntimeError, match='useful native failure'):
        run(tmp_path / 'manifest.json')


def test_applied_handoff_audit_verifies_every_source_hash(tmp_path):
    run = tmp_path / 'run'
    (run / 'me').mkdir(parents=True)
    composite = tmp_path / 'composite.json'
    formation = tmp_path / 'formation.json'
    composite.write_text('{"composite": true}\n')
    formation.write_text('{"formation": true}\n')
    manifest = tmp_path / 'handoff.json'
    manifest.write_text(json.dumps({
        'schema': 1, 'mode': 'cbh-anl', 'strict': True,
        'species': {'species-A': {}}, 'transition_states': {},
    }))
    from kinbot.anl.end_to_end import _sha256
    (run / 'me' / 'anl_handoff.json').write_text(json.dumps({
        'schema': 1, 'status': 'complete', 'strict': True,
        'manifest_sha256': _sha256(manifest),
        'species': {'species-A': {
            'method': 'profiled:ANL0-F12', 'zero_k_hartree': -1.,
            'formation_0k_kj_mol': 2.,
            'composite': str(composite),
            'composite_sha256': _sha256(composite),
            'formation': str(formation),
            'formation_sha256': _sha256(formation),
        }}, 'transition_states': {},
    }))
    data = {'handoff': {'output': str(manifest)}}
    result = _audit_handoff(tmp_path, data, run)
    assert result['status'] == 'passed'
    formation.write_text('changed\n')
    with pytest.raises(ValueError, match='formation file failed hash'):
        _audit_handoff(tmp_path, data, run)


def test_literature_gate_requires_every_declared_component(
        tmp_path, monkeypatch):
    monkeypatch.setattr(
        'kinbot.anl.end_to_end.compare_run',
        lambda benchmark, source: {
            'status': 'passed', 'checks': {'ccsdt_dz': {'passed': True}}})
    with pytest.raises(ValueError, match='lacks required comparisons'):
        _literature_checks(tmp_path, [{
            'kind': 'run', 'benchmark': 'fixture', 'source': str(tmp_path),
            'required_checks': ['ccsdt_dz', 'ccsdtq_dz'],
        }])
