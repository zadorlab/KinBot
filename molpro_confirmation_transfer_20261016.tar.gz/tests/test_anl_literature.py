"""Published numbers remain comparison targets rather than recipe inputs."""

import json
from pathlib import Path

import pytest

from kinbot.anl import literature
from kinbot.anl.dispatch import validate_spec
from kinbot.anl.literature import BENCHMARKS, compare_values


def test_ethane_tz_component_and_difference_regression_pass():
    benchmark = BENCHMARKS['ethane-tz-2017']
    observed = {
        task_id: target['expected']
        for task_id, target in benchmark['tasks'].items()
    }
    result = compare_values('ethane-tz-2017', observed)
    assert result['status'] == 'passed'
    assert result['checks']['delta_q_dz']['passed'] is True
    assert result['checks']['delta_q_dz']['derived_from'] == [
        'ccsdtq_dz', 'ccsdt_dz']
    assert 'inserted' in result['note']


def test_methane_targeted_mrcc_regression_detects_wrong_energy():
    benchmark = BENCHMARKS['methane-qz-2017']
    observed = {
        'ccsdtq_dz': benchmark['tasks']['ccsdtq_dz']['expected'],
        'ccsdtqp_dz': benchmark['tasks']['ccsdtqp_dz']['expected'] + 1e-4,
    }
    result = compare_values('methane-qz-2017', observed)
    assert result['status'] == 'failed'
    assert result['checks']['ccsdtq_dz']['passed'] is True
    assert result['checks']['ccsdtqp_dz']['passed'] is False
    assert result['checks']['delta_p_dz']['passed'] is False


def test_literature_comparison_requires_a_shared_completed_component():
    with pytest.raises(ValueError, match='no completed components'):
        compare_values('methyl-qz-2017', {'unrelated': -1.0})


def test_published_small_species_geometries_are_state_specific():
    methane = BENCHMARKS['methane-qz-2017']['molecule']
    methyl = BENCHMARKS['methyl-qz-2017']['molecule']
    assert (len(methane['symbols']), methane['multiplicity']) == (5, 1)
    assert (len(methyl['symbols']), methyl['multiplicity']) == (4, 2)
    assert methane['positions'][1][0] == pytest.approx(0.8882878215)
    assert methyl['positions'][1][0] == pytest.approx(1.0777376714)


def test_prepare_cli_builds_only_the_default_small_species_pair_plus_low(
        monkeypatch, tmp_path):
    captured = {}

    def fake_prepare(spec, run_dir):
        captured['spec'] = spec
        return Path(run_dir)

    monkeypatch.setattr('kinbot.anl.dispatch.prepare', fake_prepare)
    run_dir = tmp_path / 'methane'
    assert literature.main([
        'prepare-higher-order', 'methane-qz-2017', str(run_dir)]) == 0
    spec = captured['spec']
    assert [task['id'] for task in spec['tasks']] == [
        'ccsdt_dz', 'ccsdtq_dz', 'ccsdtqp_dz']
    assert spec['molecule']['multiplicity'] == 1
    qp = next(task for task in spec['tasks'] if task['id'] == 'ccsdtqp_dz')
    assert qp['resources']['walltime'] == '24:00:00'
    assert qp['resources']['max_cores'] == 4
    assert spec['intent']['literature_benchmark']['name'] == \
        'methane-qz-2017'
    json.dumps(spec)


def test_prepare_methyl_benchmark_uses_current_rohf_ucc_profile(
        monkeypatch, tmp_path):
    captured = {}

    def fake_prepare(spec, run_dir):
        captured['spec'] = spec
        return Path(run_dir)

    monkeypatch.setattr('kinbot.anl.dispatch.prepare', fake_prepare)
    assert literature.main([
        'prepare-higher-order', 'methyl-qz-2017', str(tmp_path / 'methyl'),
        '--task', 'ccsdt_dz', '--task', 'ccsdtq_dz']) == 0
    tasks = {task['id']: task for task in captured['spec']['tasks']}
    assert tasks['ccsdt_dz']['result_parser']['reference'] == 'ROHF'
    assert tasks['ccsdtq_dz']['result_parser']['reference'] == 'ROHF'
    assert 'scftype=ROHF' in tasks['ccsdtq_dz']['input_template']
    assert 'rohftype=semicanonical' in \
        tasks['ccsdtq_dz']['input_template']
    for task in captured['spec']['tasks']:
        task['resources'].update(
            cores=4, memory_mb=64000, partition='test')
    validate_spec(captured['spec'])


def test_prepare_one_off_methyl_uhf_source_reproduction(
        monkeypatch, tmp_path):
    captured = {}

    def fake_prepare(spec, run_dir):
        for task in spec['tasks']:
            task['resources'].update(
                cores=4, memory_mb=64000, partition='test')
        validate_spec(spec)
        captured['spec'] = spec
        return Path(run_dir)

    monkeypatch.setattr('kinbot.anl.dispatch.prepare', fake_prepare)
    run_dir = tmp_path / 'methyl-uhf'
    assert literature.main([
        'prepare-methyl-uhf', str(run_dir),
        '--partition', 'test']) == 0
    spec = captured['spec']
    assert len(spec['tasks']) == 1
    task = spec['tasks'][0]
    assert task['id'] == 'ccsdtq_dz'
    assert task['result_parser']['reference'] == 'UHF'
    assert task['source_reference_validation'] == 'methyl-qz-2017-UHF'
    assert 'scftype=UHF' in task['input_template']
    assert 'rohftype=' not in task['input_template']
    assert spec['intent']['source_reference_validation'] == \
        'methyl-qz-2017-UHF'
    unpinned = json.loads(json.dumps(spec))
    del unpinned['intent']['source_reference_validation']
    with pytest.raises(ValueError, match='reference conflicts'):
        validate_spec(unpinned)
    # A source reproduction is explicit provenance, never a molecule-name or
    # doublet-only exception inside the general dispatcher.
    generic = json.loads(json.dumps(spec))
    generic['molecule']['multiplicity'] = 4
    generic['tasks'][0]['source_reference_validation'] = 'another-source-UHF'
    generic['intent']['source_reference_validation'] = 'another-source-UHF'
    generic['intent']['literature_benchmark']['name'] = 'another-source'
    validate_spec(generic)
    generic['intent']['claim'] = 'automatic-cbh-anl-production'
    with pytest.raises(ValueError, match='reference conflicts'):
        validate_spec(generic)


def test_methyl_current_profile_compares_to_published_targets(monkeypatch):
    benchmark = BENCHMARKS['methyl-qz-2017']
    tasks = [{
        'id': 'ccsdt_dz', 'backend': 'molpro',
        'result_parser': {
            'method': 'CCSD(T)', 'basis': 'cc-pVDZ',
            'reference': 'ROHF'}}, {
        'id': 'ccsdtq_dz', 'backend': 'mrcc',
        'result_parser': {
            'method': 'CCSDT(Q)', 'basis': 'cc-pVDZ',
            'reference': 'ROHF', 'correlation': 'unrestricted'}}]
    monkeypatch.setattr(
        literature, '_load',
        lambda run_dir: (Path(run_dir), {
            'molecule': benchmark['molecule'], 'tasks': tasks}, {
            'tasks': {
                'ccsdt_dz': {'status': 'complete'},
                'ccsdtq_dz': {'status': 'complete'},
            }}))
    monkeypatch.setattr(
        literature, '_verified_task_result',
        lambda run_dir, task_id: (
            None, None, None, None, None,
            {'energy_hartree': {
                'ccsdt_dz': -39.715724312484,
                'ccsdtq_dz': -39.716241160157,
            }[task_id]}))
    result = literature.compare_run('methyl-qz-2017', '/synthetic/run')
    assert result['status'] == 'passed'
    assert result['profiled_variant'] is True
    assert result['calculation_profiles']['ccsdt_dz'] == (
        'published-MOLPRO-2012.1-to-current-MOLPRO-RUCCSD(T)')
    assert result['calculation_request_variants']['ccsdtq_dz'] == {
        'reference': {'published': 'UHF', 'observed': 'ROHF'}}
    low = result['checks']['ccsdt_dz']
    assert low['error_hartree'] == pytest.approx(1.9097516e-5)
    assert low['source_exact_tolerance_hartree'] == pytest.approx(2e-6)
    assert low['absolute_tolerance_hartree'] == pytest.approx(5e-5)
    assert low['tolerance_profile'] == (
        'published-MOLPRO-2012.1-to-current-MOLPRO-RUCCSD(T)')
    check = result['checks']['ccsdtq_dz']
    assert check['error_hartree'] == pytest.approx(1.9499843e-5)
    assert check['source_exact_tolerance_hartree'] == pytest.approx(2e-6)
    assert check['absolute_tolerance_hartree'] == pytest.approx(5e-5)
    assert check['tolerance_profile'] == 'published-UHF-to-current-ROHF'


def test_run_comparison_rejects_a_different_reference(monkeypatch):
    task = {
        'id': 'ccsdtqp_dz', 'backend': 'mrcc',
        'result_parser': {
            'method': 'CCSDTQ(P)', 'basis': 'cc-pVDZ',
            'reference': 'UHF', 'correlation': 'unrestricted'}}
    monkeypatch.setattr(
        literature, '_load',
        lambda run_dir: (Path(run_dir), {
            'molecule':
                literature.BENCHMARKS['methane-qz-2017']['molecule'],
            'tasks': [task]}, {
            'tasks': {'ccsdtqp_dz': {'status': 'complete'}}}))
    monkeypatch.setattr(
        literature, '_verified_task_result',
        lambda run_dir, task_id: (
            None, None, None, None, None,
            {'energy_hartree': -40.387527542311}))
    with pytest.raises(ValueError, match='does not match'):
        literature.compare_run('methane-qz-2017', '/synthetic/run')


def test_run_comparison_uses_verified_native_driver_evidence(monkeypatch):
    benchmark = BENCHMARKS['methane-qz-2017']
    task = {
        'id': 'ccsdtq_dz', 'backend': 'mrcc',
        'result_parser': {
            'method': 'CCSDT(Q)', 'basis': 'cc-pVDZ',
            'reference': 'RHF', 'correlation': 'unrestricted'}}
    monkeypatch.setattr(
        literature, '_load',
        lambda run_dir: (Path(run_dir), {
            'molecule': benchmark['molecule'], 'tasks': [task]}, {
            'tasks': {'ccsdtq_dz': {'status': 'complete'}}}))
    monkeypatch.setattr(
        literature, '_verified_task_result',
        lambda run_dir, task_id: (
            None, None, None, None, None, {
                'energy_hartree': benchmark['tasks']['ccsdtq_dz']['expected'],
                'driver': 'direct'}))
    result = literature.compare_run('methane-qz-2017', '/synthetic/run')
    assert result['status'] == 'passed'
    assert result['calculation_request_native_evidence'] == {
        'ccsdtq_dz': {'driver': 'direct'}}


def test_run_comparison_does_not_invent_missing_driver(monkeypatch):
    benchmark = BENCHMARKS['methane-qz-2017']
    task = {
        'id': 'ccsdtq_dz', 'backend': 'mrcc',
        'result_parser': {
            'method': 'CCSDT(Q)', 'basis': 'cc-pVDZ',
            'reference': 'RHF', 'correlation': 'unrestricted'}}
    monkeypatch.setattr(
        literature, '_load',
        lambda run_dir: (Path(run_dir), {
            'molecule': benchmark['molecule'], 'tasks': [task]}, {
            'tasks': {'ccsdtq_dz': {'status': 'complete'}}}))
    monkeypatch.setattr(
        literature, '_verified_task_result',
        lambda run_dir, task_id: (
            None, None, None, None, None, {
                'energy_hartree': benchmark['tasks']['ccsdtq_dz']['expected']}))
    with pytest.raises(ValueError, match="'observed': None"):
        literature.compare_run('methane-qz-2017', '/synthetic/run')


def test_formation_comparison_uses_computed_cbh_result(tmp_path):
    expected = BENCHMARKS['methyl-qz-2017'][
        'formation_enthalpy_0k_kcal_mol']['ANL0-F12']
    result = tmp_path / 'methyl-cbh.json'
    result.write_text(json.dumps({
        'schema': 1, 'status': 'complete',
        'formation': {
            'target_smiles': '[CH3]', 'method': 'ANL0-F12',
            'formation_0k_kj_mol': (expected + 0.02) * 4.184,
        },
    }))
    comparison = literature.compare_formation(
        'methyl-qz-2017', result, absolute_tolerance_kcal_mol=0.1)
    assert comparison['status'] == 'passed'
    assert comparison['error_kcal_mol'] == pytest.approx(0.02)
    assert 'inserted' in comparison['note']

    profile = 'profiled:ANL0-F12:scaled-triples:B2PLYP-D3BJ'
    payload = json.loads(result.read_text())
    payload['formation']['method'] = profile
    result.write_text(json.dumps(payload))
    comparison = literature.compare_formation(
        'methyl-qz-2017', result, method=profile,
        absolute_tolerance_kcal_mol=0.1)
    assert comparison['status'] == 'passed'
    assert comparison['benchmark_method_family'] == 'ANL0-F12'
    assert comparison['profiled_variant'] is True


def test_formation_comparison_rejects_wrong_species_or_method(tmp_path):
    result = tmp_path / 'wrong-cbh.json'
    result.write_text(json.dumps({
        'schema': 1, 'status': 'complete',
        'formation': {
            'target_smiles': 'C', 'method': 'ANL0',
            'formation_0k_kj_mol': 0.,
        },
    }))
    with pytest.raises(ValueError, match='target'):
        literature.compare_formation('methyl-qz-2017', result)
