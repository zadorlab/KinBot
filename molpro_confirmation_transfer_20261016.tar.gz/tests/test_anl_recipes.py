"""Complete-expression arithmetic and provenance gates use synthetic energies."""

from dataclasses import replace

import pytest

from kinbot.anl.model import ComponentResult, IncompleteRecipeError
from kinbot.anl.recipes import recipe


L2 = '1' * 64
L3 = '2' * 64
SOURCE = 'a' * 64


def components_for(equation, *, multiplicity=1):
    values = {
        'reference_cbs': -100.0,
        'harmonic_zpe': 0.1,
        'vpt2_correction': -0.01,
        'hoe_high': -99.8,
        'hoe_low': -99.7,
        'hoe_tz_high': -99.8,
        'hoe_tz_low': -99.7,
        'hoe_dz_high': -99.9,
        'hoe_dz_low': -99.85,
        'higher_order_correction': 0.0,
        'core_valence_cbs': -0.02,
        'scalar_relativistic': -0.005,
        'dboc': 0.002,
        'spin_orbit': 0.0,
    }
    result = {}
    for requirement in equation.requirements:
        backend = requirement.backends[0]
        if requirement.key in ('hoe_high', 'hoe_tz_high') and multiplicity > 1:
            backend = 'mrcc'
        if requirement.key == 'hoe_dz_low' and multiplicity > 1:
            backend = 'mrcc'
        result[requirement.key] = ComponentResult(
            key=requirement.key, value_hartree=values[requirement.key],
            quantity=requirement.quantity, method=requirement.method,
            basis=requirement.basis, backend=backend, state_id='state-A',
            charge=0, multiplicity=multiplicity,
            geometry_sha256=(None if requirement.geometry_role == 'state'
                             else {'l2': L2, 'l3': L3}[requirement.geometry_role]),
            source_sha256=SOURCE, source='synthetic calculation record',
            settings=dict(requirement.settings),
        )
    return result


def evaluate(equation, components, *, multiplicity=1):
    return equation.evaluate(components, state_id='state-A', charge=0,
                             multiplicity=multiplicity,
                             geometry_hashes={'l2': L2, 'l3': L3})


@pytest.mark.parametrize('name', ['ANL0', 'ANL0-F12'])
def test_complete_anl0_expressions_include_zpe_once(name):
    equation = recipe(name)
    components = components_for(equation)
    result = evaluate(equation, components)
    assert result.electronic_hartree == pytest.approx(-100.123)
    assert result.zero_point_hartree == pytest.approx(0.09)
    assert result.zero_k_hartree == pytest.approx(-100.033)
    assert equation.name == (
        ('profiled:ANL0-F12:scaled-triples:'
         'dual-CBS-high-reference') if name == 'ANL0-F12'
        else name)
    if name == 'ANL0-F12':
        assert components['reference_cbs'].method == \
            'mean[CCSD(T)-F12b,CCSD(T)]'
        assert components['reference_cbs'].settings['scale_trip'] == 1
    else:
        assert components['reference_cbs'].method == 'CCSD(T)'
        assert components['reference_cbs'].settings['native_basis_pair'] == (
            'aug-cc-pVQZ', 'aug-cc-pV5Z')


def test_reduced_recipe_omits_whole_additive_families_with_explicit_label():
    equation = recipe(
        'ANL0-F12', vpt2_method='B2PLYP-D3BJ',
        omitted_families=('higher_order', 'dboc'))
    keys = {item.key for item in equation.requirements}
    assert not keys & {'hoe_high', 'hoe_low', 'dboc'}
    assert {'reference_cbs', 'core_valence_cbs', 'scalar_relativistic',
            'spin_orbit', 'harmonic_zpe', 'vpt2_correction'} <= keys
    assert equation.name.endswith(
        'reduced[without=higher_order+dboc]')
    result = evaluate(equation, components_for(equation))
    assert result.electronic_hartree == pytest.approx(-100.025)
    assert result.zero_k_hartree == pytest.approx(-99.935)


def test_reduced_recipe_rejects_unknown_or_duplicate_families():
    with pytest.raises(ValueError, match='omitted'):
        recipe('ANL0', omitted_families=('invented',))
    with pytest.raises(ValueError, match='omitted'):
        recipe('ANL0', omitted_families=('dboc', 'dboc'))


def test_anl1_cross_program_higher_order_pairs_and_profiled_label():
    equation = recipe('ANL1', vpt2_method='B2PLYP-D3BJ')
    components = components_for(equation)
    result = evaluate(equation, components)
    assert result.electronic_hartree == pytest.approx(-100.173)
    assert result.zero_k_hartree == pytest.approx(-100.083)
    assert result.recipe == 'profiled:ANL1:B2PLYP-D3BJ'
    assert components['hoe_tz_high'].backend == 'mrcc'
    assert components['hoe_tz_high'].settings['reference'] == 'RHF'
    assert components['hoe_tz_high'].settings['correlation'] == 'unrestricted'
    assert components['hoe_tz_low'].backend == 'molpro'
    assert components['hoe_dz_high'].backend == 'mrcc'
    assert components['vpt2_correction'].settings['dispersion'] == 'GD3BJ'


def test_anl1_f12_uses_ram_high_reference_with_anl_power_extrapolation():
    equation = recipe('ANL1-F12', vpt2_method='B2PLYP-D3BJ')
    requirements = {item.key: item for item in equation.requirements}
    reference = requirements['reference_cbs']
    assert reference.method == 'mean[CCSD(T)-F12b,CCSD(T)]'
    assert reference.basis == \
        'mean[CBS(cc-pVQZ-F12,cc-pV5Z-F12),CBS(aug-5Z,aug-6Z)]'
    assert reference.settings['component_weights'] == (0.5, 0.5)
    assert reference.settings['f12_extrapolation_power'] == 3.7
    assert reference.settings['conventional_extrapolation_power'] == 3.7
    assert reference.settings['reference_convention'] == 'RHF/ROHF-UCC'
    assert requirements['harmonic_zpe'].backends == ('composite',)
    assert {item.key for item in equation.requirements} >= {
        'hoe_tz_high', 'hoe_tz_low', 'hoe_dz_high', 'hoe_dz_low'}
    assert evaluate(equation, components_for(equation)).recipe == (
        'profiled:ANL1-F12:scaled-triples:'
        'Ram-2025-high-reference:B2PLYP-D3BJ')


def test_anl0_f12_uses_tier_matched_dual_cbs_reference():
    reference = next(item for item in recipe('ANL0-F12').requirements
                     if item.key == 'reference_cbs')
    assert reference.basis == (
        'mean[CBS(cc-pVTZ-F12,cc-pVQZ-F12),CBS(aug-QZ,aug-5Z)]')
    assert reference.settings['f12_native_basis_pair'] == (
        'cc-pVTZ-F12', 'cc-pVQZ-F12')
    assert reference.settings['conventional_native_basis_pair'] == (
        'aug-cc-pVQZ', 'aug-cc-pV5Z')
    assert reference.settings['f12_upper_cardinal'] == 4
    assert reference.settings['conventional_upper_cardinal'] == 5


@pytest.mark.parametrize('name,expected', [
    ('ANL0-F12', ('aug-cc-pVTZ-F12', 'aug-cc-pVQZ-F12')),
    ('ANL1-F12', ('aug-cc-pVQZ-F12', 'aug-cc-pV5Z-F12')),
])
def test_f12_reference_can_be_fully_augmented(name, expected):
    equation = recipe(name, f12_augmented=True)
    reference = next(item for item in equation.requirements
                     if item.key == 'reference_cbs')
    assert reference.settings['f12_native_basis_pair'] == expected
    assert ':augmented-F12:' in equation.name


def test_f12_augmentation_option_does_not_change_conventional_recipe():
    assert recipe('ANL0', f12_augmented=True) == recipe('ANL0')


def test_rank_exact_higher_order_backend_is_narrowly_allowed():
    equation = recipe('ANL0-F12', vpt2_method='B2PLYP-D3BJ')
    components = components_for(equation)
    high = components['hoe_high']
    components['hoe_high'] = replace(
        high, value_hartree=components['hoe_low'].value_hartree,
        backend='known_zero', settings={
            **high.settings,
            'rank_exact': {'electron_count': 2,
                           'reused_low_source_sha256': SOURCE},
        })
    result = evaluate(equation, components)
    assert result.components['hoe_high'].backend == 'known_zero'
    assert result.electronic_hartree == pytest.approx(-100.023)


@pytest.mark.parametrize('name', ['ANL0', 'ANL0-F12', 'ANL1', 'ANL1-F12'])
def test_rank_exact_recipe_has_one_zero_correction_not_cancelling_energies(name):
    equation = recipe(name, rank_exact_higher_order=True)
    keys = {item.key for item in equation.requirements}
    assert 'higher_order_correction' in keys
    assert not keys & {
        'hoe_high', 'hoe_low', 'hoe_tz_high', 'hoe_tz_low',
        'hoe_dz_high', 'hoe_dz_low'}
    requirement = next(item for item in equation.requirements
                       if item.key == 'higher_order_correction')
    assert requirement.quantity == 'correction'
    assert requirement.backends == ('known_zero',)
    assert components_for(equation)['higher_order_correction'].value_hartree == 0.


def test_optional_vpt2_cbs_remains_one_zero_point_correction():
    equation = recipe('ANL1', vpt2_method='B2PLYP-D3BJ', vpt2_cbs=True)
    components = components_for(equation)
    result = evaluate(equation, components)
    assert result.recipe == 'profiled:ANL1:B2PLYP-D3BJ:VPT2-CBS'
    assert result.zero_point_hartree == pytest.approx(0.09)
    assert components['vpt2_correction'].basis == 'CBS(cc-pVTZ,cc-pVQZ)'
    assert components['vpt2_correction'].backend == 'composite'


def test_l2_geometry_and_harmonic_fallbacks_are_explicit_recipe_variants():
    equation = recipe(
        'ANL0-F12', vpt2_method='B2PLYP-D3BJ',
        fallback_geometry_method='B2PLYP',
        fallback_harmonic_method='B2PLYP-D3BJ',
        fallback_basis='cc-pVTZ')
    requirements = {item.key: item for item in equation.requirements}
    assert requirements['reference_cbs'].settings['geometry_method'] == 'B2PLYP'
    assert requirements['harmonic_zpe'].method == 'B2PLYP-D3BJ'
    assert requirements['harmonic_zpe'].geometry_role == 'l2'
    assert requirements['harmonic_zpe'].backends == ('kinbot',)
    assert 'B2PLYP/cc-pVTZ-geometry' in equation.name
    assert 'B2PLYP-D3BJ/cc-pVTZ-ZPE' in equation.name
    components = components_for(equation)
    assert evaluate(equation, components).recipe == equation.name


def test_incomplete_or_unreviewed_components_cannot_be_called_anl():
    equation = recipe('ANL0-F12')
    components = components_for(equation)
    del components['hoe_high']
    with pytest.raises(IncompleteRecipeError, match='hoe_high'):
        evaluate(equation, components)
    components = components_for(equation)
    components['vpt2_correction'] = replace(components['vpt2_correction'],
                                            review_required=True)
    with pytest.raises(IncompleteRecipeError, match='quality review'):
        evaluate(equation, components)


def test_geometry_method_and_source_identity_are_enforced():
    equation = recipe('ANL0-F12')
    components = components_for(equation)
    components['vpt2_correction'] = replace(components['vpt2_correction'],
                                            geometry_sha256=L3)
    with pytest.raises(ValueError, match='geometry differs'):
        evaluate(equation, components)
    components = components_for(equation)
    components['reference_cbs'] = replace(components['reference_cbs'],
                                          method='CCSD(T)-F12a')
    with pytest.raises(ValueError, match='method'):
        evaluate(equation, components)
    components = components_for(equation)
    components['reference_cbs'] = replace(components['reference_cbs'],
                                          settings={'scale_trip': 0})
    with pytest.raises(ValueError, match='settings'):
        evaluate(equation, components)
    components = components_for(equation)
    components['dboc'] = replace(components['dboc'], source_sha256='')
    with pytest.raises(ValueError, match='provenance'):
        evaluate(equation, components)


def test_open_shell_higher_order_uses_mrcc_and_spin_orbit_is_explicit():
    equation = recipe('ANL0', multiplicity=2)
    components = components_for(equation, multiplicity=2)
    assert evaluate(equation, components, multiplicity=2).zero_k_hartree == \
        pytest.approx(-100.033)
    components['hoe_high'] = replace(components['hoe_high'], backend='cfour')
    with pytest.raises(ValueError, match='backend'):
        evaluate(equation, components, multiplicity=2)
    components = components_for(equation, multiplicity=2)
    del components['spin_orbit']
    with pytest.raises(IncompleteRecipeError, match='spin_orbit'):
        evaluate(equation, components, multiplicity=2)

    extended = recipe('ANL1', multiplicity=2)
    extended_components = components_for(extended, multiplicity=2)
    assert evaluate(extended, extended_components, multiplicity=2).recipe == 'ANL1'
    extended_components['hoe_dz_low'] = replace(
        extended_components['hoe_dz_low'], backend='cfour')
    with pytest.raises(ValueError, match='backend'):
        evaluate(extended, extended_components, multiplicity=2)
