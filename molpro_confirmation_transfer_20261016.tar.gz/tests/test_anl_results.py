"""Native result labels and units are part of the scientific acceptance gate."""

from pathlib import Path
import sys
from tempfile import TemporaryDirectory

import pytest

from kinbot.anl.dispatch import _run_external
from kinbot.anl.results import (
    parse_cfour_dboc, parse_cfour_energy, parse_gaussian_vpt2,
    parse_molpro_energy, parse_molpro_harmonic, parse_mrcc_energy,
    parse_result, parsed_result_extends, validate_result_parser,
)
from kinbot.energy import attach_anharmonic_frequencies


# The values and surrounding labels are from the completed Blodgett CH4 job.
_CFOUR_CH4 = """BASIS=cc-pVTZ
Total SCF energy including DBOC  -40.210746196622267
Summary of diagonal Born-Oppenheimer correction at Hartree-Fock level
The total diagonal Born-Oppenheimer correction (DBOC) is: 0.0025887093 a.u.
The total diagonal Born-Oppenheimer correction (DBOC) is: 568.156016 cm-1
The total diagonal Born-Oppenheimer correction (DBOC) is: 6.797 kJ/mole
Summary of diagonal Born-Oppenheimer correction at MP1 level
The total diagonal Born-Oppenheimer correction (DBOC) is: 0.0026718675 a.u.
The total diagonal Born-Oppenheimer correction (DBOC) is: 586.407129 cm-1
The total diagonal Born-Oppenheimer correction (DBOC) is: 7.015 kJ/mole
The final electronic energy is -40.210746196622267 a.u.
This computation required 31.93 seconds (walltime).
"""

_MRCC_CCSDTQP = """Input file:
basis=cc-pVDZ
calc=CCSDTQ(P)
ccprog=mrcc
scftype=ROHF
rohftype=semicanonical
rohfcore=semicanonical
core=frozen
Total CCSDTQ energy [au]: -39.123400000000
Total CCSDTQ(P)/A energy [au]: -39.123456700000
Total CCSDTQ(P)/B energy [au]: -39.123456789012
Normal termination of mrcc.
"""

_MRCC_METHYL_CCSDTQ = """Input file:
basis=cc-pVDZ
calc=CCSDT(Q)
ccprog=mrcc
scftype=ROHF
rohftype=semicanonical
rohfcore=semicanonical
core=frozen
Total CCSDT energy [au]: -39.716126916675
Total CCSDT[Q] energy [au]: -39.716201539184
Total CCSDT(Q)/A energy [au]: -39.716240924926
Total CCSDT(Q)/B energy [au]: -39.716241160157
Normal termination of mrcc.
"""

_CFOUR_CCSDTQ = """CALC_LEVEL       ICALC       CCSDT(Q)    [ 54]    ***
BASIS            IBASIS      cc-pVTZ     [ 14]    ***
REFERENCE        IREF        RHF         [  0]    ***
CC_PROGRAM       ICCPRO      VCC         [  0]    ***
FROZEN_CORE      IFROCO      ON          [  1]    ***
  calling xvcc
 --invoking executable--
/opt/cfour/2.1/bin/xvcc
The final electronic energy is -79.123456789012 a.u.
This computation required 31.93 seconds (walltime).
"""

_ONE_ELECTRON_F12_NAN = """basis=cc-pVTZ-F12
rhf
uccsd(t)-f12b,scale_trip=1
 PROGRAMS   *        TOTAL  UCCSD(T)   RHF-SCF       INT
 Number of N-1 electron functions:               1
 Number of N-2 electron functions:               0
 New reference energy                 -0.499946213253
 RMP2-F12 correlation energy           0.000000000000
 Starting UCCSD calculation
 New reference energy                 -0.499946213253
 UCCSD-F12b singles energy            -0.000000000000
 UCCSD-F12b pair energy                0.000000000000
 UCCSD-F12b correlation energy        -0.000000000000
 Scale factor for triples energy                  NaN
 ? Error
 ? NaN detected by ieee_is_nan
 ? The problem occurs in is_nan
 GLOBAL ERROR fehler on processor   0
"""

_ONE_ELECTRON_F12_SAFE = """basis=cc-pVTZ-F12
rhf
uccsd-f12b
 PROGRAMS   *        TOTAL     UCCSD   RHF-SCF       INT
 Number of N-1 electron functions:               1
 Number of N-2 electron functions:               0
 RMP2-F12 correlation energy           0.000000000000
 Starting UCCSD calculation
 UCCSD-F12b singles energy            -0.000000000000
 UCCSD-F12b pair energy                0.000000000000
 UCCSD-F12b correlation energy        -0.000000000000
 !RHF-UCCSD-F12b energy               -0.499946213253
 Molpro calculation terminated
"""


def test_cfour_selects_hf_dboc_without_confusing_mp1_or_final_energy():
    result = parse_cfour_dboc(_CFOUR_CH4)
    assert result['selected_level'] == 'HF'
    assert result['selected']['hartree'] == pytest.approx(0.0025887093)
    assert result['selected']['cm_inverse'] == pytest.approx(568.156016)
    assert result['reported_levels']['MP1']['hartree'] == pytest.approx(0.0026718675)
    assert result['final_energy_including_dboc_hartree'] == pytest.approx(
        -40.210746196622267)
    assert parse_cfour_dboc(_CFOUR_CH4, level='MP1')['selected']['hartree'] == \
        pytest.approx(0.0026718675)


def test_cfour_rejects_incomplete_and_inconsistent_dboc_output():
    assert parse_cfour_dboc(_CFOUR_CH4, basis='cc-pVTZ')['selected_level'] == 'HF'
    with pytest.raises(ValueError, match='basis'):
        parse_cfour_dboc(_CFOUR_CH4, basis='cc-pVQZ')
    with pytest.raises(ValueError, match='completion'):
        parse_cfour_dboc(_CFOUR_CH4.replace('This computation required',
                                           'Computation did not complete'))
    with pytest.raises(ValueError, match='a.u./cm-1'):
        parse_cfour_dboc(_CFOUR_CH4.replace('568.156016', '500.000000'))
    with pytest.raises(ValueError, match='repeated the HF'):
        parse_cfour_dboc(_CFOUR_CH4.replace(
            'Summary of diagonal Born-Oppenheimer correction at MP1 level',
            'Summary of diagonal Born-Oppenheimer correction at Hartree-Fock level'))


def test_direct_mrcc_higher_order_energy_uses_rohf_ucc_convention():
    result = parse_mrcc_energy(
        _MRCC_CCSDTQP, method='CCSDTQ(P)', basis='cc-pVDZ',
        reference='ROHF', correlation='unrestricted', core='frozen',
        program='mrcc')
    assert result['energy_hartree'] == pytest.approx(-39.123456789012)
    assert result['reference'] == 'ROHF'
    assert result['correlation'] == 'unrestricted'
    assert result['program_variant'] == 'ROHF-UCCSDTQ(P)/B'
    assert result['selected_perturbative_variant'] == 'B'
    assert result['perturbative_variants_hartree'] == pytest.approx({
        'A': -39.123456700000,
        'B': -39.123456789012,
    })
    with pytest.raises(ValueError, match='scftype'):
        parse_mrcc_energy(
            _MRCC_CCSDTQP.replace('scftype=ROHF', 'scftype=UHF'),
            method='CCSDTQ(P)', basis='cc-pVDZ', reference='ROHF',
            correlation='unrestricted', core='frozen', program='mrcc')
    uhf = _MRCC_CCSDTQP.replace(
        'scftype=ROHF\nrohftype=semicanonical\nrohfcore=semicanonical\n',
        'scftype=UHF\n')
    source_result = parse_mrcc_energy(
        uhf, method='CCSDTQ(P)', basis='cc-pVDZ', reference='UHF',
        correlation='unrestricted', core='frozen', program='mrcc')
    assert source_result['reference'] == 'UHF'
    assert source_result['program_variant'] == 'UHF-UCCSDTQ(P)/B'
    with pytest.raises(ValueError, match='normal termination'):
        parse_mrcc_energy(
            _MRCC_CCSDTQP.replace('Normal termination of mrcc.',
                                  'Error at the termination of mrcc.'),
            method='CCSDTQ(P)', basis='cc-pVDZ', reference='ROHF',
            correlation='unrestricted', core='frozen', program='mrcc')


def test_direct_mrcc_selects_b_from_native_rohf_perturbative_pair():
    result = parse_mrcc_energy(
        _MRCC_METHYL_CCSDTQ, method='CCSDT(Q)', basis='cc-pVDZ',
        reference='ROHF', correlation='unrestricted', core='frozen',
        program='mrcc')
    assert result['energy_hartree'] == pytest.approx(-39.716241160157)
    assert result['selected_perturbative_variant'] == 'B'
    assert result['perturbative_variants_hartree'] == pytest.approx({
        'A': -39.716240924926,
        'B': -39.716241160157,
    })
    assert result['program_variant'] == 'ROHF-UCCSDT(Q)/B'


def test_direct_mrcc_anl1_tz_output_uses_same_strict_rohf_parser():
    basis = 'cc-pVTZ'
    output = _MRCC_METHYL_CCSDTQ.replace('basis=cc-pVDZ', f'basis={basis}')
    result = parse_mrcc_energy(
        output, method='CCSDT(Q)', basis=basis, reference='ROHF',
        correlation='unrestricted', core='frozen', program='mrcc')
    assert result['basis'] == basis
    assert result['selected_perturbative_variant'] == 'B'
    assert result['program_variant'] == 'ROHF-UCCSDT(Q)/B'


def test_direct_mrcc_requires_complete_unambiguous_variant_pair():
    with pytest.raises(ValueError, match=r'lacks perturbative variant.*B'):
        parse_mrcc_energy(
            _MRCC_METHYL_CCSDTQ.replace(
                'Total CCSDT(Q)/B energy [au]: -39.716241160157\n', ''),
            method='CCSDT(Q)', basis='cc-pVDZ', reference='ROHF',
            correlation='unrestricted', core='frozen', program='mrcc')
    with pytest.raises(ValueError, match='ambiguously reports'):
        parse_mrcc_energy(
            _MRCC_METHYL_CCSDTQ.replace(
                'Normal termination of mrcc.',
                'Total CCSDT(Q) energy [au]: -39.716241160157\n'
                'Normal termination of mrcc.'),
            method='CCSDT(Q)', basis='cc-pVDZ', reference='ROHF',
            correlation='unrestricted', core='frozen', program='mrcc')


def test_cfour_higher_order_energy_requires_rhf_spin_orbital_execution():
    result = parse_cfour_energy(
        _CFOUR_CCSDTQ, method='CCSDT(Q)', basis='cc-pVTZ',
        reference='RHF', correlation='unrestricted', core='frozen',
        program='cfour', driver='VCC')
    assert result['energy_hartree'] == pytest.approx(-79.123456789012)
    assert result['program_variant'] == 'RHF-UCCSDT(Q)'
    with pytest.raises(ValueError, match='REFERENCE=RHF'):
        parse_cfour_energy(
            _CFOUR_CCSDTQ.replace('RHF         [  0]',
                                  'UHF         [  1]'),
            method='CCSDT(Q)', basis='cc-pVTZ', reference='RHF',
            correlation='unrestricted', core='frozen', program='cfour',
            driver='VCC')
    with pytest.raises(ValueError, match='completion'):
        parse_cfour_energy(
            _CFOUR_CCSDTQ.replace('This computation required', 'Incomplete'),
            method='CCSDT(Q)', basis='cc-pVTZ', reference='RHF',
            correlation='unrestricted', core='frozen', program='cfour',
            driver='VCC')
    with pytest.raises(ValueError, match='observed xncc'):
        parse_cfour_energy(
            _CFOUR_CCSDTQ.replace('calling xvcc', 'calling xncc')
            .replace('/xvcc', '/xncc'),
            method='CCSDT(Q)', basis='cc-pVTZ', reference='RHF',
            correlation='unrestricted', core='frozen', program='cfour',
            driver='VCC')


def test_external_cfour_task_stores_selected_native_result():
    with TemporaryDirectory() as temporary:
        directory = Path(temporary)
        (directory / 'ZMAT').write_text('*CFOUR(CALC=SCF\nDBOC=ON)\n')
        task = {
            'id': 'dboc', 'kind': 'external', 'backend': 'cfour',
            'input_name': 'ZMAT',
            'resources': {'cores': 1, 'memory_mb': 1024},
            'command': [sys.executable, '-c',
                        'import sys; sys.stdout.write(' + repr(_CFOUR_CH4) + ')'],
            'stdout': 'cfour.out', 'stderr': 'cfour.err',
            'required_outputs': ['cfour.out'],
            'success_marker': {'file': 'cfour.out',
                               'contains': 'The total diagonal Born-Oppenheimer correction'},
            'result_parser': {'kind': 'cfour_dboc', 'file': 'cfour.out',
                              'level': 'HF'},
        }
        details = _run_external(directory, {'task': task})
        assert details['returncode'] == 0
        assert details['parsed_result']['selected']['hartree'] == \
            pytest.approx(0.0025887093)


# This compact excerpt preserves the exact method markers emitted by native
# Molpro 2024.1 for both closed-shell H2O and open-shell CH3O/HO2 jobs.  The
# licensed program output itself is not bundled with the tests.
_MOLPRO_F12 = """basis=cc-pVTZ-F12
rhf
uccsd(t)-f12b,scale_trip=1
kb_f12b=energy
 Starting UCCSD calculation
 F12 corrections for ansatz 3C(FIX) added to UCCSD energy
 UCCSD-F12b correlation energy -0.288234238676
 Number of N-1 electron functions: 7
 Triples (T) contribution (scaled) -0.006123456789
 RHF-UCCSD-F12b energy -40.448782742400
 !RHF-UCCSD(T)-F12 energy -40.454906199189
 PROGRAMS   *        TOTAL  UCCSD(T)   RHF-SCF       INT
 SETTING KB_F12B = -40.45490620 AU
 Molpro calculation terminated
"""

_MOLPRO_HARMONIC = """basis=cc-pVTZ
rhf
uccsd(t)
 Number of N-1 electron functions: 7
 Triples (T) contribution -0.006123456789
 PROGRAMS * TOTAL FREQ UCCSD(T) RHF-SCF INT
frequencies,numerical
 PROGRAM * FREQUENCIES (Calculation of harmonic vibrational spectra for UCCSD(T))
   Low Vibration      Wavenumber
        Nr             [1/cm]
        1                0.00
     Vibration        Wavenumber
        Nr             [1/cm]
        1             1343.29
        2             1343.90
        3             1344.76
        4             1570.56
        5             1570.88
        6             3033.49
        7             3151.55
        8             3152.19
        9             3153.44

 Zero point energy:  0.04479801 [H]     9832.03 [1/CM]      117.62 [KJ/MOL]
 Molpro calculation terminated
"""

_MOLPRO_OPEN_CCSD_T = """basis=cc-pVDZ
rhf
uccsd(t)
 PROGRAM * RHF-SCF
 Number of N-1 electron functions: 7
 Triples (T) contribution -0.006123456789
 RHF-UCCSD energy -39.806222222112
 !RHF-UCCSD(T) energy -39.812345678901
 Molpro calculation terminated
"""

_MOLPRO_OPEN_HARMONIC = _MOLPRO_HARMONIC

_MOLPRO_LEGACY_F12 = """basis=cc-pVTZ-F12
hf
ccsd(t)-f12,scale_trip=1
kb_f12b=energy(2)
 !CCSD(T)-F12b total energy -40.454906199189
 CCSD(T)-F12/cc-pVTZ-F12 energy = -40.454906199189
 Molpro calculation terminated
"""

_MOLPRO_LEGACY_HARMONIC = (_MOLPRO_HARMONIC
                           .replace('rhf\nuccsd(t)',
                                    'hf\nccsd(t)')
                           .replace('for UCCSD(T))', 'for CCSD(T))'))

_MOLPRO_ALL_ELECTRON_DKH = """basis=aug-cc-pCVTZ-DK
set,dkho=2
rhf
{uccsd(t);core}
 PROGRAM * RHF-SCF
 Number of N-1 electron functions: 7
 Triples (T) contribution -0.006123456789
 RHF-UCCSD energy -40.006222222112
 !RHF-UCCSD(T) energy -40.012345678901
 Molpro calculation terminated
"""

_GAUSSIAN_VPT2 = """#p B3LYP/cc-pVTZ Opt=(Tight,CalcFC) Freq=Anharmonic NoSymm
 WARNING: Unreliable CUBIC force constant i= 2,j= 1,k= 4
 Fundamental Bands
 -----------------
 Mode(n) Status      E(harm)   E(anharm)      I(harm)   I(anharm)
    1(1) active      3153.44     3010.18        0.10       0.12
 H  2(1) active      3152.19     3009.34        0.11       0.13
    3(1) active      3151.55     3008.91        0.12       0.14
    4(1) active      3033.49     2915.22        0.13       0.15
    5(1) active      1570.88     1534.77        0.14       0.16
    6(1) active      1570.56     1534.46        0.15       0.17
    7(1) active      1344.76     1312.63        0.16       0.18
    8(1) active      1343.90     1311.85        0.17       0.19
    9(1) active      1343.29     1311.24        0.18       0.20
 Overtones
 Anharmonic Zero Point Energy
 ----------------------------
 Harmonic       : cm-1 =  9783.68667 ; Kcal/mol =  27.973
 Anharmonic Pot.: cm-1 =  -137.81811 ; Kcal/mol =  -0.394
 Watson+Coriolis: cm-1 =     0.49625 ; Kcal/mol =   0.001
 Total Anharm   : cm-1 =  9646.36482 ; Kcal/mol =  27.580
 Normal termination of Gaussian 16 at Thu Sep 17 19:56:44 2026.
"""


def test_gaussian_vpt2_c1_route_requires_native_framework_confirmation():
    requested = _GAUSSIAN_VPT2.replace(
        'Freq=Anharmonic NoSymm',
        'Freq=Anharmonic Symmetry=(PG=C1)')
    with pytest.raises(ValueError, match='confirm the requested C1'):
        parse_gaussian_vpt2(
            requested, method='B3LYP', basis='cc-pVTZ')
    confirmed = requested.replace(
        ' WARNING:', ' Framework group  C1[X(C,H4)]\n WARNING:', 1)
    result = parse_gaussian_vpt2(
        confirmed, method='B3LYP', basis='cc-pVTZ')
    assert result['framework_group_cap'] == 'C1'


def test_gaussian_vpt2_dispersion_value_may_wrap_inside_token():
    wrapped = (_GAUSSIAN_VPT2
               .replace('B3LYP/cc-pVTZ Opt=(Tight,CalcFC)',
                        'B2PLYP/cc-pVTZ')
               .replace('Freq=Anharmonic NoSymm',
                        ('Freq=Anharmonic Symmetry=(PG=C1) '
                         'EmpiricalDispersion=G\n D3BJ'))
               .replace(' WARNING:',
                        ' Framework group  C1[X(CH4)]\n WARNING:', 1))
    result = parse_gaussian_vpt2(
        wrapped, method='B2PLYP', basis='cc-pVTZ', dispersion='GD3BJ')
    assert result['dispersion'] == 'GD3BJ'
    assert result['framework_group_cap'] == 'C1'
    with pytest.raises(ValueError, match='dispersion disagrees'):
        parse_gaussian_vpt2(
            wrapped, method='B2PLYP', basis='cc-pVTZ', dispersion='GD3')


def test_gaussian_vpt2_reconstructs_keyword_and_value_route_wraps():
    wrapped_route = (_GAUSSIAN_VPT2
                     .replace(
                         '#p B3LYP/cc-pVTZ Opt=(Tight,CalcFC) '
                         'Freq=Anharmonic NoSymm',
                         (' ----------------------------------------------------------------------\n'
                          ' #p B2PLYP/cc-pVTZ Freq=Anharmonic '
                          'Symmetry=(PG=C1) EmpiricalD\n'
                          ' ispersion=G\n'
                          ' D3BJ Integral=UltraFine\n'
                          ' ----------------------------------------------------------------------'))
                     .replace(
                         ' WARNING:',
                         ' Framework group  C1[X(CH4)]\n WARNING:', 1))
    result = parse_gaussian_vpt2(
        wrapped_route, method='B2PLYP', basis='cc-pVTZ',
        dispersion='GD3BJ')
    assert result['dispersion'] == 'GD3BJ'
    assert result['framework_group_cap'] == 'C1'
    assert result['optimized_in_job'] is False


def test_gaussian_vpt2_framework_cap_parser_is_not_group_specific():
    output = (_GAUSSIAN_VPT2
              .replace('NoSymm', 'Symmetry=(PG=C2V)')
              .replace(' WARNING:',
                       ' Framework group  C2V[X(CH4)]\n WARNING:', 1))
    result = parse_gaussian_vpt2(
        output, method='B3LYP', basis='cc-pVTZ')
    assert result['framework_group_cap'] == 'C2V'


@pytest.mark.parametrize('failure', ['?No convergence in rhfpr', 'NO CONVERGENCE!'])
def test_molpro_composite_rejects_unconverged_native_output(failure):
    with pytest.raises(ValueError, match='unconverged'):
        parse_molpro_energy(failure + '\n' + _MOLPRO_F12,
                            method='CCSD(T)-F12b', basis='cc-pVTZ-F12')


def test_molpro_f12b_selects_exact_total_energy():
    result = parse_molpro_energy(_MOLPRO_F12, method='CCSD(T)-F12b',
                                 basis='cc-pVTZ-F12', reference='ROHF')
    assert result['energy_hartree'] == pytest.approx(-40.454906199189)
    assert result['method'] == 'CCSD(T)-F12b'
    assert result['reference'] == 'ROHF'
    assert result['correlation'] == 'unrestricted'
    assert result['program_variant'] == 'RHF-UCCSD(T)-F12b'
    without_fixture_variable = (_MOLPRO_F12
                                .replace('kb_f12b=energy\n', '')
                                .replace(' SETTING KB_F12B = -40.45490620 AU\n', ''))
    assert parse_molpro_energy(without_fixture_variable, method='CCSD(T)-F12b',
                               basis='cc-pVTZ-F12')['energy_hartree'] == \
        pytest.approx(-40.454906199189)
    with pytest.raises(ValueError, match='stored F12b'):
        parse_molpro_energy(_MOLPRO_F12.replace(
            'SETTING KB_F12B = -40.45490620',
            'SETTING KB_F12B = -40.45843499'),
            method='CCSD(T)-F12b', basis='cc-pVTZ-F12')
    with pytest.raises(ValueError, match='basis'):
        parse_molpro_energy(_MOLPRO_F12, method='CCSD(T)-F12b',
                            basis='cc-pVQZ-F12')


def test_molpro_hartree_unit_and_repeated_show_preserve_f12_validation():
    output = _MOLPRO_F12.replace(' AU', ' HARTREE') + '\n KB_F12B = -40.45490620 HARTREE\n'
    result = parse_molpro_energy(output, method='CCSD(T)-F12b', basis='cc-pVTZ-F12')
    assert result['energy_hartree'] == pytest.approx(-40.454906199189)
    with pytest.raises(ValueError, match='stored F12b'):
        parse_molpro_energy(output.replace('SETTING KB_F12B = -40.45490620',
                                          'SETTING KB_F12B = -40.45843499'),
                            method='CCSD(T)-F12b', basis='cc-pVTZ-F12')


def test_molpro_conventional_anl0_accepts_full_augmented_basis():
    basis = 'aug-cc-pVQZ'
    output = _MOLPRO_OPEN_CCSD_T.replace('basis=cc-pVDZ', f'basis={basis}')
    result = parse_molpro_energy(
        output, method='CCSD(T)', basis=basis, reference='ROHF')
    assert result['basis'] == basis
    assert result['program_variant'] == 'RHF-UCCSD(T)'


@pytest.mark.parametrize('basis', [
    'aug-cc-pV5Z',
    'aug-cc-pV6Z',
])
def test_molpro_conventional_anl1_basis_outputs_use_strict_parser(basis):
    output = _MOLPRO_OPEN_CCSD_T.replace('basis=cc-pVDZ', f'basis={basis}')
    result = parse_molpro_energy(
        output, method='CCSD(T)', basis=basis, reference='ROHF')
    assert result['basis'] == basis
    assert result['program_variant'] == 'RHF-UCCSD(T)'


def test_molpro_anl1_f12_5z_output_uses_strict_f12b_parser():
    basis = 'cc-pV5Z-F12'
    output = _MOLPRO_F12.replace('cc-pVTZ-F12', basis)
    result = parse_molpro_energy(
        output, method='CCSD(T)-F12b', basis=basis, reference='ROHF')
    assert result['basis'] == basis
    assert result['program_variant'] == 'RHF-UCCSD(T)-F12b'


def test_molpro_anl1_qz_harmonic_output_uses_strict_harmonic_parser():
    output = _MOLPRO_HARMONIC.replace('basis=cc-pVTZ', 'basis=cc-pVQZ')
    result = parse_molpro_harmonic(
        output, basis='cc-pVQZ', reference='RHF')
    assert result['basis'] == 'cc-pVQZ'
    assert result['program_variant'] == 'RHF-UCCSD(T)'


def test_one_electron_f12_avoids_and_recovers_undefined_triples_scaling():
    kwargs = {
        'method': 'CCSD(T)-F12b', 'basis': 'cc-pVTZ-F12',
        'reference': 'ROHF', 'rank_exact_electrons': 1,
    }
    safe = parse_molpro_energy(_ONE_ELECTRON_F12_SAFE, **kwargs)
    assert safe['energy_hartree'] == pytest.approx(-0.499946213253)
    assert safe['method'] == 'CCSD(T)-F12b'
    assert safe['effective_program_variant'] == 'RHF-UCCSD-F12b'
    assert safe['rank_exact']['electron_count'] == 1
    assert safe['rank_exact']['recovered_molpro_scale_trip_nan'] is False

    recovered = parse_molpro_energy(_ONE_ELECTRON_F12_NAN, **kwargs)
    assert recovered['energy_hartree'] == pytest.approx(-0.499946213253)
    assert recovered['rank_exact']['recovered_molpro_scale_trip_nan'] is True


def test_rank_exact_molpro_uses_hf_for_one_and_ccsd_for_two_electrons():
    hf = """basis=cc-pVTZ-F12
rhf
 PROGRAMS * TOTAL RHF-SCF INT
 !RHF STATE 1.1 Energy                 -0.499999123456
 Molpro calculation terminated
"""
    parsed_hf = parse_molpro_energy(
        hf, method='CCSD(T)-F12b', basis='cc-pVTZ-F12',
        reference='ROHF', rank_exact_electrons=1, effective_method='HF')
    assert parsed_hf['energy_hartree'] == pytest.approx(-0.499999123456)
    assert parsed_hf['rank_exact']['effective_method'] == 'HF'

    ccsd = """basis=cc-pVQZ-F12
rhf
uccsd-f12b
 PROGRAMS * TOTAL UCCSD RHF-SCF INT
 !RHF-UCCSD-F12b energy                -1.174475123456
 Molpro calculation terminated
"""
    parsed_ccsd = parse_molpro_energy(
        ccsd, method='CCSD(T)-F12b', basis='cc-pVQZ-F12',
        reference='RHF', rank_exact_electrons=2,
        effective_method='CCSD-F12b')
    assert parsed_ccsd['energy_hartree'] == pytest.approx(-1.174475123456)
    assert parsed_ccsd['rank_exact']['effective_method'] == 'CCSD-F12b'
    with pytest.raises(ValueError, match='normal completion'):
        parse_molpro_energy(
            _ONE_ELECTRON_F12_NAN, method='CCSD(T)-F12b',
            basis='cc-pVTZ-F12', reference='ROHF')

    request = {
        'kind': 'molpro_energy', 'file': 'f12.out',
        'method': 'CCSD(T)-F12b', 'basis': 'cc-pVTZ-F12',
        'reference': 'ROHF', 'rank_exact_electrons': 1,
    }
    validate_result_parser(
        request, backend='molpro',
        template='basis=cc-pVTZ-F12\nrhf\nuccsd-f12b\n',
        outputs=['f12.out'])


def test_legacy_molpro_records_remain_reproducible_but_lack_ucc_provenance():
    energy_request = {'kind': 'molpro_energy', 'file': 'f12.out',
                      'method': 'CCSD(T)-F12b', 'basis': 'cc-pVTZ-F12'}
    validate_result_parser(
        energy_request, backend='molpro',
        template='basis=cc-pVTZ-F12\nhf\nccsd(t)-f12,scale_trip=1\n',
        outputs=['f12.out'])
    energy = parse_result(_MOLPRO_LEGACY_F12, energy_request)
    assert energy == {
        'kind': 'molpro_energy', 'method': 'CCSD(T)-F12b',
        'basis': 'cc-pVTZ-F12', 'energy_hartree': -40.454906199189}
    assert 'reference' not in energy
    assert 'correlation' not in energy

    harmonic_request = {'kind': 'molpro_harmonic', 'file': 'harmonic.out',
                        'basis': 'cc-pVTZ'}
    validate_result_parser(
        harmonic_request, backend='molpro',
        template=('basis=cc-pVTZ\nhf\nccsd(t)\n'
                  'frequencies,numerical\n'), outputs=['harmonic.out'])
    harmonic = parse_result(_MOLPRO_LEGACY_HARMONIC, harmonic_request)
    assert harmonic['kind'] == 'molpro_harmonic'
    assert harmonic['method'] == 'CCSD(T)'
    assert 'program_variant' not in harmonic
    assert 'correlation' not in harmonic


def test_legacy_parser_declaration_cannot_claim_modern_settings():
    request = {'kind': 'molpro_energy', 'file': 'sp.out',
               'method': 'CCSD(T)', 'basis': 'cc-pVDZ',
               'core': 'frozen'}
    with pytest.raises(ValueError, match='invalid result_parser'):
        validate_result_parser(
            request, backend='molpro',
            template='basis=cc-pVDZ\nhf\nccsd(t)\n', outputs=['sp.out'])


@pytest.mark.parametrize('old,new,error', [
    ('uccsd(t)-f12b,scale_trip=1', 'uccsd(t)-f12,scale_trip=1',
     'scaled-triples F12'),
    ('Starting UCCSD calculation', 'Starting RCCSD calculation',
     'unrestricted coupled-cluster startup'),
    ('UCCSD-F12b correlation energy', 'RCCSD-F12b correlation energy',
     'F12b unrestricted correlation'),
    ('TOTAL  UCCSD(T)   RHF-SCF', 'TOTAL  RCCSD(T)   RHF-SCF',
     'unrestricted F12 program summary'),
])
def test_molpro_f12b_rejects_ambiguous_or_restricted_execution(old, new,
                                                               error):
    with pytest.raises(ValueError, match=error):
        parse_molpro_energy(_MOLPRO_F12.replace(old, new),
                            method='CCSD(T)-F12b', basis='cc-pVTZ-F12',
                            reference='ROHF')


def test_molpro_open_shell_uses_rhf_uccsd_t_label():
    result = parse_molpro_energy(
        _MOLPRO_OPEN_CCSD_T, method='CCSD(T)', basis='cc-pVDZ',
        reference='ROHF')
    assert result['energy_hartree'] == pytest.approx(-39.812345678901)
    assert result['reference'] == 'ROHF'
    assert result['program_variant'] == 'RHF-UCCSD(T)'
    with pytest.raises(ValueError, match='UHF-UCC engine'):
        parse_molpro_energy(
            _MOLPRO_OPEN_CCSD_T.replace('uccsd(t)',
                                         'uccsd(t),uhf_uccsd=1'),
            method='CCSD(T)', basis='cc-pVDZ', reference='ROHF')


def test_molpro_rejects_false_uccsdt_label_with_zero_triples():
    broken = (_MOLPRO_OPEN_CCSD_T
              .replace('uccsd(t)', 'uccsd(t),uhf_uccsd=1')
              .replace('Triples (T) contribution -0.006123456789',
                       'Triples (T) contribution 0.000000000000')
              .replace('RHF-UCCSD energy -39.806222222112',
                       'RHF-UCCSD energy -39.812345678901'))
    with pytest.raises(ValueError, match='UHF-UCC engine'):
        parse_molpro_energy(broken, method='CCSD(T)', basis='cc-pVDZ',
                            reference='RHF')

    zero_without_forced_flag = broken.replace(',uhf_uccsd=1', '')
    with pytest.raises(ValueError, match='zero perturbative triples'):
        parse_molpro_energy(zero_without_forced_flag, method='CCSD(T)',
                            basis='cc-pVDZ', reference='RHF')


def test_old_forced_ucc_workflow_can_load_but_result_is_rejected():
    request = {'kind': 'molpro_energy', 'file': 'sp.out',
               'method': 'CCSD(T)', 'basis': 'cc-pVDZ',
               'reference': 'RHF'}
    old_template = 'basis=cc-pVDZ\nrhf\nuccsd(t),uhf_uccsd=1\n'
    with pytest.raises(ValueError, match='invalid result_parser'):
        validate_result_parser(
            request, backend='molpro', template=old_template,
            outputs=['sp.out'])
    validate_result_parser(
        request, backend='molpro', template=old_template,
        outputs=['sp.out'], allow_obsolete=True)
    forced = _MOLPRO_OPEN_CCSD_T.replace(
        'uccsd(t)', 'uccsd(t),uhf_uccsd=1')
    with pytest.raises(ValueError, match='UHF-UCC engine'):
        parse_result(forced, request)


def test_old_forced_ucc_harmonic_workflow_can_load_only_as_obsolete():
    request = {'kind': 'molpro_harmonic', 'file': 'harmonic.out',
               'basis': 'cc-pVTZ', 'reference': 'RHF'}
    old_template = (
        'basis=cc-pVTZ\nrhf\nuccsd(t),uhf_uccsd=1\n'
        'frequencies,numerical\n')
    with pytest.raises(ValueError, match='invalid result_parser'):
        validate_result_parser(
            request, backend='molpro', template=old_template,
            outputs=['harmonic.out'])
    validate_result_parser(
        request, backend='molpro', template=old_template,
        outputs=['harmonic.out'], allow_obsolete=True)


def test_molpro_energy_pins_all_electron_and_dkh2_settings():
    result = parse_molpro_energy(
        _MOLPRO_ALL_ELECTRON_DKH, method='CCSD(T)',
        basis='aug-cc-pCVTZ-DK', reference='RHF',
        core='all-electron', relativistic='DKH2')
    assert result['core'] == 'all-electron'
    assert result['relativistic'] == 'DKH2'
    with pytest.raises(ValueError, match='all-electron'):
        parse_molpro_energy(
            _MOLPRO_ALL_ELECTRON_DKH.replace(';core}', '}'),
            method='CCSD(T)', basis='aug-cc-pCVTZ-DK', reference='RHF',
            core='all-electron', relativistic='DKH2')
    with pytest.raises(ValueError, match='DKHO'):
        parse_molpro_energy(
            _MOLPRO_ALL_ELECTRON_DKH.replace('set,dkho=2\n', ''),
            method='CCSD(T)', basis='aug-cc-pCVTZ-DK', reference='RHF',
            core='all-electron', relativistic='DKH2')
    with pytest.raises(ValueError, match='nonrelativistic'):
        parse_molpro_energy(
            _MOLPRO_ALL_ELECTRON_DKH, method='CCSD(T)',
            basis='aug-cc-pCVTZ-DK', reference='RHF',
            core='all-electron', relativistic='none')


def test_molpro_harmonic_ignores_zero_modes_and_crosschecks_zpe():
    result = parse_molpro_harmonic(
        _MOLPRO_HARMONIC, basis='cc-pVTZ', reference='RHF')
    assert len(result['wavenumbers_cm_inverse']) == 9
    assert result['low_modes_cm_inverse'] == [0.0]
    assert result['review_required'] is False
    assert result['wavenumbers_cm_inverse'][0] == 1343.29
    assert result['zpe']['hartree'] == pytest.approx(0.04479801)
    assert result['reference'] == 'RHF'
    with pytest.raises(ValueError, match='restricted HF reference'):
        parse_molpro_harmonic(
            _MOLPRO_HARMONIC.replace('RHF-SCF', 'UHF-SCF'),
            basis='cc-pVTZ', reference='RHF')
    with pytest.raises(ValueError, match='modes disagree'):
        parse_molpro_harmonic(_MOLPRO_HARMONIC.replace('3153.44', '3253.44'),
                              basis='cc-pVTZ')
    with pytest.raises(ValueError, match='imaginary mode for a minimum'):
        parse_molpro_harmonic(_MOLPRO_HARMONIC.replace('1343.29', '1343.29i'),
                              basis='cc-pVTZ')
    with pytest.raises(ValueError, match='imaginary mode for a minimum'):
        parse_molpro_harmonic(_MOLPRO_HARMONIC.replace(
            '1                0.00', '1              -20.00'),
            basis='cc-pVTZ')
    opened = parse_molpro_harmonic(
        _MOLPRO_OPEN_HARMONIC, basis='cc-pVTZ', reference='ROHF')
    assert opened['reference'] == 'ROHF'
    assert opened['program_variant'] == 'RHF-UCCSD(T)'
    with pytest.raises(ValueError, match='UHF-UCC engine'):
        parse_molpro_harmonic(
            _MOLPRO_HARMONIC.replace(
                'uccsd(t)', 'uccsd(t),uhf_uccsd=1'),
            basis='cc-pVTZ', reference='RHF')


def test_molpro_harmonic_accepts_exactly_one_transition_state_mode():
    saddle = _MOLPRO_HARMONIC.replace(
        '1             1343.29', '1              500.00i').replace(
        '0.04479801 [H]     9832.03 [1/CM]      117.62 [KJ/MOL]',
        '0.0417377851 [H]     9160.385 [1/CM]      109.58 [KJ/MOL]')
    parsed = parse_molpro_harmonic(
        saddle, basis='cc-pVTZ', reference='RHF',
        stationary_point='transition_state')
    assert parsed['stationary_point'] == 'transition_state'
    assert parsed['imaginary_wavenumbers_cm_inverse'] == [-500.0]
    assert len(parsed['wavenumbers_cm_inverse']) == 8
    with pytest.raises(ValueError, match='minimum'):
        parse_molpro_harmonic(saddle, basis='cc-pVTZ', reference='RHF')


def test_gaussian_vpt2_named_zpe_and_warnings():
    result = parse_gaussian_vpt2(_GAUSSIAN_VPT2, method='B3LYP',
                                 basis='cc-pVTZ')
    assert result['anharmonic_correction_cm_inverse'] == pytest.approx(-137.32185)
    assert result['optimized_in_job'] is True
    assert result['review_required'] is False
    assert len(result['warnings']) == 1
    assert result['nonblocking_anl_warnings'] == result['warnings']
    assert result['blocking_warnings'] == []
    assert result['warning_policy'] == \
        'native-gaussian-warnings-informational-for-anl-v1'
    assert len(result['anharmonic_fundamentals_cm_inverse']) == 9
    assert result['harmonic_fundamentals_cm_inverse'][0] == pytest.approx(3153.44)
    assert result['anharmonic_fundamentals_cm_inverse'][1] == pytest.approx(3009.34)
    with pytest.raises(ValueError, match='components disagree'):
        parse_gaussian_vpt2(_GAUSSIAN_VPT2.replace('9646.36482', '9600.36482'),
                             method='B3LYP', basis='cc-pVTZ')
    with pytest.raises(ValueError, match='final normal termination'):
        parse_gaussian_vpt2(_GAUSSIAN_VPT2.split(' Normal termination')[0],
                             method='B3LYP', basis='cc-pVTZ')
    with pytest.raises(ValueError, match='route'):
        parse_gaussian_vpt2(_GAUSSIAN_VPT2.replace('B3LYP/cc-pVTZ',
                                                  'B3LYP/cc-pVTZ-F12'),
                             method='B3LYP', basis='cc-pVTZ')
    frequency_only = _GAUSSIAN_VPT2.replace(
        'B3LYP/cc-pVTZ Opt=(Tight,CalcFC)',
        'B2PLYP/cc-pVTZ EmpiricalDispersion=GD3BJ')
    result = parse_gaussian_vpt2(frequency_only, method='B2PLYP',
                                 basis='cc-pVTZ', dispersion='GD3BJ')
    assert result['dispersion'] == 'GD3BJ'
    assert result['optimized_in_job'] is False
    late_dispersion = frequency_only.replace(
        ' EmpiricalDispersion=GD3BJ', '').replace(
            ' Normal termination',
            (' Gaussian archive payload\n' * 700
             + ' EmpiricalDispersion=GD3BJ\n Normal termination'))
    assert late_dispersion.index('EmpiricalDispersion') > 10000
    assert parse_gaussian_vpt2(
        late_dispersion, method='B2PLYP', basis='cc-pVTZ',
        dispersion='GD3BJ')['dispersion'] == 'GD3BJ'
    with pytest.raises(ValueError, match='dispersion'):
        parse_gaussian_vpt2(frequency_only, method='B2PLYP',
                             basis='cc-pVTZ')


def test_gaussian_vpt2_fundamentals_are_an_explicit_mess_handoff():
    clean = _GAUSSIAN_VPT2.replace(
        ' WARNING: Unreliable CUBIC force constant i= 2,j= 1,k= 4\n', '')
    result = parse_gaussian_vpt2(clean, method='B3LYP', basis='cc-pVTZ')
    species = type('Species', (), {
        'reduced_freqs': list(reversed(
            result['harmonic_fundamentals_cm_inverse'])),
        'anl_thermochemistry_frequencies': None,
        'anl_thermochemistry_frequency_source': None,
    })()
    fundamentals = attach_anharmonic_frequencies(species, result)
    assert fundamentals[0] == pytest.approx(1311.24)
    assert fundamentals[-1] == pytest.approx(3010.18)
    source = species.anl_thermochemistry_frequency_source
    assert source['model'] == 'harmonic_plus_vpt2_mode_shifts'
    assert source['method'] == 'B3LYP'
    assert source['mode_map'] == list(range(9, 0, -1))
    # A rotor-projected target can contain fewer modes; the unmatched VPT2
    # mode is omitted rather than serialized alongside the hindered rotor.
    species.reduced_freqs = species.reduced_freqs[1:]
    assert len(attach_anharmonic_frequencies(species, result)) == 8
    species.reduced_freqs = [5000.] * 10
    with pytest.raises(ValueError, match='KinBot needs 10'):
        attach_anharmonic_frequencies(species, result)
    species.reduced_freqs = [5000.] * 9
    with pytest.raises(ValueError, match='mode match exceeds'):
        attach_anharmonic_frequencies(species, result)
    blocked = parse_gaussian_vpt2(
        _GAUSSIAN_VPT2.replace('1311.24', '-1.00'),
        method='B3LYP', basis='cc-pVTZ')
    with pytest.raises(ValueError, match='quality review'):
        attach_anharmonic_frequencies(species, blocked)


def test_gaussian_vpt2_rejects_incomplete_or_flags_nonpositive_fundamentals():
    with pytest.raises(ValueError, match='not consecutive'):
        parse_gaussian_vpt2(_GAUSSIAN_VPT2.replace('    9(1) active',
                                                   '   10(1) active'),
                            method='B3LYP', basis='cc-pVTZ')
    result = parse_gaussian_vpt2(
        _GAUSSIAN_VPT2.replace('1311.24', '-1.00'),
        method='B3LYP', basis='cc-pVTZ')
    assert result['review_required'] is True
    assert 'Nonpositive anharmonic fundamental mode(s): 9' in result['warnings']
    assert result['blocking_warnings'] == [
        'Nonpositive anharmonic fundamental mode(s): 9']
    assert result['nonblocking_anl_warnings'] == [
        'WARNING: Unreliable CUBIC force constant i= 2,j= 1,k= 4']


def test_gaussian_vpt2_warning_policy_migrates_archived_parser_result():
    current = parse_gaussian_vpt2(
        _GAUSSIAN_VPT2, method='B3LYP', basis='cc-pVTZ')
    saved = {key: value for key, value in current.items()
             if key not in ('nonblocking_anl_warnings', 'blocking_warnings',
                            'warning_policy')}
    saved['review_required'] = True
    assert parsed_result_extends(saved, current)

    changed = {**current, 'warnings': ['WARNING: different native warning'],
               'nonblocking_anl_warnings': [
                   'WARNING: different native warning']}
    assert not parsed_result_extends(saved, changed)

    blocked = parse_gaussian_vpt2(
        _GAUSSIAN_VPT2.replace('1311.24', '-1.00'),
        method='B3LYP', basis='cc-pVTZ')
    assert not parsed_result_extends(saved, blocked)


def test_gaussian_linear_mode_labels_keep_degenerate_components():
    linear = (_GAUSSIAN_VPT2
              .replace('    5(1) active', '    5(1,-1) active')
              .replace('    6(1) active', '    5(1,+1) active')
              .replace('    7(1) active', '    6(1,-1) active')
              .replace('    8(1) active', '    6(1,+1) active')
              .replace('    9(1) active', '    7(1) active'))
    result = parse_gaussian_vpt2(linear, method='B3LYP', basis='cc-pVTZ')
    assert result['fundamental_mode_labels'][4:8] == [
        '5(1,-1)', '5(1,+1)', '6(1,-1)', '6(1,+1)']


def test_parser_declaration_must_match_method_and_input():
    request = {'kind': 'molpro_energy', 'file': 'sp.out',
               'method': 'CCSD(T)-F12b', 'basis': 'cc-pVTZ-F12',
               'reference': 'RHF'}
    template = 'basis=cc-pVTZ-F12\nrhf\nuccsd(t)-f12b,scale_trip=1\n'
    validate_result_parser(request, backend='molpro', template=template,
                           outputs=['sp.out'])
    with pytest.raises(ValueError, match='invalid result_parser'):
        validate_result_parser(request, backend='molpro',
                               template=template.replace('scale_trip=1', 'scale_trip=0'),
                               outputs=['sp.out'])
    with pytest.raises(ValueError, match='invalid result_parser'):
        validate_result_parser(request, backend='molpro',
                               template=template.replace('-f12b', '-f12'),
                               outputs=['sp.out'])
