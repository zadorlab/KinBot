"""Native-output components require complete, hash-checked task records."""

import hashlib
import json
from copy import deepcopy
from pathlib import Path
from tempfile import TemporaryDirectory

import pytest
from ase.io import read, write
from ase.units import Hartree, invcm, kJ, mol

from kinbot.anl.dispatch import _geometry_hash, advance, prepare
from kinbot.anl.extrapolation import core_valence_correction
from kinbot.anl.model import (ComponentRequirement, ComponentResult,
                              IncompleteRecipeError)
from kinbot.anl.recipes import recipe
from kinbot.anl.results import parse_result
from kinbot.anl.workflow import (_cbs_components,
                                 attach_task_vpt2_frequencies,
                                 atomic_zero_vibrational_component,
                                 cbs_task_component,
                                 core_valence_task_component,
                                 rank_exact_core_valence_component,
                                 rank_exact_higher_order_correction,
                                 scalar_relativistic_task_component,
                                 task_component)
from tests.anl_fixture import dispatch_spec, molpro_task


_F12 = """basis=cc-pVTZ-F12
rhf
uccsd(t)-f12b,scale_trip=1
 Starting UCCSD calculation
 UCCSD-F12b correlation energy -0.288234238676
 Number of N-1 electron functions: 7
 Triples (T) contribution (scaled) -0.006123456789
 RHF-UCCSD-F12b energy -40.448782742400
 !RHF-UCCSD(T)-F12 energy -40.454906199189
 PROGRAMS * TOTAL UCCSD(T) RHF-SCF INT
 Molpro calculation terminated
"""

_F12_QZ = """basis=cc-pVQZ-F12
rhf
uccsd(t)-f12b,scale_trip=1
 Starting UCCSD calculation
 UCCSD-F12b correlation energy -0.290012345678
 Number of N-1 electron functions: 7
 Triples (T) contribution (scaled) -0.006123456789
 RHF-UCCSD-F12b energy -40.450484849685
 !RHF-UCCSD(T)-F12 energy -40.456608306474
 PROGRAMS * TOTAL UCCSD(T) RHF-SCF INT
 Molpro calculation terminated
"""


def test_atomic_vibrational_terms_are_exact_hash_bound_zeros():
    molecule = {
        'symbols': ['H'], 'positions': [[0., 0., 0.]],
        'charge': 0, 'multiplicity': 2}
    requirements = {item.key: item for item in recipe(
        'ANL0-F12', vpt2_method='B2PLYP-D3BJ',
        multiplicity=2, atomic=True).requirements}
    harmonic = atomic_zero_vibrational_component(
        molecule, requirements['harmonic_zpe'], state_id='H-2S',
        geometry_sha256='1' * 64)
    anharmonic = atomic_zero_vibrational_component(
        molecule, requirements['vpt2_correction'], state_id='H-2S',
        geometry_sha256='2' * 64)
    assert harmonic.value_hartree == anharmonic.value_hartree == 0.
    assert harmonic.backend == anharmonic.backend == 'known_zero'
    assert harmonic.source_sha256 != anharmonic.source_sha256
    with pytest.raises(ValueError, match='one atom'):
        atomic_zero_vibrational_component(
            {**molecule, 'symbols': ['H', 'H']},
            requirements['harmonic_zpe'], state_id='H2',
            geometry_sha256='1' * 64)


@pytest.mark.parametrize('molecule', [
    {'symbols': ['H'], 'positions': [[0., 0., 0.]],
     'charge': 0, 'multiplicity': 2},
    {'symbols': ['H', 'H'], 'positions': [[0., 0., 0.], [0., 0., .74]],
     'charge': 0, 'multiplicity': 1},
])
def test_rank_exact_higher_order_correction_needs_no_qc_result(molecule):
    requirement = next(item for item in recipe(
        'ANL0-F12', multiplicity=molecule['multiplicity'],
        rank_exact_higher_order=True).requirements
        if item.key == 'higher_order_correction')
    component = rank_exact_higher_order_correction(
        molecule, requirement, state_id='rank-exact-state',
        geometry_sha256='3' * 64)
    assert component.value_hartree == 0.
    assert component.backend == 'known_zero'
    assert component.settings['rank_exact']['electron_count'] in (1, 2)
    assert len(component.source_sha256) == 64


def test_rank_exact_higher_order_correction_rejects_three_electrons():
    molecule = {'symbols': ['He', 'H'],
                'positions': [[0., 0., 0.], [0., 0., 1.]],
                'charge': 0, 'multiplicity': 2}
    requirement = next(item for item in recipe(
        'ANL0-F12', multiplicity=2,
        rank_exact_higher_order=True).requirements
        if item.key == 'higher_order_correction')
    with pytest.raises(ValueError, match='at most two electrons'):
        rank_exact_higher_order_correction(
            molecule, requirement, state_id='not-rank-exact',
            geometry_sha256='3' * 64)


def _electronic_component(key, energy, basis, *, core, relativistic='none'):
    return ComponentResult(
        key=key, value_hartree=energy, quantity='electronic',
        method='CCSD(T)', basis=basis, backend='molpro', state_id='state-A',
        charge=0, multiplicity=1, geometry_sha256='1' * 64,
        source_sha256=hashlib.sha256(key.encode()).hexdigest(),
        source=f'{key}.out', settings={
            'reference': 'RHF', 'correlation': 'unrestricted',
            'program_variant': 'RHF-UCCSD(T)', 'core': core,
            'relativistic': relativistic})


def test_common_correction_providers_apply_verified_differences(monkeypatch):
    components = {
        'ae_tz': _electronic_component(
            'ae_tz', -40.10, 'cc-pCVTZ', core='all-electron'),
        'ae_qz': _electronic_component(
            'ae_qz', -40.20, 'cc-pCVQZ', core='all-electron'),
        'fc_tz': _electronic_component(
            'fc_tz', -40.08, 'cc-pCVTZ', core='frozen'),
        'fc_qz': _electronic_component(
            'fc_qz', -40.17, 'cc-pCVQZ', core='frozen'),
        'dkh': _electronic_component(
            'dkh', -40.205, 'aug-cc-pCVTZ-DK', core='all-electron',
            relativistic='DKH2'),
        'nonrel': _electronic_component(
            'nonrel', -40.200, 'aug-cc-pCVTZ-DK', core='all-electron'),
    }
    monkeypatch.setattr(
        'kinbot.anl.workflow.task_component',
        lambda run_dir, task_id, **kwargs: components[task_id])
    requirements = {item.key: item for item in recipe('ANL0-F12').requirements}
    cv = core_valence_task_component(
        'run', all_electron_lower='ae_tz', all_electron_upper='ae_qz',
        frozen_core_lower='fc_tz', frozen_core_upper='fc_qz',
        requirement=requirements['core_valence_cbs'], state_id='state-A')
    assert cv.value_hartree == pytest.approx(core_valence_correction(
        all_electron_lower=-40.10, all_electron_upper=-40.20,
        frozen_core_lower=-40.08, frozen_core_upper=-40.17))
    assert cv.backend == 'composite'
    assert len(cv.source_sha256) == 64
    rel = scalar_relativistic_task_component(
        'run', 'dkh', 'nonrel',
        requirement=requirements['scalar_relativistic'], state_id='state-A')
    assert rel.value_hartree == pytest.approx(-0.005)
    assert rel.backend == 'composite'
    components['nonrel'] = ComponentResult(
        **{**components['nonrel'].__dict__, 'geometry_sha256': '2' * 64})
    with pytest.raises(ValueError, match='different geometry'):
        scalar_relativistic_task_component(
            'run', 'dkh', 'nonrel',
            requirement=requirements['scalar_relativistic'],
            state_id='state-A')


def test_hydrogen_core_valence_is_a_provenance_bound_exact_zero():
    requirement = next(item for item in recipe('ANL0-F12').requirements
                       if item.key == 'core_valence_cbs')
    component = rank_exact_core_valence_component(
        {'symbols': ['H', 'H'], 'charge': 0, 'multiplicity': 1},
        requirement, state_id='hydrogen-X1Sigma-g-plus',
        geometry_sha256='4' * 64)
    assert component.value_hartree == 0.
    assert component.backend == 'known_zero'
    assert component.settings['rank_exact']['atomic_numbers'] == [1, 1]
    with pytest.raises(ValueError, match='H/He'):
        rank_exact_core_valence_component(
            {'symbols': ['C'], 'charge': 0, 'multiplicity': 1},
            requirement, state_id='carbon', geometry_sha256='4' * 64)


def _complete_task(run_dir, task, output):
    task_id = task['id']
    directory = run_dir / 'tasks' / task_id
    output_name = task['result_parser']['file']
    (directory / output_name).write_text(output)
    stdout_name = task.get('stdout', 'stdout.txt')
    stderr_name = task.get('stderr', 'stderr.txt')
    for name in (stdout_name, stderr_name):
        if name != output_name:
            (directory / name).write_text('')
    state_path = run_dir / 'state.json'
    state = json.loads(state_path.read_text())
    state['tasks'][task_id]['status'] = 'complete'
    state_path.write_text(json.dumps(state))
    artifacts = {
        name: hashlib.sha256((directory / name).read_bytes()).hexdigest()
        for name in {'geometry.xyz', 'task.json', task['input_name'],
                     output_name, stdout_name, stderr_name}
    }
    (directory / 'execution.json').write_text(json.dumps({
        'schema': 1, 'task_id': task_id, 'status': 'executed',
        'geometry_sha256': state['tasks'][task_id]['geometry_sha256'],
        'artifacts': artifacts,
        'details': {'parsed_result': parse_result(output, task['result_parser'])},
    }))
    return directory


def _completed_f12(root):
    spec = dispatch_spec()
    geometry = next(task for task in spec['tasks']
                    if task['id'] == 'l3_geometry')
    geometry['geometry_from'] = 'initial'
    task = next(task for task in spec['tasks'] if task['id'] == 'f12_tz')
    task['result_parser']['reference'] = 'RHF'
    spec['tasks'] = [geometry, task]
    spec_file = root / 'spec.json'
    spec_file.write_text(json.dumps(spec))
    run_dir = prepare(spec_file, root / 'run')
    _complete_optimization(run_dir, geometry)
    advance(run_dir, submit=False)
    directory = _complete_task(run_dir, task, _F12)
    return run_dir, directory


def _completed_f12_pair(root, *, split_geometry=False):
    spec = dispatch_spec()
    geometry = next(task for task in spec['tasks']
                    if task['id'] == 'l3_geometry')
    geometry['geometry_from'] = 'initial'
    tasks = [task for task in spec['tasks']
             if task['id'] in ('f12_tz', 'f12_qz')]
    for task in tasks:
        task['result_parser']['reference'] = 'RHF'
    optimizations = [geometry]
    if split_geometry:
        other = deepcopy(geometry)
        other['id'] = 'l3_other'
        tasks[1]['geometry_from'] = other['id']
        optimizations.append(other)
    spec['tasks'] = [*optimizations, *tasks]
    spec_file = root / 'spec.json'
    spec_file.write_text(json.dumps(spec))
    run_dir = prepare(spec_file, root / 'run')
    for optimization in optimizations:
        _complete_optimization(run_dir, optimization)
    advance(run_dir, submit=False)
    for task, output in zip(tasks, (_F12, _F12_QZ)):
        _complete_task(run_dir, task, output)
    return run_dir


def _complete_optimization(run_dir, task, *, move=0.0):
    ident = task['id']
    directory = run_dir / 'tasks' / ident
    atoms = read(directory / 'geometry.xyz')
    atoms.positions[1, 0] += move
    write(directory / 'final.xyz', atoms)
    (directory / 'optimization.log').write_text('Synthetic accepted optimization\n')
    generated = []
    if task['profile']['calculator'] == 'molpro':
        generated = [f'{ident}_step_0001{suffix}'
                     for suffix in ('.inp', '.out', '.log', '.xyz')]
        for name in generated:
            (directory / name).write_text('Synthetic native artifact\n')
    artifact_names = {'geometry.xyz', 'task.json', 'final.xyz',
                      'optimization.log', *generated}
    artifacts = {name: hashlib.sha256((directory / name).read_bytes()).hexdigest()
                 for name in artifact_names}
    geometry_hash = _geometry_hash(atoms)
    (directory / 'execution.json').write_text(json.dumps({
        'schema': 1, 'task_id': ident, 'status': 'executed',
        'geometry_sha256': _geometry_hash(read(directory / 'geometry.xyz')),
        'artifacts': artifacts,
        'details': {'final_geometry_sha256': geometry_hash,
                    'generated_files': generated},
    }))
    state_path = run_dir / 'state.json'
    state = json.loads(state_path.read_text())
    state['tasks'][ident]['status'] = 'complete'
    state['tasks'][ident]['final_geometry_sha256'] = geometry_hash
    state_path.write_text(json.dumps(state))
    return geometry_hash


def _harmonic_output(basis, shift):
    modes = [1343.29, 1343.90, 1344.76, 1570.56, 1570.88,
             3033.49, 3151.55, 3152.19, 3153.44]
    modes = [value + shift for value in modes]
    zpe_cm = sum(modes) / 2
    zpe_hartree = zpe_cm * invcm / Hartree
    zpe_kj = zpe_hartree * Hartree * mol / kJ
    lines = '\n'.join(f' {i} {value:.2f}' for i, value in enumerate(modes, 1))
    return (f'basis={basis}\nrhf\nuccsd(t)\n'
            'PROGRAM * RHF-SCF\n'
            'Number of N-1 electron functions: 7\n'
            'Triples (T) contribution -0.006123456789\n'
            'frequencies,numerical\n'
            'PROGRAM * FREQUENCIES (Calculation of harmonic vibrational '
            'spectra for UCCSD(T))\nVibration Wavenumber\n'
            f'{lines}\n\nZero point energy: {zpe_hartree:.8f} [H] '
            f'{zpe_cm:.2f} [1/CM] {zpe_kj:.2f} [KJ/MOL]\n'
            'Molpro calculation terminated\n')


def _vpt2_output(basis, correction, *, warning=False):
    harmonic = 9800.0
    modes = [3200., 3150., 3100., 3000., 1600., 1550., 1400., 1350., 1250.]
    bands = '\n'.join(
        f'{index}(1) active {value:.3f} {value - 20.:.3f} 1.0 1.0'
        for index, value in enumerate(modes, 1))
    warning_text = ('WARNING: Unreliable CUBIC force constant i=1,j=2,k=3\n'
                    if warning else '')
    return (f'#p B2PLYP/{basis} Freq=Anharmonic '
            'EmpiricalDispersion=GD3BJ\n'
            f'{warning_text}'
            'Fundamental Bands\n'
            'Mode(n) Status E(harm) E(anharm) I(harm) I(anharm)\n'
            f'{bands}\nOvertones\n'
            'Anharmonic Zero Point Energy\n'
            f'Harmonic       : cm-1 = {harmonic:.5f} ;\n'
            f'Anharmonic Pot.: cm-1 = {correction:.5f} ;\n'
            'Watson+Coriolis: cm-1 = 0.00000 ;\n'
            f'Total Anharm   : cm-1 = {harmonic + correction:.5f} ;\n'
            'Normal termination of Gaussian 16\n')


def test_verified_vpt2_task_attaches_partition_function_frequencies():
    with TemporaryDirectory() as temporary:
        run_dir, _, _ = _completed_zpe_pair(Path(temporary), kind='vpt2')
        species = type('Species', (), {
            'reduced_freqs': [1250., 1350., 1400., 1550., 1600.,
                              3000., 3100., 3150., 3200.],
            'anl_thermochemistry_frequencies': None,
            'anl_thermochemistry_frequency_source': None,
        })()
        corrected = attach_task_vpt2_frequencies(
            species, run_dir, 'vpt2_qz')
        assert corrected == pytest.approx(
            [1230., 1330., 1380., 1530., 1580., 2980., 3080., 3130., 3180.])
        source = species.anl_thermochemistry_frequency_source
        assert source['task_id'] == 'vpt2_qz'
        assert len(source['source_sha256']) == 64


def test_native_gaussian_warning_does_not_block_anl_frequency_handoff():
    with TemporaryDirectory() as temporary:
        run_dir, _, _ = _completed_zpe_pair(Path(temporary), kind='vpt2')
        workflow = json.loads((run_dir / 'workflow.json').read_text())
        task = next(item for item in workflow['tasks']
                    if item['id'] == 'vpt2_qz')
        _complete_task(
            run_dir, task,
            _vpt2_output('cc-pVQZ', -80., warning=True))
        # Simulate an archived result from the parser version that treated
        # every native Gaussian warning as a manual-review gate.
        execution_path = run_dir / 'tasks/vpt2_qz/execution.json'
        execution = json.loads(execution_path.read_text())
        archived = execution['details']['parsed_result']
        for key in ('nonblocking_anl_warnings', 'blocking_warnings',
                    'warning_policy'):
            archived.pop(key)
        archived['review_required'] = True
        execution_path.write_text(json.dumps(execution))
        species = type('Species', (), {
            'reduced_freqs': [1250., 1350., 1400., 1550., 1600.,
                              3000., 3100., 3150., 3200.],
            'anl_thermochemistry_frequencies': None,
            'anl_thermochemistry_frequency_source': None,
        })()
        attach_task_vpt2_frequencies(species, run_dir, 'vpt2_qz')
        assert species.anl_thermochemistry_frequencies[-1] == \
            pytest.approx(3180.)


def test_parser_flagged_vpt2_frequency_handoff_stays_blocked():
    with TemporaryDirectory() as temporary:
        run_dir, _, _ = _completed_zpe_pair(Path(temporary), kind='vpt2')
        workflow = json.loads((run_dir / 'workflow.json').read_text())
        task = next(item for item in workflow['tasks']
                    if item['id'] == 'vpt2_qz')
        output = _vpt2_output('cc-pVQZ', -80., warning=True).replace(
            '1250.000 1230.000', '1250.000 -1.000')
        _complete_task(run_dir, task, output)
        species = type('Species', (), {
            'reduced_freqs': [1250., 1350., 1400., 1550., 1600.,
                              3000., 3100., 3150., 3200.],
            'anl_thermochemistry_frequencies': None,
            'anl_thermochemistry_frequency_source': None,
        })()
        with pytest.raises(ValueError, match='explicit quality review'):
            attach_task_vpt2_frequencies(species, run_dir, 'vpt2_qz')


def _completed_zpe_pair(root, *, kind):
    spec = dispatch_spec()
    is_harmonic = kind == 'harmonic'
    source = next(task for task in spec['tasks'] if task['id'] == (
        'l3_geometry' if is_harmonic else 'l2_geometry'))
    optimizations, evaluations = [], []
    for suffix, basis in (('tz', 'cc-pVTZ'), ('qz', 'cc-pVQZ')):
        opt = deepcopy(source)
        opt['id'] = f'geom_{suffix}'
        opt['geometry_from'] = 'initial'
        opt['profile']['basis'] = basis
        optimizations.append(opt)
        if is_harmonic:
            task = molpro_task(
                f'freq_{suffix}',
                f'basis={basis}\nrhf\nuccsd(t)\n'
                'frequencies,numerical\n',
                geometry_from=opt['id'],
                result_parser={'kind': 'molpro_harmonic', 'basis': basis,
                               'reference': 'RHF'})
        else:
            task = deepcopy(next(item for item in spec['tasks']
                                 if item['id'] == 'gaussian_vpt2'))
            task['id'] = f'vpt2_{suffix}'
            task['geometry_from'] = opt['id']
            task['depends_on'] = []
            task['input_name'] = f"{task['id']}.com"
            task['stdin'] = task['input_name']
            task['stdout'] = f"{task['id']}.log"
            task['stderr'] = f"{task['id']}.err"
            task['required_outputs'] = [task['stdout']]
            task['success_marker']['file'] = task['stdout']
            task['result_parser']['file'] = task['stdout']
            task['result_parser']['basis'] = basis
            task['input_template'] = task['input_template'].replace(
                'B2PLYP/cc-pVTZ', f'B2PLYP/{basis}')
        evaluations.append(task)
    spec['tasks'] = optimizations + evaluations
    spec_file = root / 'spec.json'
    spec_file.write_text(json.dumps(spec))
    run_dir = prepare(spec_file, root / 'run')
    lower_geometry = _complete_optimization(run_dir, optimizations[0])
    upper_geometry = _complete_optimization(run_dir, optimizations[1], move=0.01)
    advance(run_dir, submit=False)
    for index, task in enumerate(evaluations):
        basis = ('cc-pVTZ', 'cc-pVQZ')[index]
        output = (_harmonic_output(basis, index)
                  if is_harmonic else _vpt2_output(basis, -137.0 + index))
        _complete_task(run_dir, task, output)
    return run_dir, lower_geometry, upper_geometry


def test_read_completed_f12_component_reparses_and_checks_artifacts():
    with TemporaryDirectory() as temporary:
        run_dir, directory = _completed_f12(Path(temporary))
        result = task_component(run_dir, 'f12_tz', key='f12_tz',
                                state_id='state-A')
        assert result.value_hartree == pytest.approx(-40.454906199189)
        assert result.method == 'CCSD(T)-F12b'
        assert result.settings['scale_trip'] == 1
        assert result.source_sha256 == hashlib.sha256(
            (directory / 'f12_tz.out').read_bytes()).hexdigest()

        # Parser upgrades may add derived metadata without invalidating the
        # immutable native calculation or its older execution record.
        execution_path = directory / 'execution.json'
        execution = json.loads(execution_path.read_text())
        execution['details']['parsed_result'].pop('program_variant')
        execution_path.write_text(json.dumps(execution))
        upgraded = task_component(run_dir, 'f12_tz', key='f12_tz',
                                  state_id='state-A')
        assert upgraded.settings['program_variant'] == 'RHF-UCCSD(T)-F12b'

        execution = json.loads(execution_path.read_text())
        execution['details']['parsed_result']['energy_hartree'] += 0.001
        execution_path.write_text(json.dumps(execution))
        with pytest.raises(ValueError, match='differs from native'):
            task_component(run_dir, 'f12_tz', key='f12_tz',
                           state_id='state-A')

        execution['details']['parsed_result']['energy_hartree'] -= 0.001
        execution_path.write_text(json.dumps(execution))

        (directory / 'f12_tz.out').write_text(_F12.replace('-40.454906199189',
                                                          '-40.454000000000'))
        with pytest.raises(RuntimeError, match='artifact'):
            task_component(run_dir, 'f12_tz', key='f12_tz',
                           state_id='state-A')


def test_old_unparsed_dispatch_result_cannot_enter_recipe():
    with TemporaryDirectory() as temporary:
        run_dir, directory = _completed_f12(Path(temporary))
        execution_path = directory / 'execution.json'
        execution = json.loads(execution_path.read_text())
        del execution['details']['parsed_result']
        execution_path.write_text(json.dumps(execution))
        with pytest.raises(ValueError, match='differs from native'):
            task_component(run_dir, 'f12_tz', key='reference_cbs',
                           state_id='state-A')
        state_path = run_dir / 'state.json'
        state = json.loads(state_path.read_text())
        state['tasks']['f12_tz']['status'] = 'submitted'
        state_path.write_text(json.dumps(state))
        with pytest.raises(IncompleteRecipeError, match='not complete'):
            task_component(run_dir, 'f12_tz', key='reference_cbs',
                           state_id='state-A')


def test_verified_f12_task_pair_builds_recipe_cbs_component():
    with TemporaryDirectory() as temporary:
        run_dir = _completed_f12_pair(Path(temporary))
        parent = next(item for item in recipe('ANL0-F12').requirements
                      if item.key == 'reference_cbs')
        requirement = ComponentRequirement(
            'reference_cbs', 'electronic', 'CCSD(T)-F12b',
            'CBS(cc-pVTZ-F12,cc-pVQZ-F12)', 'l3', ('composite',),
            {'scale_trip': 1, 'correlation': 'unrestricted',
             'reference': 'RHF',
             'reference_convention': 'RHF/ROHF-UCC',
             'upper_cardinal': 4,
             'extrapolation_power':
                 parent.settings['f12_extrapolation_power'],
             'geometry_method': 'CCSD(T)',
             'geometry_basis': 'cc-pVTZ'})
        kwargs = {'requirement': requirement, 'state_id': 'state-A',
                  'lower_basis': 'cc-pVTZ-F12',
                  'upper_basis': 'cc-pVQZ-F12'}
        result = cbs_task_component(run_dir, 'f12_tz', 'f12_qz', **kwargs)
        assert result.value_hartree == pytest.approx(-40.457504545051066)
        assert result.backend == 'composite'
        assert result.basis == 'CBS(cc-pVTZ-F12,cc-pVQZ-F12)'
        assert result.settings['scale_trip'] == 1
        assert result.settings['upper_cardinal'] == 4
        assert len(result.source_sha256) == 64

        with pytest.raises(ValueError, match='basis order'):
            cbs_task_component(run_dir, 'f12_qz', 'f12_tz', **kwargs)
        with pytest.raises(ValueError, match='distinct'):
            cbs_task_component(run_dir, 'f12_tz', 'f12_tz', **kwargs)
        with pytest.raises(ValueError, match='basis pair'):
            cbs_task_component(run_dir, 'f12_tz', 'f12_qz',
                               **{**kwargs, 'upper_basis': 'cc-pV5Z-F12'})
        harmonic = next(item for item in recipe('ANL1').requirements
                        if item.key == 'harmonic_zpe')
        with pytest.raises(ValueError, match='geometry level'):
            cbs_task_component(run_dir, 'f12_tz', 'f12_qz',
                               **{**kwargs, 'requirement': harmonic})


def test_one_electron_f12_cbs_ignores_only_legacy_rank_recovery_metadata():
    parent = next(item for item in recipe(
        'ANL0-F12', multiplicity=2).requirements
                  if item.key == 'reference_cbs')
    requirement = ComponentRequirement(
        'reference_cbs', 'electronic', 'CCSD(T)-F12b',
        'CBS(cc-pVTZ-F12,cc-pVQZ-F12)', 'l3', ('composite',),
        {'scale_trip': 1, 'correlation': 'unrestricted',
         'reference': 'ROHF', 'reference_convention': 'RHF/ROHF-UCC',
         'upper_cardinal': 4,
         'extrapolation_power': parent.settings['f12_extrapolation_power'],
         'geometry_method': 'CCSD(T)', 'geometry_basis': 'cc-pVTZ'})
    geometry = '1' * 64
    common = {
        'reference': 'ROHF',
        'program_variant': 'RHF-UCCSD(T)-F12b',
        'correlation': 'unrestricted',
        'reference_convention': 'RHF/ROHF-UCC',
        'scale_trip': 1,
    }

    def component(key, basis, value, settings, source_hash):
        return ComponentResult(
            key=key, value_hartree=value, quantity='electronic',
            method='CCSD(T)-F12b', basis=basis, backend='molpro',
            state_id='hydrogen-2S-one-half', charge=0, multiplicity=2,
            geometry_sha256=geometry, source_sha256=source_hash,
            source=f'{key}.out', settings=settings)

    lower = component(
        'f12_tz', 'cc-pVTZ-F12', -0.49999,
        {**common, 'effective_program_variant': 'RHF-UCCSD-F12b',
         'rank_exact': {
             'electron_count': 1,
             'triples_scaling_bypassed': True,
             'recovered_molpro_scale_trip_nan': True,
         }}, '2' * 64)
    upper = component(
        'f12_qz', 'cc-pVQZ-F12', -0.5, common, '3' * 64)
    geometry_sources = (
        {'task_id': 'l3_geometry', 'geometry_sha256': geometry},
        {'task_id': 'l3_geometry', 'geometry_sha256': geometry},
    )
    result = _cbs_components(
        lower, upper, requirement=requirement,
        lower_basis='cc-pVTZ-F12', upper_basis='cc-pVQZ-F12',
        geometry_sources=geometry_sources, electron_count=1)
    assert result.backend == 'composite'
    assert result.settings['scale_trip'] == 1

    with pytest.raises(ValueError, match='settings differ'):
        _cbs_components(
            lower, upper, requirement=requirement,
            lower_basis='cc-pVTZ-F12', upper_basis='cc-pVQZ-F12',
            geometry_sources=geometry_sources, electron_count=7)

    incompatible = component(
        'f12_qz', 'cc-pVQZ-F12', -0.5,
        {**common, 'effective_program_variant': 'RHF'}, '4' * 64)
    with pytest.raises(ValueError, match='settings differ'):
        _cbs_components(
            lower, incompatible, requirement=requirement,
            lower_basis='cc-pVTZ-F12', upper_basis='cc-pVQZ-F12',
            geometry_sources=geometry_sources, electron_count=1)


def test_conventional_anl0_cbs_pins_native_full_augmented_pair():
    requirement = next(item for item in recipe('ANL0').requirements
                       if item.key == 'reference_cbs')
    lower_basis, upper_basis = requirement.settings['native_basis_pair']
    geometry = '5' * 64
    settings = {
        'reference': 'RHF', 'correlation': 'unrestricted',
        'reference_convention': 'RHF/ROHF-UCC',
        'program_variant': 'RHF-UCCSD(T)',
    }

    def component(key, basis, value, digest):
        return ComponentResult(
            key=key, value_hartree=value, quantity='electronic',
            method='CCSD(T)', basis=basis, backend='molpro',
            state_id='state-A', charge=0, multiplicity=1,
            geometry_sha256=geometry, source_sha256=digest,
            source=f'{key}.out', settings=settings)

    sources = (
        {'task_id': 'l3_geometry', 'geometry_sha256': geometry},
        {'task_id': 'l3_geometry', 'geometry_sha256': geometry},
    )
    result = _cbs_components(
        component('anl0_qz', lower_basis, -40.0, '6' * 64),
        component('anl0_5z', upper_basis, -40.1, '7' * 64),
        requirement=requirement, lower_basis=lower_basis,
        upper_basis=upper_basis, geometry_sources=sources,
        electron_count=10)
    assert result.basis == 'CBS(aug-QZ,aug-5Z)//cc-pVTZ'
    assert result.settings['native_basis_pair'] == (
        lower_basis, upper_basis)


def test_cbs_pair_rejects_incomplete_or_changed_native_output():
    with TemporaryDirectory() as temporary:
        run_dir = _completed_f12_pair(Path(temporary))
        requirement = next(item for item in recipe('ANL0-F12').requirements
                           if item.key == 'reference_cbs')
        kwargs = {'requirement': requirement, 'state_id': 'state-A',
                  'lower_basis': 'cc-pVTZ-F12',
                  'upper_basis': 'cc-pVQZ-F12'}
        state_path = run_dir / 'state.json'
        state = json.loads(state_path.read_text())
        state['tasks']['f12_qz']['status'] = 'submitted'
        state_path.write_text(json.dumps(state))
        with pytest.raises(IncompleteRecipeError, match='not complete'):
            cbs_task_component(run_dir, 'f12_tz', 'f12_qz', **kwargs)
        state['tasks']['f12_qz']['status'] = 'complete'
        state_path.write_text(json.dumps(state))
        output = run_dir / 'tasks' / 'f12_qz' / 'f12_qz.out'
        output.write_text(output.read_text().replace('-40.456608306474',
                                                    '-40.456000000000'))
        with pytest.raises(RuntimeError, match='artifact'):
            cbs_task_component(run_dir, 'f12_tz', 'f12_qz', **kwargs)


def test_electronic_cbs_rejects_distinct_optimizers_even_at_same_coordinates():
    with TemporaryDirectory() as temporary:
        run_dir = _completed_f12_pair(Path(temporary), split_geometry=True)
        requirement = next(item for item in recipe('ANL0-F12').requirements
                           if item.key == 'reference_cbs')
        with pytest.raises(ValueError, match='different geometry sources'):
            cbs_task_component(
                run_dir, 'f12_tz', 'f12_qz', requirement=requirement,
                state_id='state-A', lower_basis='cc-pVTZ-F12',
                upper_basis='cc-pVQZ-F12')


def test_harmonic_cbs_accepts_two_verified_basis_optimized_geometries():
    with TemporaryDirectory() as temporary:
        run_dir, lower_geometry, upper_geometry = _completed_zpe_pair(
            Path(temporary), kind='harmonic')
        assert lower_geometry != upper_geometry
        requirement = next(item for item in recipe('ANL1').requirements
                           if item.key == 'harmonic_zpe')
        result = cbs_task_component(
            run_dir, 'freq_tz', 'freq_qz', requirement=requirement,
            state_id='state-A', lower_basis='cc-pVTZ',
            upper_basis='cc-pVQZ')
        lower = task_component(run_dir, 'freq_tz', key='freq_tz',
                               state_id='state-A')
        upper = task_component(run_dir, 'freq_qz', key='freq_qz',
                               state_id='state-A')
        assert result.value_hartree == pytest.approx(
            upper.value_hartree + 0.5265464668174269 *
            (upper.value_hartree - lower.value_hartree))
        assert result.quantity == 'zpe'
        assert result.geometry_sha256 == upper_geometry
        assert result.settings['geometry_mode'] == 'basis_optimized'
        assert result.value_hartree > 0

        final = run_dir / 'tasks' / 'geom_tz' / 'final.xyz'
        final.write_text(final.read_text() + '\n')
        with pytest.raises(RuntimeError, match='artifact'):
            cbs_task_component(run_dir, 'freq_tz', 'freq_qz',
                               requirement=requirement, state_id='state-A',
                               lower_basis='cc-pVTZ', upper_basis='cc-pVQZ')


def test_profiled_vpt2_cbs_accepts_two_matching_gaussian_geometries():
    with TemporaryDirectory() as temporary:
        run_dir, lower_geometry, upper_geometry = _completed_zpe_pair(
            Path(temporary), kind='vpt2')
        assert lower_geometry != upper_geometry
        equation = recipe('ANL1', vpt2_method='B2PLYP-D3BJ', vpt2_cbs=True)
        assert equation.name == 'profiled:ANL1:B2PLYP-D3BJ:VPT2-CBS'
        requirement = next(item for item in equation.requirements
                           if item.key == 'vpt2_correction')
        result = cbs_task_component(
            run_dir, 'vpt2_tz', 'vpt2_qz', requirement=requirement,
            state_id='state-A', lower_basis='cc-pVTZ',
            upper_basis='cc-pVQZ')
        expected_cm = -136.0 + 0.5265464668174269
        assert result.value_hartree == pytest.approx(expected_cm * invcm / Hartree)
        assert result.quantity == 'correction'
        assert result.geometry_sha256 == upper_geometry
        assert result.settings['dispersion'] == 'GD3BJ'
