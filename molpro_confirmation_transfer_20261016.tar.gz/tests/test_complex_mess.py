"""Direct/PES complex selection and saddle-free dissociation output."""
import copy
from dataclasses import replace
import hashlib
import itertools
import json
import logging
import os
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import numpy as np
from ase.build import molecule
from kinbot import constants, pes, symmetry
from kinbot.mess import MESS, apply_conformer_shifts
from kinbot.conformer_counting import representative_record
from test_mess_conformers import values
from kinbot.parameters import Parameters
from kinbot.stationary_pt import StationaryPoint
from kinbot.species_routing import routing_name
from kinbot.product_complex import reassess_product_complex
from kinbot.stereo_identity import canonical_identity


def species(formula, mult=1):
    atoms = molecule(formula)
    p = StationaryPoint(formula, 0, mult, atom=atoms.get_chemical_symbols(), geom=atoms.positions)
    p.characterize()
    p.name = routing_name(p)
    symmetry.calculate_symmetry(p)
    p.energy, p.zpe = -40., .01
    p.freq = p.reduced_freqs = [1000.] * max(0, 3*p.natom - (5 if p.natom == 2 else 6))
    return p


class TestComplexMESS(unittest.TestCase):
    def setUp(self):
        tmp = TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        self.addCleanup(os.chdir, Path.cwd())
        os.chdir(tmp.name)
        Path('me').mkdir()
        Path('input.json').write_text(json.dumps(dict(barrier_threshold=100.,
            high_level=0, rotor_scan=0, multi_conf_tst=0, conformer_search=0,
            me=0, uq=0, epsilon=100., sigma=3., queuing='local')))
        self.par = Parameters('input.json', show_warnings=False).par

    def reactions(self, homolysis=False):
        parent = species('CH4')
        products = [species('CH3', 2), species('H', 2)]
        products[0].energy, products[1].energy = -39., -1.
        reactions = []
        for name, barrier, depth in [('high', 35., -1.), ('low', 25., -1.01)]:
            ts = copy.deepcopy(parent)
            ts.name = name
            ts.energy += barrier/constants.AUtoKCAL
            ts.wellorts = 1
            ts.optical_reference = canonical_identity(parent)
            ts.stereopath_id = 'ordinary'
            ts.stereopath_metadata = {'schema': 'kinbot.stereopath.v1', 'id': 'ordinary'}
            ts.freq = ts.reduced_freqs = [-1000.] + [1000.] * 8
            complex_species = copy.deepcopy(parent)
            complex_species.name = name + '_IRC_F_prod'
            # A loose CH3/H arrangement, with a graph distinct from methane.
            complex_species.geom[1] = [3., 0., 0.]
            complex_species.characterize()
            symmetry.calculate_symmetry(complex_species)
            complex_species.energy += depth/constants.AUtoKCAL
            reactions.append(SimpleNamespace(instance_name=name, ts=ts,
                products=products, prod_opt=[SimpleNamespace(species=p) for p in products],
                do_vdW=not homolysis, mp2=0, irc_prod=complex_species,
                irc_prod_opt=SimpleNamespace(species=complex_species)))
        if homolysis:
            reactions = reactions[:1]
            reactions[0].instance_name = 'test_hom_sci'
            reactions[0].ts = copy.deepcopy(parent)
        parent.reac_obj = reactions
        parent.reac_ts_done = [-1] * len(reactions)
        parent.reac_type = ['hom_sci' if homolysis else 'test'] * len(reactions)
        return parent, reactions

    def test_direct_selects_lowest_ordinary_barrier_without_complex(self):
        parent, reactions = self.reactions()
        for order in (reactions, reactions[::-1]):
            parent.reac_obj = order
            writer = MESS(dict(self.par, me_skip_vdW=1), parent)
            writer.write_input(None)
            output = Path('me/mess_0000.inp').read_text()
            self.assertNotIn(' high\n', output)
            self.assertNotIn('{wellname}', output)
            headers = [line.split('!')[0].split() for line in output.splitlines()
                       if line.strip().startswith('Barrier ')]
            low = writer.ts_names['low']
            self.assertEqual(len(headers), 1)
            self.assertEqual(headers[0][:3], ['Barrier', low, 'w_1'])
            self.assertTrue(headers[0][3].startswith('b_'))
            self.assertEqual(sum(l.strip().startswith('Well ') for l in output.splitlines()), 1)
            self.assertNotIn('Core PhaseSpaceTheory', output)
            self.assertEqual(values(output, 'WellDepth'), [25., 26.01])
            self.assertTrue(all(r.do_vdW for r in reactions))
            self.assertNotIn('high_IRC_F_prod', output)

    def test_final_unbound_complex_is_omitted_without_losing_inner_saddle(self):
        parent, reactions = self.reactions()
        separated = sum(p.energy + p.zpe for p in reactions[0].products)
        saved = []
        for reaction in reactions:
            p = reaction.irc_prod_opt.species
            p.energy = separated - p.zpe + .02/constants.AUtoKCAL
            reaction.vdW_depth = 3.04  # initial-well comparison, now obsolete
            saved.append(p.geom.copy())
            reassess_product_complex(reaction, self.par)
        writer = MESS(self.par, parent)
        writer.write_input(None)
        text = Path('me/mess_0000.inp').read_text()
        self.assertEqual(sum(l.strip().startswith('Well ') for l in text.splitlines()), 1)
        self.assertEqual(sum(l.strip().startswith('Barrier ') for l in text.splitlines()), 1)
        self.assertNotIn('Core PhaseSpaceTheory', text)
        self.assertIn(' low\n', text)
        for reaction, geom in zip(reactions, saved):
            self.assertFalse(reaction.do_vdW)
            self.assertAlmostEqual(reaction.vdW_depth, -.02)
            np.testing.assert_array_equal(reaction.irc_prod_opt.species.geom, geom)

    def test_final_complex_check_uses_retained_mc_ground_not_selected_parent(self):
        parent, reactions = self.reactions()
        r = reactions[0]
        r.irc_prod_opt.species.energy = (sum(p.energy+p.zpe for p in r.products)
            - r.irc_prod_opt.species.zpe - 1./constants.AUtoKCAL)
        fragment = r.products[0]
        reference = representative_record(fragment)
        lower = replace(reference, index=2,
                        zero_energy_hartree=reference.zero_energy_hartree-4/constants.AUtoKCAL)
        fragment.conformer_index = [2]
        fragment.conformer_geom = [lower.geometry]
        fragment.conformer_zeroenergy = [lower.zero_energy_hartree]
        fragment.conformer_freq = [lower.frequencies_cm1]
        fragment.conformer_inventory = (lower,)
        fragment.conformer_records = {2: lower}
        reassess_product_complex(r, dict(self.par, multi_conf_tst=1))
        self.assertFalse(r.do_vdW)
        expected = (lower.zero_energy_hartree + r.products[1].energy + r.products[1].zpe
                    - r.irc_prod_opt.species.energy - r.irc_prod_opt.species.zpe)*constants.AUtoKCAL
        self.assertAlmostEqual(r.vdW_depth, expected)

    def test_bound_complex_with_large_imaginary_mode_keeps_direct_saddle(self):
        parent, reactions = self.reactions()
        reference = parent.energy + parent.zpe
        products = reactions[0].products
        products[0].energy += (reference + 43.19/constants.AUtoKCAL
                              - sum(p.energy + p.zpe for p in products))
        saved = []
        for reaction, barrier in zip(reactions, (52.01, 42.01)):
            point = reaction.irc_prod_opt.species
            point.energy = reference + 31.93/constants.AUtoKCAL - point.zpe
            point.freq = [-71.0308, -10.5093] + [1000.] * 7
            point.reduced_freqs = [-71.0308, 10.5093] + [1000.] * 7
            reaction.ts.energy = reference + barrier/constants.AUtoKCAL - reaction.ts.zpe
            saved.append((point, point.geom.copy(), list(point.freq), reaction.ts))
        writer = MESS(self.par, parent)
        with self.assertLogs('KinBot', level='WARNING') as logs:
            for reaction in reactions:
                reassess_product_complex(reaction, self.par)
            writer.write_input(None)
        output = Path('me/mess_0000.inp').read_text()
        headers = [line.split('!')[0].split() for line in output.splitlines()
                   if line.strip().startswith('Barrier ')]
        self.assertEqual(len(headers), 1)
        self.assertEqual(headers[0][1:3], [writer.ts_names['low'], 'w_1'])
        self.assertTrue(headers[0][3].startswith('b_'))
        self.assertEqual(sum(l.strip().startswith('Well ') for l in output.splitlines()), 1)
        self.assertNotIn('Core PhaseSpaceTheory', output)
        self.assertNotIn('Tunneling   Eckart', output)
        self.assertIn('barrier is submerged', output)
        self.assertIn('-71.0308', '\n'.join(logs.output))
        for reaction, (point, geom, raw, ts) in zip(reactions, saved):
            self.assertFalse(reaction.do_vdW)
            self.assertFalse(reaction.final_vdW_assessment['retained'])
            self.assertAlmostEqual(reaction.vdW_depth, 11.26)
            self.assertIs(reaction.irc_prod_opt.species, point)
            self.assertIs(reaction.ts, ts)
            self.assertEqual(point.freq, raw)
            np.testing.assert_array_equal(point.geom, geom)
        self.assertEqual(parent.reac_ts_done, [-1, -1])

    def test_complex_frequency_check_uses_existing_configured_tolerance(self):
        for mode, threshold, retained in ((100., 50., True), (-10.5, 50., True),
                                         (-50., 50., True), (-71., 50., False),
                                         (-71., 80., True)):
            with self.subTest(mode=mode, threshold=threshold):
                _, reactions = self.reactions()
                reaction = reactions[0]
                point = reaction.irc_prod_opt.species
                point.freq = [mode] + [1000.] * 8
                raw = list(point.freq)
                reassess_product_complex(reaction, dict(self.par, imagfreq_threshold=threshold))
                self.assertEqual(reaction.do_vdW, retained)
                self.assertEqual(point.freq, raw)

    def test_distinct_stereopaths_keep_ts_properties_and_share_selected_complex(self):
        from kinbot.mess_mirrors import population_keys
        for skip, mixed, reverse in itertools.product((0, 1), repeat=3):
            with self.subTest(skip=skip, mixed=mixed, reverse=reverse):
                parent, reactions = self.reactions()
                selected_complex = reactions[1].irc_prod_opt.species
                if mixed:
                    reactions[0].do_vdW = False
                parent.reac_obj = reactions[::-1] if reverse else reactions
                par = dict(self.par, multi_conf_tst=1, me_skip_vdW=skip)
                with patch('kinbot.mess.reaction_path_id', side_effect=lambda r: r.instance_name):
                    writer = MESS(par, parent)
                    writer.write_input(None)
                text = Path('me/mess_0000.inp').read_text()
                summed = skip or not mixed
                self.assertEqual('Union ! 2 stereochemical pathways' in text, bool(summed))
                self.assertEqual(sum(line.strip().startswith('Well ') for line in text.splitlines()),
                                 1 if skip else 2)
                self.assertEqual(sum(line.strip().startswith('Barrier ') for line in text.splitlines()),
                                 1 if skip else 2 if summed else 3)
                self.assertEqual(text.count('Core PhaseSpaceTheory'), 0 if skip else 1)
                self.assertEqual(values(text, 'ImaginaryFrequency'), [1000., 1000.])
                high_depth = (35. - (sum(p.energy+p.zpe for p in reactions[0].products)
                              - parent.energy-parent.zpe)*constants.AUtoKCAL) if mixed else 36.01
                depths = values(text, 'WellDepth')
                self.assertEqual(sorted(zip(depths[::2], depths[1::2])),
                                 [(25., 26.01), (35., round(high_depth, 2))])
                high = reactions[0].ts.mess_tunneling_reference
                self.assertAlmostEqual(high['input_depths_kcal_mol'][1], high_depth)
                if not mixed:
                    self.assertAlmostEqual(high['right_parent_observations'][0]['electronic_energy_hartree'],
                                           selected_complex.energy)
                keys = population_keys(reactions[0].products if skip else [selected_complex])
                self.assertIn(' '.join(keys), text)
                self.assertEqual([reaction.do_vdW for reaction in reactions], [not mixed, True])

    def test_unmodeled_complex_optics_cannot_block_direct_output(self):
        for mc in (0, 1):
            parent, reactions = self.reactions()
            complexes = [r.irc_prod_opt.species for r in reactions]
            writer = MESS(dict(self.par, multi_conf_tst=mc, me_skip_vdW=1), parent)
            original = writer._parent_symmetry
            def checked(point, **kwargs):
                self.assertTrue(all(point is not p for p in complexes))
                return original(point, **kwargs)
            from kinbot.mess import writer_members as members
            def checked_members(point, *args, **kwargs):
                self.assertTrue(all(point is not p for p in complexes))
                return members(point, *args, **kwargs)
            with patch.object(writer, '_parent_symmetry', side_effect=checked), \
                    patch('kinbot.mess.writer_members', side_effect=checked_members):
                writer.write_input(None)
            self.assertTrue(all(r.do_vdW for r in reactions))

    def test_submerged_refined_ts_keeps_calculated_energies_without_complex_well(self):
        for mc in (0, 1):
            parent, reactions = self.reactions()
            reference = parent.energy + parent.zpe
            products = reactions[0].products
            products[0].energy += (reference + 60.11/constants.AUtoKCAL
                                  - sum(p.energy+p.zpe for p in products))
            for reaction, barrier in zip(reactions, (61.042, 57.340)):
                reaction.ts.energy = reference + barrier/constants.AUtoKCAL - reaction.ts.zpe
                point = reaction.irc_prod_opt.species
                point.energy = reference + 59.577/constants.AUtoKCAL - point.zpe
            writer = MESS(dict(self.par, multi_conf_tst=mc, me_skip_vdW=1), parent)
            writer.write_input(None)
            text = Path('me/mess_0000.inp').read_text()
            # MC fragment RRHO blocks also carry a relative zero energy.
            self.assertEqual(values(text, 'ZeroEnergy')[-1], 57.34)
            self.assertTrue(all(value == 0. for value in values(text, 'ZeroEnergy')[:-1]))
            self.assertEqual(values(text, 'GroundEnergy'), [60.11])
            self.assertNotIn('Tunneling   Eckart', text)
            self.assertNotIn('Core PhaseSpaceTheory', text)
            self.assertNotIn('59.58', text)
            self.assertTrue(all(r.do_vdW for r in reactions))

    def test_pes_workers_still_write_complex_and_phase_space_models(self):
        from kinbot.mess_mirrors import population_keys
        from kinbot.species_routing import mess_filename
        for mc in (0, 1):
            parent, reactions = self.reactions()
            writer = MESS(dict(self.par, pes=1, multi_conf_tst=mc), parent)
            with patch('kinbot.mess.reaction_path_id', side_effect=lambda r: r.instance_name):
                writer.write_input(None)
            for reaction in reactions:
                name = reaction.irc_prod_opt.species.name
                complex_text = Path(name + '_0000.mess').read_text()
                self.assertRegex(complex_text, r'Well\s+\{name\}')
                self.assertIn('ZeroEnergy[kcal/mol]', complex_text)
                barrier = Path(reaction.instance_name + '_0000.mess').read_text()
                self.assertIn(' '.join(population_keys([reaction.irc_prod_opt.species])), barrier)
            key = '_'.join(sorted(routing_name(p) for p in reactions[0].products))
            text = Path(mess_filename(key, 0)).read_text()
            self.assertIn('Core PhaseSpaceTheory', text)
            self.assertIn('{wellname}', text)
            self.assertIn('{prodname}', text)

    def test_vdw_option_changes_network_not_inner_tunneling_in_direct_and_pes(self):
        from kinbot.mess_mirrors import population_keys
        from kinbot.mess_networks import _HEADER, split_model

        self.assertEqual(self.par['me_skip_vdW'], 0)
        root = Path.cwd()
        for mc in (0, 1):
            parent, reactions = self.reactions()
            reaction = reactions[1]
            parent.reac_obj = [reaction]
            parent.reac_ts_done = [-1]
            parent.reac_type = ['test']
            reference = parent.energy + parent.zpe
            complex_species = reaction.irc_prod_opt.species
            # These assigned energies test serialization, not methane chemistry.
            complex_species.energy = reference + 20./constants.AUtoKCAL - complex_species.zpe
            reaction.ts.energy = reference + 25./constants.AUtoKCAL - reaction.ts.zpe
            reaction.products[0].energy += (
                reference + 30./constants.AUtoKCAL
                - sum(p.energy + p.zpe for p in reaction.products))
            if mc:
                selected = representative_record(complex_species)
                lower = replace(selected, index=2,
                    zero_energy_hartree=selected.zero_energy_hartree-1./constants.AUtoKCAL)
                complex_species.conformer_index = [2]
                complex_species.conformer_geom = [lower.geometry]
                complex_species.conformer_zeroenergy = [lower.zero_energy_hartree]
                complex_species.conformer_freq = [lower.frequencies_cm1]
                complex_species.conformer_inventory = (lower,)
                complex_species.conformer_records = {2: lower}
            saved_ts = (reaction.ts.geom.copy(), reaction.ts.energy,
                        reaction.ts.zpe, list(reaction.ts.freq))
            folder = root / f'mc_{mc}'
            folder.mkdir()
            worker = folder / routing_name(parent)
            worker.mkdir()
            (worker / 'me').mkdir()
            par = dict(self.par, multi_conf_tst=mc, smiles='C', pes=1)
            os.chdir(worker)
            try:
                MESS(par, parent).write_input(None)
            finally:
                os.chdir(root)
            # The option can be changed at final PES assembly without new QC
            # or rewriting the worker's saved statistical models.
            artifacts = {path.name: path.read_bytes() for path in worker.glob('*.mess')}
            prod_names = sorted(routing_name(p) for p in reaction.products)
            prod_key = '_'.join(prod_names)
            parent_name, complex_name = routing_name(parent), complex_species.name
            for skip, corrected in itertools.product((0, 1), repeat=2):
                for mode in ('direct', 'pes'):
                    with self.subTest(mc=mc, skip=skip, corrected=corrected, mode=mode):
                        settings = dict(par, me_skip_vdW=skip, correct_submerged=corrected)
                        os.chdir(folder)
                        try:
                            if mode == 'direct':
                                (folder / 'me').mkdir(exist_ok=True)
                                MESS(dict(settings, pes=0), parent).write_input(None)
                            else:
                                with patch('kinbot.pes.logger', logging.getLogger('KinBot'), create=True):
                                    pes.create_mess_input(settings,
                                        [parent_name, complex_name], [prod_key], [], [],
                                        [[parent_name, reaction.instance_name, prod_names,
                                          25., 20., 'vdW_IRC_F_prod']],
                                        {parent_name: 0., complex_name: 20.}, {prod_key: 30.},
                                        {parent_name: parent_name, complex_name: parent_name,
                                         prod_key: complex_name}, parent.mass, False)
                            output = Path('me/mess_0000.inp').read_text()
                        finally:
                            os.chdir(root)
                        _, blocks, _ = split_model(output)
                        wells = [block for block in blocks if _HEADER.search(block)[1] == 'Well']
                        barriers = [block for block in blocks if _HEADER.search(block)[1] == 'Barrier']
                        inner = next(block for block in barriers if 'ImaginaryFrequency' in block)
                        self.assertEqual(len(wells), 1 if skip else 2)
                        self.assertEqual(len(barriers), 1 if skip else 2)
                        self.assertEqual(output.count('Core PhaseSpaceTheory'), 0 if skip else 1)
                        self.assertEqual(values(inner, 'ZeroEnergy'), [25.])
                        self.assertEqual(values(inner, 'ImaginaryFrequency'), [1000.])
                        self.assertEqual(values(inner, 'Frequencies'), [8.])
                        self.assertEqual(values(inner, 'WellDepth'), [25., 5.])
                        self.assertEqual(values(inner, 'CutoffEnergy'), [5.])
                        self.assertEqual(values(output, 'GroundEnergy'), [30.])
                        right = reaction.products if skip else [complex_species]
                        self.assertIn('! kinbot_mirror_endpoints ' + ' '.join(
                            population_keys([parent]) + population_keys(right)), inner)
                        if not skip:
                            complex_block = next(block for block in wells if complex_name in block)
                            self.assertEqual(values(complex_block, 'ZeroEnergy'), [19. if mc else 20.])
                            exit_block = next(block for block in barriers if 'Core PhaseSpaceTheory' in block)
                            complex_short = _HEADER.search(complex_block)[2].split()[0]
                            self.assertIn(complex_short, _HEADER.search(exit_block)[2].split()[1:3])
                        self.assertTrue(reaction.do_vdW)
                        np.testing.assert_array_equal(reaction.ts.geom, saved_ts[0])
                        self.assertEqual((reaction.ts.energy, reaction.ts.zpe, reaction.ts.freq), saved_ts[1:])
                        self.assertEqual({path.name: path.read_bytes() for path in worker.glob('*.mess')},
                                         artifacts)

    def test_homolysis_never_counts_or_renders_placeholder_saddle(self):
        parent, reactions = self.reactions(True)
        writer = MESS(self.par, parent)
        original = writer._parent_symmetry
        def checked(p, **kwargs):
            self.assertIsNot(p, reactions[0].ts)
            return original(p, **kwargs)
        with patch.object(writer, '_parent_symmetry', side_effect=checked), \
             patch.object(writer, 'write_barrier', side_effect=AssertionError('placeholder TS')):
            writer.write_input(None)
        output = Path('me/mess_0000.inp').read_text()
        self.assertEqual(output.count('Core PhaseSpaceTheory'), 1)
        self.assertNotIn('Tunneling', output)
        self.assertNotIn('{blessname}', output)

    def test_full_pes_stages_scalar_and_multistate_flux_after_network_energy_assignment(self):
        from test_vrc_multistate import _completed_channel
        root = Path.cwd()
        for multistate in (False, True):
            folder = root / ('multistate' if multistate else 'scalar')
            folder.mkdir()
            os.chdir(folder)
            try:
                parent, reactions = self.reactions(True)
                reaction = reactions[0]
                reaction.instance_name = 'r_hom_sci'
                parent_name = routing_name(parent)
                product_names = sorted(routing_name(p) for p in reaction.products)
                product_key = '_'.join(product_names)
                worker = folder / parent_name
                worker.mkdir()
                (worker / 'me').mkdir()
                rotd = folder / 'rotdPy'
                rotd.mkdir()
                settings = dict(self.par, pes=1, smiles='C', uq_n=2,
                    rotdpy_mess_mode='required', rotdpy_directory=str(rotd),
                    vrc_tst_scan={parent_name: ['r_hom_sci']})
                if multistate:
                    manifest = _completed_channel(rotd)
                    payload = json.loads(manifest.read_text())
                    payload['reaction'] = reaction.instance_name
                    manifest.unlink()
                    (rotd / f'{reaction.instance_name}.multistate.json').write_text(json.dumps(payload))
                    settings['vrc_tst_surface_model_file'] = str(rotd / 'surfaces.json')
                else:
                    (rotd / 'r_hom_sci.py').write_text('# generated scalar input\n')
                    number = rotd / 'kb_r' / 'Ne_0.out'
                    surface = rotd / 'kb_r' / 'output' / 'surface_0.dat'
                    surface.parent.mkdir(parents=True)
                    number.write_text('-186 0\n0 100\n100 200\n300 400\n')
                    surface.write_text('native flux\n')
                    files = [str(path.relative_to(rotd)) for path in (number, surface)]
                    (rotd / 'r_hom_sci.rotdpy.json').write_text(json.dumps({
                        'status': 'complete', 'surface_count': 1,
                        'validation': {'dynamical_correction': .85,
                            'dynamical_correction_application': 'number_of_states_flux'},
                        'result_files': files, 'result_sha256': {
                            name: hashlib.sha256((rotd/name).read_bytes()).hexdigest() for name in files}}))
                def factor(parameter, iteration):
                    if parameter in ('energy', 'barrier'):
                        return 3. * iteration
                    return 1. + .1 * iteration if parameter == 'freq' else 1.
                with patch('kinbot.uncertaintyAnalysis.UQ.calc_factor', side_effect=factor):
                    os.chdir(worker)
                    MESS(settings, parent).write_input(None)
                    original = {path.name: path.read_bytes() for path in worker.glob('*.mess')}
                    os.chdir(folder)
                    with patch('kinbot.pes.logger', logging.getLogger('KinBot'), create=True):
                        pes.create_mess_input(settings, [parent_name], [product_key], [],
                            [[parent_name, 'r_hom_sci', product_names, 0.]], [],
                            {parent_name: 0.}, {product_key: 30.},
                            {parent_name: parent_name, product_key: parent_name}, parent.mass, False)
                for iteration in (0, 1):
                    output = Path(f'me/mess_{iteration:04d}.inp').read_text()
                    self.assertEqual(output.count('Core Rotd'), 2 if multistate else 1)
                    self.assertNotIn('PhaseSpaceTheory', output)
                    self.assertNotIn('kinbot_rotdpy_begin', output)
                    self.assertNotIn('{ground_energy}', output)
                    self.assertIn(str(1000 + 100*iteration), output)
                    expected = 30. + 3.*iteration
                    if not multistate:
                        expected -= 186. * constants.AUtoKCAL / constants.AUtoCM
                    self.assertTrue(any(abs(value-expected) < 1.e-7 for value in values(output, 'ZeroEnergy')))
                    provenance = json.loads(Path(f'me/rotdpy_sources_{iteration:04d}.json').read_text())
                    record = provenance['reactions']['r_hom_sci']
                    self.assertEqual(record['network_ground_energy_kcal_mol'], 30.+3.*iteration)
                    self.assertTrue(Path('me', record['staged_bottlenecks'][0]['file']
                        if multistate else record['mess_file']).is_file())
                self.assertEqual({path.name: path.read_bytes() for path in worker.glob('*.mess')}, original)
                # Context tampering cannot change a final network convolution.
                context = next((worker / 'me/rotdpy_models').glob('*.json'))
                context.write_text('{}')
                from kinbot.rotdpy_mess import resolve_models
                # Check every UQ context; the first changed one must be rejected.
                with self.assertRaisesRegex(ValueError, 'context changed'):
                    for item in original.values():
                        if b'kinbot_rotdpy_begin' in item:
                            resolve_models(item.decode(), worker, settings, 30., {}, 'r_hom_sci')
            finally:
                os.chdir(root)

    def test_required_rotd_does_not_require_unselected_optional_vdw_exits(self):
        parent, _ = self.reactions()
        settings = dict(self.par, rotdpy_mess_mode='production',
            vrc_tst_scan={routing_name(parent): ['a_different_hom_sci']},
            vrc_tst_surface_model_file='reviewed.json')
        MESS(settings, parent).write_input(None)
        self.assertIn('Core PhaseSpaceTheory', Path('me/mess_0000.inp').read_text())

    def test_selected_geometry_rotd_cannot_silently_stand_for_a_conformer_union(self):
        parent, reactions = self.reactions(True)
        reaction = reactions[0]
        fragment = reaction.products[0]
        record = representative_record(fragment)
        records = {0: record, 1: replace(record, index=1,
            zero_energy_hartree=record.zero_energy_hartree+.001)}
        folder = Path('rotdPy')
        folder.mkdir()
        (folder / f'{reaction.instance_name}.py').write_text('# exists\n')
        (folder / f'{reaction.instance_name}.rotdpy.json').write_text('{}')
        writer = MESS(dict(self.par, multi_conf_tst=1, rotdpy_mess_mode='required'), parent)
        with patch('kinbot.mess.writer_members', side_effect=lambda point, *args: records if point is fragment else {}):
            with self.assertRaisesRegex(NotImplementedError, 'separate sampled flux'):
                writer._rotd_model(reaction.products, 'CH4', 0., 0., 1., 1., reaction)

    def test_homolysis_can_require_a_hash_verified_rotd_surface(self):
        parent, reactions = self.reactions(True)
        reaction = reactions[0]
        root = Path('rotdPy')
        result_root = root / f'kb_{reaction.instance_name}'
        surface = result_root / 'output' / 'surface_0.dat'
        number = result_root / 'Ne_0.out'
        surface.parent.mkdir(parents=True)
        input_file = root / f'{reaction.instance_name}.py'
        input_file.write_text('# generated ROTD_py input\n')
        surface.write_text('surface flux\n')
        number.write_text('0.0 1.0\n100.0 2.0\n')
        result_files = [
            str(number.relative_to(root)), str(surface.relative_to(root))]
        hashes = {
            relative: hashlib.sha256((root / relative).read_bytes()).hexdigest()
            for relative in result_files
        }
        manifest = root / f'{reaction.instance_name}.rotdpy.json'
        manifest.write_text(json.dumps({
            'schema': 2, 'status': 'complete',
            'reaction': reaction.instance_name, 'surface_count': 1,
            'validation': {
                'name': 'interface', 'dynamical_correction': 0.85,
                'dynamical_correction_application': 'number_of_states_flux'},
            'result_files': result_files, 'result_sha256': hashes,
        }))

        writer = MESS(dict(self.par, rotdpy_mess_mode='required'), parent)
        writer.write_input(None)
        output = Path('me/mess_0000.inp').read_text()
        self.assertIn('Core Rotd', output)
        self.assertNotIn('Core PhaseSpaceTheory', output)
        staged = Path('me/rotd_test_hom_sci_Ne_0.out')
        self.assertEqual(
            staged.read_text(), '0 0\n0.01 1.0\n100.0 2.0\n')
        self.assertEqual(number.read_text(), '0.0 1.0\n100.0 2.0\n')
        provenance = json.loads(Path('me/rotdpy_sources.json').read_text())
        source = provenance['reactions'][reaction.instance_name]
        self.assertEqual(source['source_sha256'], hashes[result_files[0]])
        self.assertEqual(source['mess_file_sha256'], hashlib.sha256(
            staged.read_bytes()).hexdigest())
        self.assertEqual(source['mess_preprocessing'], {
            'name': 'explicit_zero_flux_origin',
            'applied': True,
            'row': [0., 0.],
            'positive_flux_origin_shift_cm_inverse': 0.01,
        })
        self.assertEqual(source['indistinguishability_factor'], 1)
        self.assertEqual(source['fragment_multiplicities'], [2, 2])
        self.assertEqual(source['reactive_surface_multiplicity'], 1)
        self.assertEqual(source['dynamical_correction'], 0.85)
        self.assertEqual(
            source['mess_symmetry_factor'],
            writer._parent_symmetry(reaction.products[0])
            * writer._parent_symmetry(reaction.products[1]))
        self.assertAlmostEqual(
            source['raw_flux_equivalent_mess_symmetry_factor'],
            source['mess_symmetry_factor'] / 0.85)
        writer.par['rotdpy_mess_mode'] = 'off'
        writer.write_input(None)
        self.assertIn('Core PhaseSpaceTheory', Path('me/mess_0000.inp').read_text())
        self.assertEqual(json.loads(Path('me/rotdpy_sources.json').read_text())['reactions'], {})

    def test_rotd_self_combination_includes_identical_fragment_factor(self):
        parent, reactions = self.reactions(True)
        reaction = reactions[0]
        fragment = reaction.products[0]
        reaction.products = [fragment, copy.deepcopy(fragment)]
        root = Path('rotdPy')
        result_root = root / f'kb_{reaction.instance_name}'
        surface = result_root / 'output' / 'surface_0.dat'
        number = result_root / 'Ne_0.out'
        surface.parent.mkdir(parents=True)
        input_file = root / f'{reaction.instance_name}.py'
        input_file.write_text('# generated ROTD_py input\n')
        surface.write_text('surface flux\n')
        number.write_text('0.0 1.0\n100.0 2.0\n')
        result_files = [
            str(number.relative_to(root)), str(surface.relative_to(root))]
        hashes = {
            relative: hashlib.sha256((root / relative).read_bytes()).hexdigest()
            for relative in result_files
        }
        (root / f'{reaction.instance_name}.rotdpy.json').write_text(
            json.dumps({
                'schema': 3, 'status': 'complete',
                'reaction': reaction.instance_name, 'surface_count': 1,
                'validation': {
                    'name': 'interface', 'dynamical_correction': 0.85,
                    'dynamical_correction_application': (
                        'number_of_states_flux')},
                'result_files': result_files, 'result_sha256': hashes,
            }))

        writer = MESS(dict(self.par, rotdpy_mess_mode='required'), parent)
        block = writer._rotd_model(
            reaction.products, 'C2H6', 0., 0., 1., 1., reaction)
        source = writer.rotdpy_sources[reaction.instance_name]
        fragment_symmetry = writer._parent_symmetry(fragment)

        self.assertIn('Core Rotd', block)
        self.assertEqual(source['rotational_symmetry_product'],
                         fragment_symmetry ** 2)
        self.assertEqual(source['indistinguishability_factor'], 2)
        self.assertEqual(source['fragment_multiplicities'], [2, 2])
        self.assertEqual(source['reactive_surface_multiplicity'], 1)
        self.assertEqual(source['mess_symmetry_factor'],
                         fragment_symmetry ** 2 * 2)
        self.assertAlmostEqual(
            source['raw_flux_equivalent_mess_symmetry_factor'],
            fragment_symmetry ** 2 * 2 / 0.85)

    def test_required_rotd_surface_refuses_phase_space_fallback(self):
        parent, _ = self.reactions(True)
        writer = MESS(dict(self.par, rotdpy_mess_mode='required'), parent)
        with self.assertRaisesRegex(FileNotFoundError, 'completed ROTD_py'):
            writer.write_input(None)

    def test_mc_phase_space_uses_product_combinations_and_parent_normalization(self):
        parent, reactions = self.reactions(True)
        fragment = reactions[0].products[0]
        base = representative_record(fragment)
        # Associated calculated properties, including a tolerated soft mode.
        first = replace(base, index=0, zero_energy_hartree=base.zero_energy_hartree-1./constants.AUtoKCAL,
                        frequencies_cm1=(-20., *base.frequencies_cm1[1:]))
        second = replace(base, index=2, zero_energy_hartree=base.zero_energy_hartree+2./constants.AUtoKCAL,
                         sigma_ext=base.sigma_ext/2, remaining_optical_weight=2.)
        ensemble = {0: first, 2: second}
        from kinbot.mess import writer_members as original
        def members(point, population, **kwargs):
            return ensemble if point is fragment else original(point, population, **kwargs)
        par = dict(self.par, multi_conf_tst=1)
        with patch('kinbot.mess.writer_members', side_effect=members):
            writer = MESS(par, parent)
            writer.write_input(None)
            direct = Path('me/mess_0000.inp').read_text()
            writer.par['pes'] = 1
            deferred = writer.write_bimol(reactions[0].products, 0., 1., 1., 0, 1)
        expected_parent = (sum(p.energy+p.zpe for p in reactions[0].products)
                           - parent.energy-parent.zpe)*constants.AUtoKCAL
        replacements = dict(name='b_1', ground_energy=expected_parent, blessname='bl',
                            wellname='w_1', prodname='b_1')
        replacements.update({'fr_name_'+routing_name(p): 'fr_'+str(i)
                             for i,p in enumerate(reactions[0].products)})
        deferred = apply_conformer_shifts(deferred.format(**replacements))
        for text in (direct, deferred):
            barrier = text[text.index('  Barrier'):]
            self.assertIn('Union ! product conformer combinations', barrier)
            self.assertEqual(values(barrier, 'ZeroEnergy'),
                             [round(expected_parent-1., 2), round(expected_parent+2., 2)])
            self.assertEqual(values(barrier, 'SymmetryFactor'), [1., .25])
            self.assertIn('20.0', barrier)
            self.assertNotIn('-20.0', barrier)
            self.assertEqual(values(text, 'GroundEnergy'), [round(expected_parent-1., 2)])
        self.assertEqual(first.frequencies_cm1[0], -20.)


    def test_two_mc_fragment_ensembles_form_four_phase_space_terms(self):
        parent, _ = self.reactions(True)
        products = [species('H2O'), species('NH3')]
        choices = []
        for p, offset, divisor in zip(products, (2., 3.), (.5, 1./3.)):
            base = representative_record(p)
            choices.append({0: base, 1: replace(base, index=1,
                zero_energy_hartree=base.zero_energy_hartree+offset/constants.AUtoKCAL,
                sigma_ext=base.sigma_ext*divisor)})
        writer = MESS(dict(self.par, multi_conf_tst=1), parent)
        def members(p, population):
            return choices[next(i for i, point in enumerate(products) if point is p)]
        with patch('kinbot.mess.writer_members', side_effect=members):
            direct = writer._phase_space_models(products, 'H5N1O1', 50., 0., 1., 1.)
            writer.par['pes'] = 1
            deferred = writer._phase_space_models(products, 'H5N1O1', '{ground_energy}', 0., 1., 1.)
        deferred = apply_conformer_shifts(deferred.format(ground_energy=50.))
        for output in (direct, deferred):
            self.assertEqual(output.count('Core PhaseSpaceTheory'), 4)
            self.assertEqual(values(output, 'ZeroEnergy'), [50., 53., 52., 55.])
            self.assertEqual(values(output, 'SymmetryFactor'), [1., 1./3., .5, 1./6.])
            self.assertEqual(values(output, 'Frequencies'), [9.]*4)

    def test_pes_complex_choice_does_not_depend_on_discovery_order(self):
        observations = [ ['p', name, prods, 30., None, 'vdW_IRC_F_prod']
                         for name, prods in [('high', ['a', 'b']), ('low', ['b', 'a']),
                                             ('stereo', ['a', 'b-s-other'])] ]
        energies = {'high_IRC_F_prod': -1., 'low_IRC_F_prod': -2., 'stereo_IRC_F_prod': -3.}
        expected = {'high_IRC_F_prod': 'low_IRC_F_prod', 'low_IRC_F_prod': 'low_IRC_F_prod',
                    'stereo_IRC_F_prod': 'stereo_IRC_F_prod'}
        for order in itertools.permutations(observations):
            self.assertEqual(pes.find_min_vdW(list(order), energies), expected)


if __name__ == '__main__':
    unittest.main()
