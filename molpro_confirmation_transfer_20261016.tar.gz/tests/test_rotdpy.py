"""General rotdPy input generation, execution, and restart contracts."""

import json
import os
from pathlib import Path
import pickle
import signal
import sqlite3
import subprocess
import sys
from tempfile import TemporaryDirectory
import time
from types import SimpleNamespace
from unittest.mock import patch

import pytest

from kinbot.parameters import Parameters
from kinbot.pes import (_rotdpy_correction_block,
                        _write_rotdpy_slurm_template,
                        create_rotdpy_inputs)
from kinbot.rotdpy import (_controller_lock, ensure_available, main,
                           number_of_states_file, read_result, run,
                           sampling_progress,
                           stage_number_of_states_file)
from kinbot.molpro import _vrc_multireference_method


def test_full_pes_restores_automatic_homolytic_selection(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr('kinbot.pes._write_rotdpy_slurm_template', lambda *args: None)
    par = {'rotdpy_run': 1, 'queuing': 'slurm',
           'vrc_tst_scan': {}, 'vrc_tst_noscan': {}}
    # The correction precondition is reached only if the accepted global
    # homolytic channel was restored to the worker-independent selection.
    with pytest.raises(KeyError, match='Results of scan'):
        create_rotdpy_inputs(par, [['parent', 'parent_hom_sci_1_2', ['a', 'b'], 0.]], [])
    assert par['vrc_tst_scan'] == {'parent': ['parent_hom_sci_1_2']}


def test_generated_input_uses_configured_sampling_and_portable_scratch():
    with TemporaryDirectory() as temporary:
        previous = Path.cwd()
        os.chdir(temporary)
        try:
            Path('input.json').write_text(json.dumps({
                'barrier_threshold': 50.,
                'queuing': 'slurm',
                'queue_name': 'short-cpu',
                'vrc_tst_noscan': {'parent': ['parent_hom_sci_1_2']},
                'rotdpy_dist': [3.0],
                'rotdpy_processors': 2,
                'rotdpy_max_jobs': 3,
                'rotdpy_walltime': '01:30:00',
                'rotdpy_temperature_grid': [100., 50., 1., 2],
                'rotdpy_energy_grid': [0., 5., 1., 3],
                'rotdpy_angular_grid': [0., 1., 1., 4],
                'rotdpy_flux_parameters': {
                    'pot_smp_max': 8, 'pot_smp_min': 4,
                    'tot_smp_max': 8, 'tot_smp_min': 4,
                    'flux_rel_err': 5, 'smp_len': 1,
                },
            }))
            par = Parameters('input.json', show_warnings=False).par
            Path('vrctst').mkdir()
            reaction = 'parent_hom_sci_1_2'
            Path(f'vrctst/corr_{reaction}.json').write_text(json.dumps({
                'dist': [30.], 'e_samp': [0.], 'e_high': [0.],
                'scan_ref': [[0, 0]], 'ra': [[0], [0]],
                'e_inf_samp': -1., 'e_inf_high': -1.,
                'frags_atom': [['H'], ['H']],
                'frags_geom': [[[0., 0., 0.]], [[1., 0., 0.]]],
                'frags_mult': [2, 2], 'unique': [[[0]], [[0]]],
            }))
            created = create_rotdpy_inputs(
                par, [['parent', reaction, ['h', 'h'], 0.]], [],
                correction_root='.')
            assert created == [f'rotdPy/{reaction}.py']
            generated = Path(created[0]).read_text()
            compile(generated, created[0], 'exec')
            assert "'method': 'caspt2(2,2)'" in generated
            assert "'basis': 'vdz'" in generated
            assert "'processors': 2" in generated
            assert "'max_jobs': 3" in generated
            assert "os.environ.get('SCRATCH')" in generated
            assert 'corrections = None' in generated
            assert "'KinBot 1D scan'" not in generated
            assert 'temperature = generate_grid(*[100.0, 50.0, 1.0, 2])' in generated
            assert "'pot_smp_min': 4" in generated
            assert 'dynamical_correction=0.85' in generated
            scheduler = Path('rotdPy/qu.tpl').read_text()
            site_setup = Path('rotdPy/site_setup.sh')
            assert site_setup.is_file()
            assert 'KINBOT_BACKEND=molpro' in scheduler
            assert f'source {site_setup.resolve()}' in scheduler
            assert 'command -v molpro' in scheduler
            assert '#SBATCH --partition=short-cpu' in scheduler
            assert '#SBATCH --ntasks={procs}' in scheduler
            assert '#SBATCH --time=01:30:00' in scheduler
            assert 'export I_MPI_FABRICS="${{I_MPI_FABRICS:-shm}}"' in scheduler
            sample_job = scheduler.format(
                surf_id=0, face_id=1, samp_id=2, procs=2, mem=4096)
            assert 'export I_MPI_FABRICS="${I_MPI_FABRICS:-shm}"' in sample_job
            assert '#SBATCH --ntasks=2' in sample_job
            assert str(Path(sys.executable)) in scheduler
        finally:
            os.chdir(previous)


def test_rotdpy_partition_max_uses_discovered_partition_limit(tmp_path):
    with patch('kinbot.qc._ordinary_slurm_walltime',
               return_value='#SBATCH --time=01:00:00') as discover, \
            patch.dict(os.environ, {'SBATCH_EXCLUDE': 'node16'}, clear=True):
        path = _write_rotdpy_slurm_template({
            'queuing': 'slurm',
            'queue_name': 'short-cpu',
            'queue_walltime': 'partition_max',
            'rotdpy_walltime': 'partition_max',
            'rotdpy_exclusive': 0,
        }, tmp_path)

    text = Path(path).read_text()
    discover.assert_called_once()
    assert '#SBATCH --partition=short-cpu' in text
    assert '#SBATCH --time=01:00:00' in text
    assert '#SBATCH --exclude=node16' in text
    assert '@WALLTIME' not in text


def test_multipoint_vrc_scan_retains_cubic_correction_contract():
    correction = {
        'dist': [3., 4., 5., 30.],
        'e_samp': [4., 2., 1., 0.],
        'e_high': [5., 2.5, 1.2, 0.],
        'scan_ref': [[0, 1]],
    }
    rendered = _rotdpy_correction_block(correction, noscan=False)
    assert "'KinBot 1D scan'" in rendered
    assert "'r_sample' : [3.0, 4.0, 5.0, 30.0]" in rendered

    with pytest.raises(ValueError, match='three scan points plus'):
        _rotdpy_correction_block({
            **correction,
            'dist': [3., 4., 30.],
            'e_samp': [2., 1., 0.],
            'e_high': [2.5, 1.2, 0.],
        }, noscan=False)


def test_vrc_mrci_q_uses_davidson_corrected_energy():
    method, energy = _vrc_multireference_method('MRCI+Q(2,2)', 18)
    assert 'occ,10' in method
    assert 'closed,8' in method
    assert 'wf,18,1,0' in method
    assert '{mrci,thrden=1.d-8,thrvar=1.d-10;option,cluster=0;}' in method
    assert 'KBVRCVAR=energy(1)' in method
    assert 'KBVRCSEL=energd(1)' in method
    assert energy == 'KBVRCSEL'


def test_mess_staging_adds_zero_flux_origin_without_changing_native(tmp_path):
    source = tmp_path / 'Ne_1.out'
    destination = tmp_path / 'me' / 'Ne_1.out'
    source.write_text('0.0000e+00 2.5000e+00\n6.9503e+00 3.0000e+00\n')

    provenance = stage_number_of_states_file(source, destination)

    assert source.read_text() == (
        '0.0000e+00 2.5000e+00\n6.9503e+00 3.0000e+00\n')
    assert destination.read_text() == (
        '0 0\n0.01 2.5000e+00\n6.9503e+00 3.0000e+00\n')
    assert provenance['name'] == 'explicit_zero_flux_origin'
    assert provenance['applied'] is True
    assert provenance['positive_flux_origin_shift_cm_inverse'] == 0.01
    assert provenance['mess_file_sha256'] == __import__('hashlib').sha256(
        destination.read_bytes()).hexdigest()

    provenance = stage_number_of_states_file(destination,
                                              tmp_path / 'already.out')
    assert provenance['applied'] is False
    assert provenance['positive_flux_origin_shift_cm_inverse'] is None
    assert (tmp_path / 'already.out').read_text() == destination.read_text()


def test_mess_staging_preserves_native_negative_threshold_and_energy_reference(tmp_path):
    from kinbot.rotdpy import number_of_states_ground
    source, target = tmp_path / 'native.out', tmp_path / 'mess.out'
    source.write_text('-186 0\n0 13000\n100 15000\n')
    info = stage_number_of_states_file(source, target)
    assert target.read_bytes() == source.read_bytes()
    assert not info['applied']
    assert info['row'] == [-186., 0.]
    assert number_of_states_ground(target) == -186.


def test_production_result_requires_converged_numeric_multipoint_sampling(
        tmp_path):
    input_file = tmp_path / 'channel.py'
    input_file.write_text('# production input\n')
    result_root = tmp_path / 'kb_channel'
    outputs = [result_root / 'Ne_0.out'] + [
        result_root / 'output' / f'surface_{index}.dat'
        for index in range(3)]
    for output in outputs:
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text('0.0 1.0\n')
    relatives = [str(path.relative_to(tmp_path)) for path in outputs]
    hashes = {relative: __import__('hashlib').sha256(
        path.read_bytes()).hexdigest()
              for relative, path in zip(relatives, outputs)}
    validation = {
        'name': 'production',
        'sampling_level': {'method': 'caspt2(2,2)', 'basis': 'vdz'},
        'trusted_correction_level': {
            'method': 'mrci+q(2,2)', 'basis': 'vtz'},
        'correction': {'kind': 'one_dimensional', 'point_count': 4,
                       'source_sha256': 'a' * 64},
        'dividing_surfaces': {
            'requested_distances_angstrom': [3., 4., 5.],
            'generated_count': 3},
        'dynamical_correction': 0.85,
        'dynamical_correction_application': 'number_of_states_flux',
    }
    statistics = {
        str(index): {'converged': True, 'accepted_samples': 100}
        for index in range(3)}
    manifest = {
        'schema': 3, 'status': 'complete', 'reaction': 'channel',
        'surface_count': 3,
        'input_sha256': __import__('hashlib').sha256(
            input_file.read_bytes()).hexdigest(),
        'validation': validation, 'surface_statistics': statistics,
        'result_files': relatives, 'result_sha256': hashes,
    }
    (tmp_path / 'channel.rotdpy.json').write_text(json.dumps(manifest))
    assert read_result(input_file, required_profile='production')[
        'surface_count'] == 3
    _, provenance = number_of_states_file(
        input_file, required_profile='production')
    assert provenance['dynamical_correction'] == pytest.approx(0.85)
    assert provenance['dynamical_correction_source'] == 'validation_metadata'

    validation['trusted_correction_level'] = {
        'model': 'spin_splitting',
        'triplet_reference': {
            'method': 'uccsd(t)-f12b',
            'basis': ['avtz-f12', 'avqz-f12'],
        },
        'singlet_triplet_gaps': [
            {'label': 'caspt2_f12', 'method': 'caspt2-f12(2,2)',
             'basis': ['avtz-f12', 'avqz-f12']},
            {'label': 'mrci_f12_q', 'method': 'mrci-f12+q(2,2)',
             'basis': ['avtz-f12', 'avqz-f12']},
        ],
        'weighting': {'model': 'distance_switch'},
    }
    (tmp_path / 'channel.rotdpy.json').write_text(json.dumps(manifest))
    assert read_result(input_file, required_profile='production')[
        'surface_count'] == 3

    # Completed production calculations from before the metadata field was
    # added remain auditable from their immutable generated Python input.
    validation.pop('dynamical_correction')
    validation.pop('dynamical_correction_application')
    input_file.write_text(
        '# production input\n'
        'multi.print_results(\n'
        'dynamical_correction=0.85,\n'
        ')\n')
    manifest['input_sha256'] = __import__('hashlib').sha256(
        input_file.read_bytes()).hexdigest()
    (tmp_path / 'channel.rotdpy.json').write_text(json.dumps(manifest))
    _, provenance = number_of_states_file(
        input_file, required_profile='production')
    assert provenance['dynamical_correction'] == pytest.approx(0.85)
    assert provenance['dynamical_correction_source'] == 'generated_input'

    manifest['surface_statistics']['1']['converged'] = False
    (tmp_path / 'channel.rotdpy.json').write_text(json.dumps(manifest))
    with pytest.raises(RuntimeError, match='not converged'):
        read_result(input_file, required_profile='production')


def test_production_selection_rejects_interface_smoke_manifest(tmp_path):
    input_file = tmp_path / 'channel.py'
    input_file.write_text('# smoke input\n')
    surface = tmp_path / 'kb_channel' / 'output' / 'surface_0.dat'
    number = tmp_path / 'kb_channel' / 'Ne_0.out'
    surface.parent.mkdir(parents=True)
    surface.write_text('0.0 1.0\n')
    number.write_text('0.0 1.0\n')
    relatives = [str(number.relative_to(tmp_path)),
                 str(surface.relative_to(tmp_path))]
    hashes = {relative: __import__('hashlib').sha256(
        (tmp_path / relative).read_bytes()).hexdigest()
              for relative in relatives}
    (tmp_path / 'channel.rotdpy.json').write_text(json.dumps({
        'schema': 2, 'status': 'complete', 'reaction': 'channel',
        'surface_count': 1, 'result_files': relatives,
        'result_sha256': hashes,
    }))
    with pytest.raises(RuntimeError, match='not production validated'):
        number_of_states_file(input_file, required_profile='production')


def test_executor_records_success_and_reuses_matching_result():
    with TemporaryDirectory() as temporary:
        root = Path(temporary)
        input_file = root / 'channel.py'
        (root / 'qu.tpl').write_text('# test scheduler template\n')
        surface = root / 'kb_channel' / 'output' / 'surface_0.dat'
        number = root / 'kb_channel' / 'Ne_0.out'
        surface.parent.mkdir(parents=True)
        surface.write_text('surface flux\n')
        number.write_text('0.0 1.0\n')
        surface_hash = __import__('hashlib').sha256(surface.read_bytes()).hexdigest()
        number_hash = __import__('hashlib').sha256(number.read_bytes()).hexdigest()
        input_file.write_text(
            "import json\n"
            "from pathlib import Path\n"
            "Path('channel.rotdpy.json').write_text(json.dumps({"
            "'schema': 2, 'status': 'complete', 'reaction': 'channel', "
            "'surface_count': 2, "
            "'result_files': ['kb_channel/Ne_0.out', "
            "'kb_channel/output/surface_0.dat'], "
            f"'result_sha256': {{'kb_channel/Ne_0.out': '{number_hash}', "
            f"'kb_channel/output/surface_0.dat': '{surface_hash}'}}"
            "}))\n"
            "print('sampling complete')\n")
        with patch('kinbot.rotdpy.ensure_available', return_value={
                'version': 'test', 'location': '/test',
                'git_revision': 'abc'}):
            record = run(input_file, python=sys.executable)
            reused = run(input_file, python=sys.executable)
        assert record['status'] == 'complete'
        assert record['surface_count'] == 2
        assert reused == record
        assert (root / 'channel.rotdpy.stdout').read_text() == (
            'sampling complete\n')


def test_executor_rejects_a_second_controller_for_the_same_input(tmp_path):
    input_file = tmp_path / 'channel.py'
    input_file.write_text('# generated input\n')

    with _controller_lock(input_file):
        with pytest.raises(RuntimeError, match='another ROTD_py controller'):
            with _controller_lock(input_file):
                pass

    owner = input_file.with_name('channel.controller.lock')
    assert owner.read_text() == ''


def test_executor_forwards_termination_to_controller_process_group(tmp_path):
    child = tmp_path / 'child.py'
    child.write_text(
        'import os\n'
        'from pathlib import Path\n'
        'import time\n'
        "Path('child.pid').write_text(str(os.getpid()))\n"
        'while True:\n'
        '    time.sleep(1)\n')
    wrapper = tmp_path / 'wrapper.py'
    wrapper.write_text(
        'from pathlib import Path\n'
        'import sys\n'
        'from kinbot.rotdpy import _run_controller\n'
        f'_run_controller([sys.executable, {str(child)!r}], '
        f'Path({str(tmp_path)!r}))\n')
    process = subprocess.Popen([sys.executable, str(wrapper)])
    pid_file = tmp_path / 'child.pid'
    for _ in range(100):
        if pid_file.is_file():
            break
        time.sleep(.05)
    assert pid_file.is_file()
    child_pid = int(pid_file.read_text())

    process.send_signal(signal.SIGTERM)
    assert process.wait(timeout=15) == 128 + signal.SIGTERM
    with pytest.raises(ProcessLookupError):
        os.kill(child_pid, 0)


def test_number_of_states_selection_is_hash_verified():
    with TemporaryDirectory() as temporary:
        root = Path(temporary)
        input_file = root / 'channel.py'
        input_file.write_text('# generated input\n')
        result_root = root / 'kb_channel'
        surface = result_root / 'output' / 'surface_0.dat'
        first = result_root / 'Ne_0.out'
        final = result_root / 'Ne_1.out'
        surface.parent.mkdir(parents=True)
        surface.write_text('surface flux\n')
        first.write_text('0.0 1.0\n')
        final.write_text('0.0 2.0\n')
        files = [first, final, surface]
        relatives = [str(path.relative_to(root)) for path in files]
        hashes = {
            relative: __import__('hashlib').sha256(path.read_bytes()).hexdigest()
            for relative, path in zip(relatives, files)
        }
        (root / 'channel.rotdpy.json').write_text(json.dumps({
            'schema': 2, 'status': 'complete', 'reaction': 'channel',
            'surface_count': 1, 'result_files': relatives,
            'result_sha256': hashes,
        }))

        selected, provenance = number_of_states_file(input_file)
        assert selected == final.resolve()
        assert provenance['energy_index'] == 1
        assert provenance['selection'] == 'highest_available_correction'
        explicit, provenance = number_of_states_file(input_file, 0)
        assert explicit == first.resolve()
        assert provenance['selection'] == 'explicit'
        with pytest.raises(RuntimeError, match='no Ne_2.out'):
            number_of_states_file(input_file, 2)
        final.write_text('changed\n')
        with pytest.raises(RuntimeError, match='hash changed'):
            number_of_states_file(input_file)


def test_executor_fails_early_when_rotdpy_is_not_installed():
    with TemporaryDirectory() as temporary:
        input_file = Path(temporary) / 'channel.py'
        input_file.write_text('raise AssertionError("must not execute")\n')
        with patch('kinbot.rotdpy.importlib.util.find_spec',
                   return_value=None):
            with pytest.raises(RuntimeError, match='same environment'):
                run(input_file, python=sys.executable)


def test_executor_reports_captured_rotdpy_stderr():
    with TemporaryDirectory() as temporary:
        root = Path(temporary)
        input_file = root / 'channel.py'
        input_file.write_text(
            'import sys\n'
            'sys.stderr.write("scheduler template field failure\\n")\n'
            'raise SystemExit(3)\n')
        (root / 'qu.tpl').write_text('# scheduler fixture\n')
        with patch('kinbot.rotdpy.ensure_available', return_value={
                'version': 'test', 'location': '/test',
                'git_revision': 'abc'}):
            with pytest.raises(RuntimeError,
                               match='status 3.*scheduler template field'):
                run(input_file, python=sys.executable)
        record = json.loads((root / 'channel.execution.json').read_text())
        assert record['returncode'] == 3
        assert 'scheduler template field failure' in record['error']
        assert (root / record['stderr']).read_text() == \
            'scheduler template field failure\n'


def test_rotdpy_revision_must_match_pinned_submodule():
    with patch('kinbot.rotdpy.dependency_provenance', return_value={
            'version': '0.1.0', 'location': '/different',
            'git_revision': 'wrong'}):
        with pytest.raises(RuntimeError, match='pinned'):
            ensure_available()


def test_command_line_check_reports_completed_manifest(tmp_path, capsys):
    input_file = tmp_path / 'channel.py'
    input_file.write_text('# generated input\n')
    surface = tmp_path / 'kb_channel' / 'output' / 'surface_0.dat'
    number = tmp_path / 'kb_channel' / 'Ne_0.out'
    surface.parent.mkdir(parents=True)
    surface.write_text('surface flux\n')
    number.write_text('0.0 1.0\n')
    files = [number, surface]
    relative = [str(path.relative_to(tmp_path)) for path in files]
    hashes = {name: __import__('hashlib').sha256(path.read_bytes()).hexdigest()
              for name, path in zip(relative, files)}
    (tmp_path / 'channel.rotdpy.json').write_text(json.dumps({
        'schema': 2, 'status': 'complete', 'reaction': 'channel',
        'surface_count': 1, 'result_files': relative,
        'result_sha256': hashes,
    }))
    assert main(['check', str(input_file)]) == 0
    assert json.loads(capsys.readouterr().out)['status'] == 'complete'


def test_live_progress_counts_converged_surfaces_and_active_samples(tmp_path):
    input_file = tmp_path / 'channel.py'
    input_file.write_text('# generated input\n')
    root = tmp_path / 'kb_channel'
    for index in range(3):
        (root / f'Surface_{index}' / 'jobs').mkdir(parents=True)
    output = root / 'output'
    output.mkdir()
    (output / 'surface_0.dat').write_text('complete\n')
    (root / 'Surface_1/jobs/surf1_face0_samp843.pkl').write_bytes(b'x')

    with patch('kinbot.rotdpy.time.time',
               return_value=input_file.stat().st_mtime + 120.):
        progress = sampling_progress(input_file)
    assert progress['status'] == 'running'
    assert progress['surface_count'] == 3
    assert progress['converged_surfaces'] == 1
    assert progress['remaining_surfaces'] == 2
    assert progress['active_samples'] == [
        {'surface': 1, 'face': 0, 'sample': 843}]
    assert progress['elapsed_seconds'] == 120
    assert progress['linear_eta_seconds'] == 240


def test_live_progress_reports_periodic_restart_snapshot(tmp_path):
    input_file = tmp_path / 'channel.py'
    input_file.write_text('# generated input\n')
    root = tmp_path / 'kb_channel'
    (root / 'Surface_0/jobs').mkdir(parents=True)
    face = SimpleNamespace(_acct_num=83, _fail_num=1,
                           _close_num=20, _face_num=10)
    flux = SimpleNamespace(flux_array=[face], selected_faces=[0],
                           pot_max=100, tot_max=1000, converged=False)
    database = root / 'rotdPy_restart.db'
    with sqlite3.connect(database) as connection:
        connection.execute(
            'CREATE TABLE rotdpy_saved_runs '
            '(surf_id int, multi_flux blob, sample_list blob, '
            'flux_base blob, run_index int)')
        connection.execute(
            'INSERT INTO rotdpy_saved_runs VALUES (?, ?, ?, ?, ?)',
            (0, pickle.dumps(flux), pickle.dumps([83]), b'', 1))

    progress = sampling_progress(input_file)
    snapshot = progress['restart_snapshot']
    assert snapshot['accepted_samples'] == 83
    assert snapshot['failed_samples'] == 1
    assert snapshot['space_rejections'] == 30
    assert snapshot['potential_sample_ceiling'] == 100
    assert snapshot['accepted_samples_to_ceiling'] == 17
    assert snapshot['total_configuration_draws'] == 114
    assert snapshot['total_sample_ceiling'] == 1000
    assert snapshot['configuration_draws_to_ceiling'] == 886


def test_live_progress_reports_stalled_inactive_restart(tmp_path):
    input_file = tmp_path / 'channel.py'
    input_file.write_text('# generated input\n')
    root = tmp_path / 'kb_channel'
    (root / 'Surface_0/jobs').mkdir(parents=True)
    face = SimpleNamespace(_acct_num=100, _fail_num=0,
                           _close_num=0, _face_num=0)
    flux = SimpleNamespace(flux_array=[face], selected_faces=[0],
                           pot_max=100, tot_max=1000, converged=False)
    database = root / 'rotdPy_restart.db'
    with sqlite3.connect(database) as connection:
        connection.execute(
            'CREATE TABLE rotdpy_saved_runs '
            '(surf_id int, multi_flux blob, sample_list blob, '
            'flux_base blob, run_index int)')
        connection.execute(
            'INSERT INTO rotdpy_saved_runs VALUES (?, ?, ?, ?, ?)',
            (0, pickle.dumps(flux), pickle.dumps([100]), b'', 1))
    old = database.stat().st_mtime

    with patch('kinbot.rotdpy.time.time', return_value=old + 301.):
        progress = sampling_progress(input_file)

    assert progress['status'] == 'stalled'
    assert progress['restart_snapshot']['age_seconds'] == 301
    assert 'No sample jobs are active' in progress['status_detail']
